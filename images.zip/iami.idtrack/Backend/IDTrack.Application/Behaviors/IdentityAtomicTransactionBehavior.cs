using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Behaviors;

public sealed class IdentityAtomicTransactionBehavior<TRequest, TResponse>
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull, IIdentityAtomicTransaction
{
    private readonly IIdentityUnitOfWork _unitOfWork;
    public IdentityAtomicTransactionBehavior(IIdentityUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        await _unitOfWork.BeginTransactionAsync(cancellationToken);

        var response = await next();

        await _unitOfWork.CommitTransactionAsync(cancellationToken);

        return response;
    }

    private TResponse FromResult(Result result)
    {
        // Use reflection to get the FromResult method
        var fromResultMethod = typeof(TResponse).GetMethod("FromResult")!;

        // Invoke the FromResult method and cast the result to TResponseponse
        return (TResponse)fromResultMethod.Invoke(null, new object[] { result })!;
    }
}
