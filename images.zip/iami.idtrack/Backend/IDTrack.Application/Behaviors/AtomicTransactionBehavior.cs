using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Behaviors;

public sealed class AtomicTransactionBehavior<TRequest, TResponse>
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : notnull, IAtomicTransaction
{
    private readonly IUnitOfWork _unitOfWork;
    public AtomicTransactionBehavior(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        await _unitOfWork.BeginTransactionAsync(cancellationToken);

        var response = await next();

        var result = FromResponse(response);

        if (result is not null && result.IsFailure)
        {
            await _unitOfWork.RollBackTransactionAsync(cancellationToken);
        } 
        else 
        {
            await _unitOfWork.CommitTransactionAsync(cancellationToken);
        }

        return response;
    }

    private TResponse FromResult(Result result)
    {
        // Use reflection to get the FromResult method
        var fromResultMethod = typeof(TResponse).GetMethod("FromResult")!;

        // Invoke the FromResult method and cast the result to TResponseponse
        return (TResponse)fromResultMethod.Invoke(null, new object[] { result })!;
    }

    private Result? FromResponse(TResponse response)
    {
        // use casting to convert TResponse to Result, return null if failed
        try {
            return response as Result;
        } catch {
            return null;
        }
    }
}
