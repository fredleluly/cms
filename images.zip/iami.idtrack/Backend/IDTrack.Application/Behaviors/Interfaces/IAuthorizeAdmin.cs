namespace IDTrack.Application.Behaviors.Interfaces;

public interface IAuthorizeAdmin
{
}
