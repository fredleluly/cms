namespace IDTrack.Application.Behaviors.Interfaces;

public interface IAtomicTransaction
{
}

public interface IIdentityAtomicTransaction
{
}
