using Microsoft.Extensions.DependencyInjection;
using FluentValidation;
using IDTrack.Application.Behaviors;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Application.Features.Auth;

namespace IDTrack.Application;

public static class ApplicationInstaller
{
	public static IServiceCollection AddApplication(this IServiceCollection services)
	{
		services.AddMediatR(config =>
		{
			config.RegisterServicesFromAssembly(typeof(ApplicationInstaller).Assembly);

            config.AddOpenBehavior(typeof(ValidationBehavior<,>));

            config.AddOpenBehavior(typeof(AuthorizationBehavior<,>));

            config.AddOpenBehavior(typeof(AtomicTransactionBehavior<,>));

            config.AddOpenBehavior(typeof(IdentityAtomicTransactionBehavior<,>));
		});

        services.AddValidatorsFromAssembly(typeof(ApplicationInstaller).Assembly, ServiceLifetime.Singleton);

        services.AddSingleton<PickingEventSource>();

		return services;
	}
}
