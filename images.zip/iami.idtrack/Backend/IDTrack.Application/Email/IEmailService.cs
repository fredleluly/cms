using IDTrack.Domain.Models;

namespace IDTrack.Application.Email;

public interface IEmailService
{
    public Task<Result> SendSimpleMessageAddressListAsync(
        string subject,
        string body,
        string toList,
        string? ccList = null,
        string? bccList = null,
        CancellationToken ct = default);

    public Task<Result> SendSimpleHtmlMessageAsync(
        string subject,
        string body,
        string toName,
        string to,
        string? cc = null,
        string? bcc = null,
        CancellationToken ct = default);

    public Task<Result> SendSimpleHtmlMessageAddressListAsync(
        string subject,
        string body,
        string toList,
        string? ccList = null,
        string? bccList = null,
        CancellationToken ct = default);

    public Task<Result> SendSimpleMessage(
        string subject,
        string body,
        string toName,
        string to,
        string? cc = null,
        string? bcc = null,
        CancellationToken ct = default);
}
