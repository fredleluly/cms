namespace IDTrack.Application.Email;

public class EmailOptions
{
    public required string EmailFromName { get; set; }
    public required string EmailFrom { get; set; }
    public required string Host { get; set; }
    public required int Port { get; set; }
    public required string EmailUser { get; set; }
    public required string EmailPassword { get; set; }
    public required int SecureSocketOptions { get; set; }
    public bool RemoveXoAuth2 { get; set; } = false;
    public int RetryMax { get; set; } = 5;
};
