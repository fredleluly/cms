using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Abstractions.Messaging;

public interface IQuery<TResponse> : IRequest<Result<TResponse>>
{
}


