using IDTrack.Domain.Models;

namespace IDTrack.Application.Abstractions.Data;

public static class UnitOfWorkDomainError
{
    public static Error DuplicateEntry => new(nameof(DuplicateEntry), "Failed to save data: Duplicate entry");
}
