using IDTrack.Domain.Models;

namespace IDTrack.Application.Abstractions.Data;

public interface IPersistorQueueMaker
{
	public void AddEventsQueue(IReadOnlyCollection<IDomainEvent> domainEvents);
	public void AddEventQueue(IDomainEvent domainEvents);
}
