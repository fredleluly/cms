﻿using IDTrack.Domain.Models;

namespace IDTrack.Application.Abstractions.Data;

public interface IUnitOfWork
{
    public Task BeginTransactionAsync(CancellationToken cancellationToken);
	public Task CommitTransactionAsync(CancellationToken cancellationToken);
	public Task<Result> SaveChangesAsync(CancellationToken cancellationToken);
	public Task RollBackTransactionAsync(CancellationToken cancellationToken);
}

public interface IIdentityUnitOfWork : IUnitOfWork
{
}
