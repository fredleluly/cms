using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Dashboard.UseCases;

public record GetDriverSummaryUseCase(): IRequest<Result<GetDriverSummaryUseCaseResult>>, IAuthorizeAdmin;

public record GetDriverSummaryUseCaseResult(
    int TotalDriver,
    int AvailableDriver
);

public class GetDriverSummaryUseCaseHandler : IRequestHandler<GetDriverSummaryUseCase, Result<GetDriverSummaryUseCaseResult>>
{
    private readonly IUserRepository _userRepository;
    private readonly IPickingInstructionRepository _piRepository;

    public GetDriverSummaryUseCaseHandler(
        IUserRepository userRepository,
        IPickingInstructionRepository piRepository)
    {
        _userRepository = userRepository;
        _piRepository = piRepository;
    }

    public async Task<Result<GetDriverSummaryUseCaseResult>> Handle(GetDriverSummaryUseCase request, CancellationToken cancellationToken)
    {
        // Get total drivers count
        var totalDriverQuery = _userRepository
            .QueryDrivers()
            .GroupBy(x => 1)
            .Select(g => new { Count = g.Count() });

        var totalDriver = await _userRepository.LoadPageAsync(
            totalDriverQuery,
            new PagingQuery(),
            cancellationToken);

        // Get drivers with active picking instructions separately
        var driverWithActivePickings = await _piRepository.LoadPageAsync(
            _piRepository
                .Query()
                .Where(e => e.PickStatus == PickingInstruction.PickingStatus.InProgress)
                .Select(e => e.DriverId)
                .Distinct()
                .GroupBy(e => 1)
                .Select(e => new { Count = e.Count() }),
            new PagingQuery(),
            cancellationToken
        );

        var availableDriverCount = totalDriver.Rows.First().Count - driverWithActivePickings.Rows.First().Count;

        return Result.Success(new GetDriverSummaryUseCaseResult(
            totalDriver.Rows.FirstOrDefault()?.Count ?? 0,
            availableDriverCount
        ));
    }
}
