using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Dashboard.UseCases;

public record GetDriverActivitiesUseCase() : PagingQuery, IRequest<Result<PagingResult<DriverActivity>>>;

public record DriverActivity(
    string DriverName,
    string LogisticPartner,
    string? PickNo,
    DateTime? DriveStart
);

public class GetDriverActivitiesUseCaseHandler : IRequestHandler<GetDriverActivitiesUseCase, Result<PagingResult<DriverActivity>>>
{
    private readonly IUserRepository _userRepo;
    private readonly IPickingInstructionRepository _piRepo;

    public GetDriverActivitiesUseCaseHandler(IUserRepository userRepo, IPickingInstructionRepository piRepo)
    {
        _userRepo = userRepo;
        _piRepo = piRepo;
    }

    public async Task<Result<PagingResult<DriverActivity>>> Handle(GetDriverActivitiesUseCase request, CancellationToken cancellationToken)
    {
        var drivers = await _userRepo
            .LoadPageAsync(
                _userRepo
                    .QueryDrivers(),
                request,
                cancellationToken);

        var activePickingInstructions = await _piRepo.LoadPageAsync(
            _piRepo
                .Query()
                .Where(e => e.PickStatus == PickingInstruction.PickingStatus.InProgress),
            new PagingQuery(1, 1000),
            cancellationToken);

        PagingResult<DriverActivity> result = new PagingResult<DriverActivity>(
           drivers.Rows
            .Select(driver => {
                var activePI = activePickingInstructions.Rows
                    .Where(pi => pi.DriverId == driver.Id)
                    .FirstOrDefault();

                return new DriverActivity(
                    driver.Fullname,
                    driver.Claims.First(c => c.Type == ClaimType.LogisticPartnerId).Value,
                    activePI?.PickNo,
                    activePI?.PickStartTime);
                }
            ).ToList(),
            drivers.Page,
            drivers.RowsPerPage,
            drivers.TotalRows,
            drivers.TotalPages
        );

       return result;
    }
}
