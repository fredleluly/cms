using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Paging;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Dashboard.UseCases;

public record GetSupplierSummaryUseCase(
    DateTime Date
): IRequest<Result<GetSupplierSummaryUseCaseResult>>, IAuthorizeAdmin;

public record GetSupplierSummaryUseCaseResult(
    int TotalSupplier,
    int TotalOKBs,
    int TotalPickupPoint
);

public class GetSupplierSummaryUseCaseHandler : IRequestHandler<GetSupplierSummaryUseCase, Result<GetSupplierSummaryUseCaseResult>>
{
    private readonly IPartSupplierRepository _supplierRepository;
    private readonly IPickupPointRepository _pickupPointRepo;
    private readonly IPickingInstructionRepository _pickingInstructionRepo;

    public GetSupplierSummaryUseCaseHandler(
        IPartSupplierRepository supplierRepository,
        IPickupPointRepository pickupPointRepo,
        IPickingInstructionRepository pickingInstructionRepo)
    {
        _supplierRepository = supplierRepository;
        _pickupPointRepo = pickupPointRepo;
        _pickingInstructionRepo = pickingInstructionRepo;
    }

    public async Task<Result<GetSupplierSummaryUseCaseResult>> Handle(GetSupplierSummaryUseCase request, CancellationToken cancellationToken)
    {
        var totalSupplierQuery = _pickingInstructionRepo
            .Query()
            .Where(pi => pi.PickDate.Date == request.Date.Date)
            .Join(
                _pickupPointRepo.Query().Select(pp => new { pp.PickingInstructionId, pp.VendorCode }),
                pi => pi.Id,
                pp => pp.PickingInstructionId,
                (pi, pp) => pp.VendorCode
            )
            .Distinct()
            .GroupBy(x => 1)
            .Select(g => new { Count = g.Count() });

        var totalSupplier = await _supplierRepository.LoadPageAsync(
            totalSupplierQuery,
            new PagingQuery(),
            cancellationToken);

        var totalOkb = await _pickupPointRepo.LoadPageAsync(
            _pickingInstructionRepo
                .Query()
                .Where(pi => pi.PickDate.Date == request.Date.Date)
                .Join(
                    _pickupPointRepo.Query().Select(pp => new { pp.Id, pp.PickingInstructionId, OKBs = pp.OKBs }),
                    pi => pi.Id,
                    pp => pp.PickingInstructionId,
                    (pi, pp) => pp.OKBs
                )
                .SelectMany(e => e)
                .GroupBy(x => 1)
                .Select(g => new { Count = g.Count() }),
            new PagingQuery(),
            cancellationToken);

        var pickPointCount = await _pickingInstructionRepo.LoadPageAsync(
            _pickingInstructionRepo
                .Query()
                .Where(pi => pi.PickDate.Date == request.Date.Date)
                .Join(
                    _pickupPointRepo.Query().Select(pp => new { pp.PickingInstructionId }),
                    pi => pi.Id,
                    pp => pp.PickingInstructionId,
                    (pi, pp) => 1
                )
                .GroupBy(x => 1)
                .Select(g => new { Count = g.Count() }),
            new PagingQuery(),
            cancellationToken
        );

        return Result<GetSupplierSummaryUseCaseResult>.Success(new GetSupplierSummaryUseCaseResult(
            totalSupplier.Rows.FirstOrDefault()?.Count ?? 0,
            totalOkb.Rows.FirstOrDefault()?.Count ?? 0,
            pickPointCount.Rows.FirstOrDefault()?.Count ?? 0
        ));
    }
}
