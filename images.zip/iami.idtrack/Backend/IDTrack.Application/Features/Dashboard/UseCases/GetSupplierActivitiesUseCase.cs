using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Dashboard.UseCases;

public record GetSupplierActivitiesUseCase(DateTime Date): PagingQuery, IAuthorizeAdmin, IRequest<Result<PagingResult<SupplierActivity>>>;

public record SupplierActivity(
    string VendorCode,
    string? VendorName,
    int TotalOkb,
    int TotalOkbPicked
);

public class GetSupplierActivitiesUseCaseHandler : IRequestHandler<GetSupplierActivitiesUseCase, Result<PagingResult<SupplierActivity>>>
{
    private readonly IPartSupplierRepository _suppRepo;
    private readonly IPickingInstructionRepository _pickRepo;
    private readonly IPickupPointRepository _pickPointRepository;

    public GetSupplierActivitiesUseCaseHandler(
        IPartSupplierRepository suppRepo, 
        IPickingInstructionRepository pickRepo, 
        IPickupPointRepository pickPointRepository)
    {
        _suppRepo = suppRepo;
        _pickRepo = pickRepo;
        _pickPointRepository = pickPointRepository;
    }

    public async Task<Result<PagingResult<SupplierActivity>>> Handle(GetSupplierActivitiesUseCase request, CancellationToken cancellationToken)
    {
        var suppQuery = _suppRepo
            .Query();

        var pickingQuery = _pickRepo
            .Query()
            .Where(e => e.PickDate.Date == request.Date.Date)
            .Join(
                _pickPointRepository.Query(),
                pi => pi.Id,
                pp => pp.PickingInstructionId,
                (pi, pp) => new { pp.OKBs, pp.VendorCode }
             )
            .SelectMany(e => e.OKBs, (e, o) => new { e.VendorCode, Okb = o });

        var qry = suppQuery
            .Join(pickingQuery,
                s => s.VendorCode,
                p => p.VendorCode,
                (s, p) => new { Supplier = s, Okb = p.Okb }
            )
            .GroupBy(e => new { e.Supplier.VendorCode, e.Supplier.AliasName })
            .Where(e => e.Count() > 0)
            .Select(e => new SupplierActivity(
                e.Key.VendorCode,
                e.Key.AliasName,
                e.Count(),
                e.Count(e => e.Okb.Status == PickupOKB.PickupOKBStatus.Picked)
            ));

        return await _suppRepo.LoadPageAsync(qry, request, cancellationToken);
    }
}

