using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Dashboard.UseCases;

public record GetPickingSummaryUseCase(
    RangeQuery<DateTime> Date
): IRequest<Result<GetPickingSummaryUseCaseResult>>, IAuthorizeAdmin;

public record GetPickingSummaryUseCaseResult(
    int Total,
    int TotalCompleted,
    int TotalPending,
    int TotalInProgress
);

public class GetPickingSummaryUseCaseHandler : IRequestHandler<GetPickingSummaryUseCase, Result<GetPickingSummaryUseCaseResult>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    public GetPickingSummaryUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
    }

    public async Task<Result<GetPickingSummaryUseCaseResult>> Handle(GetPickingSummaryUseCase request, CancellationToken cancellationToken)
    {
        var predicate = PredicateBuilder.True<PickingInstruction>();

        predicate = predicate.And(x => x.PickDate >= request.Date.From);
        predicate = predicate.And(x => x.PickDate <= request.Date.To);

        var query = _pickingInstructionRepository
            .Query()
            .Where(e => (e.PickDate.Date >= request.Date.From && e.PickDate.Date <= request.Date.To))
            .GroupBy(x => 1)
            .Select(g => new 
            {
                Total = g.Count(),
                TotalCompleted = g.Count(x => x.PickStatus >= PickingInstruction.PickingStatus.GateIn),
                TotalPending = g.Count(x => x.PickStatus == PickingInstruction.PickingStatus.New),
                TotalInProgress = g.Count(x => x.PickStatus == PickingInstruction.PickingStatus.InProgress)
            });

        var result = await _pickingInstructionRepository.LoadPageAsync(query, new PagingQuery(), cancellationToken);

        return Result.Success(
            result.Rows.Select(r => new GetPickingSummaryUseCaseResult(
                r.Total,
                r.TotalCompleted,
                r.TotalPending,
                r.TotalInProgress
            )).FirstOrDefault() ?? new GetPickingSummaryUseCaseResult(0, 0, 0, 0)
        );
    }
}
