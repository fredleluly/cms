using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.AppConfiguration.UseCase;

public record GetAppConfigUseCase() : IRequest<Result<GetAppConfigUseCaseResult>>, IAuthorizeAdmin;

public record GetAppConfigUseCaseResult(
    string GeofenceEnable,
    string GeofenceRadius,
    bool DirectGeofenceEnabled,
    bool RealtimeMonitoringEnabled,
    DateTime OldDataCutoffDate
);

public class GetAppConfigUseCaseHandler : IRequestHandler<GetAppConfigUseCase, Result<GetAppConfigUseCaseResult>>
{
    private IAppConfigurationService _appConfigurationService;

    public GetAppConfigUseCaseHandler(IAppConfigurationService appConfigurationService)
    {
        _appConfigurationService = appConfigurationService;
    }
    public async Task<Result<GetAppConfigUseCaseResult>> Handle(GetAppConfigUseCase request, CancellationToken cancellationToken)
    {
        var geofenceEnableResult = await _appConfigurationService.IsPickingGeofenceEnabledAsync(cancellationToken);

        var geofenceRadiusResult = await _appConfigurationService.GetGeofenceRadiusInMeterAsync(cancellationToken);

        var directGeofenceEnableResult = await _appConfigurationService.IsDirectDlvGeofenceEnabledAsync(cancellationToken);

        var realtimeMonitoringEnabled = await _appConfigurationService.IsRealtimeMonitoringEnabledAsync(cancellationToken);

        var oldDataCutoffDate = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);

        var result = new GetAppConfigUseCaseResult(
            geofenceEnableResult.ToString(), 
            geofenceRadiusResult.ToString(),
            directGeofenceEnableResult,
            realtimeMonitoringEnabled,
            oldDataCutoffDate);

        return Result<GetAppConfigUseCaseResult>.Success(result);
    }
}
