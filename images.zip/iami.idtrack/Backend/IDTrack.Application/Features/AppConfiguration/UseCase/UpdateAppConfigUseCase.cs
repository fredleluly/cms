using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.AppConfiguration;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.AppConfiguration.UseCase;

public record UpdateAppConfigUseCase(
    string GeofenceEnable, 
    string GeofenceRadius,
    bool DirectGeofenceEnabled,
    bool RealtimeMonitoringEnabled,
    DateTime OldDataCutoffDate
) : IRequest<Result>, IAtomicTransaction, IAuthorizeAdmin;

public class UpdateAppConfigUseCaseHandler : IRequestHandler<UpdateAppConfigUseCase, Result>
{
    private readonly IAppConfigurationService _appConfigurationService;

    public UpdateAppConfigUseCaseHandler(IAppConfigurationService appConfigurationService)
    {
        _appConfigurationService = appConfigurationService;
    }
    public async Task<Result> Handle(UpdateAppConfigUseCase request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(request.GeofenceEnable) || string.IsNullOrWhiteSpace(request.GeofenceRadius))
        {
            return Result.Failure<AppConfig>(AppConfigurationDomainError.FailedToUpdateAppConfiguration(""));
        }

        var enableGeofenceConfig = new AppConfig(IAppConfigurationService.ENABLE_GEOFENCE_KEY, request.GeofenceEnable);
        var radiusGeofenceConfig = new AppConfig(IAppConfigurationService.GEOFENCE_RADIUS_KEY, request.GeofenceRadius);
        
        var updateResult = await _appConfigurationService.UpdateAppConfigurationAsync(
            enableGeofenceConfig, 
            radiusGeofenceConfig, 
            request.DirectGeofenceEnabled,
            request.RealtimeMonitoringEnabled,
            request.OldDataCutoffDate,
            cancellationToken);

        if (!updateResult.IsSuccess)
            return Result.Failure<AppConfig>(updateResult.Error);

        return Result.Success();
    }
}
