using IDTrack.Domain.Features.AppConfiguration;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.AppConfiguration;

public interface IAppConfigurationService
{
    public const string GLOBAL_APP_GROUP = "ITRACK";
    public const string APP_GROUP_KEY = "ITRACK_GEOFENCE";
    public const string GEOFENCE_RADIUS_KEY = "GEOFENCE_RADIUS";
    public const string ENABLE_GEOFENCE_KEY = "GEOFENCE_ENABLED";
    public const string ENABLE_DIRECT_GEOFENCE_KEY = "DIRECT_GEOFENCE_ENABLED";
    public const string ENABLE_REALTIME_MONITORING_KEY = "REALTIME_MONITORING_ENABLED";
    public const string OKB_CUTOFF_KEY = "OKB_CUTOFF";
    public Task<double> GetGeofenceRadiusInMeterAsync(CancellationToken cancellationToken);
    public Task<bool> IsDirectDlvGeofenceEnabledAsync(CancellationToken cancellationToken);
    public Task<bool> IsPickingGeofenceEnabledAsync(CancellationToken cancellationToken);
    public Task<bool> IsRealtimeMonitoringEnabledAsync(CancellationToken cancellationToken);
    public Task<Result> UpdateAppConfigurationAsync(
        AppConfig geofenceEnabled, 
        AppConfig geofenceRadius,
        bool directDlvGeofenceEnabled,
        bool enableRealtimeMonitoring,
        DateTime okbCutoffDate,
        CancellationToken cancellationToken);
    public Task<DateTime> GetOkbCutoffDateAsync(CancellationToken cancellationToken);
}
