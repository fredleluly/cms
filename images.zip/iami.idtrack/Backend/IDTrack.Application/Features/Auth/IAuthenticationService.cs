using System.Security.Claims;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Auth;

public interface IAuthenticationService
{
    public Task<Result<User>> GetAuthenticatedUserAsync(CancellationToken cancellationToken = default);
    public Task<Result<ICollection<Claim>>> GetAuthenticatedUserClaimsAsync(CancellationToken cancellationToken = default);
    public Task<Result<int>> GetAuthenticatedUserIdAsync(CancellationToken cancellationToken = default);
}
