using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Request
public record ConfirmEmailUseCase(
    string Email,
    string Token
) : IRequest<Result>;

// Handler
public class ConfirmEmailUSeCaseHandler : IRequestHandler<ConfirmEmailUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public ConfirmEmailUSeCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result> Handle(ConfirmEmailUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.ConfirmedEmailAsync(request.Email, request.Token);

        if (result.IsSuccess)
            return Result.Success();
        return Result.Failure(result.Error);
    }
}
