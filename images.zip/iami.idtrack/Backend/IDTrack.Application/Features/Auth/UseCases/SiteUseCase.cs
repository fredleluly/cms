using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

public record SiteUseCase() : IRequest<Result<SiteUseCaseResult>>;

public record SiteUseCaseResult(
    string Fullname,
    string Username,
    string Email,
    string? PhoneNumber,
    string? LogisticPartnerName = null,
    string? SupplierName = null
);

public class SiteUseCaseHandler : IRequestHandler<SiteUseCase, Result<SiteUseCaseResult>>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IPickingTransporterRepository _transporterRepository;
    private readonly IPartSupplierRepository _supplierRepository;

    public SiteUseCaseHandler(IAuthenticationService authenticationService, IPickingTransporterRepository transporterRepository, IPartSupplierRepository supplierRepository)
    {
        _authenticationService = authenticationService;
        _transporterRepository = transporterRepository;
        _supplierRepository = supplierRepository;
    }

    public async Task<Result<SiteUseCaseResult>> Handle(SiteUseCase request, CancellationToken cancellationToken)
    {
        var user = await _authenticationService.GetAuthenticatedUserAsync(cancellationToken);

        if (user.Value is null)
            return Result.Failure<SiteUseCaseResult>(IdentityDomainError.UserIsNotAuthenticated);

        string? transporterName = null;
        string? supplierName = null;

        var transporterCode = user.Value.Claims.FirstOrDefault(c => c.Type == ClaimType.LogisticPartnerId)?.Value;

        if (transporterCode != null)
        {
            var transporter = await _transporterRepository.GetByTransporterCodeAsync(transporterCode, cancellationToken);

            if (transporter.Value is not null)
                transporterName = transporter.Value.TransporterName;
        }

        var supplierCode = user.Value.Claims.FirstOrDefault(c => c.Type == ClaimType.SupplierId)?.Value;

        if (supplierCode != null)
        {
            var supplier = await _supplierRepository.GetByCodeAsync(supplierCode, cancellationToken);

            if (supplier.Value is not null)
                supplierName = supplier.Value.VendorName;
        }

        return Result.Success(new SiteUseCaseResult(
            user.Value.Fullname,
            user.Value.Username,
            user.Value.Email,
            user.Value.PhoneNumber,
            transporterName,
            supplierName
        ));
    }
}
