using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Identity.Models;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Request
public record RefreshTokenUseCase(
    string JwtToken,
    string RefreshToken
) : IRequest<Result<RefreshTokenUseCaseResult>>;

// Response
public record RefreshTokenUseCaseResult : AuthenticationResult
{
    public RefreshTokenUseCaseResult(AuthenticationResult result) : base(
        result.AccessToken,
        result.RefreshToken,
        result.TokenType,
        result.Scope,
        result.ExpiresIn)
    { }
};

// Handler
public class RefreshTokenUseCaseHandler : IRequestHandler<RefreshTokenUseCase, Result<RefreshTokenUseCaseResult>>
{
    private readonly IIdentityService _identityService;

    public RefreshTokenUseCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result<RefreshTokenUseCaseResult>> Handle(RefreshTokenUseCase request, CancellationToken cancellationToken)
    {
        Result<AuthenticationResult> result = await _identityService.RefreshTokenAsync(request.JwtToken, request.RefreshToken, cancellationToken);

        if (result.IsFailure || result.Value is null)
            return Result.Failure<RefreshTokenUseCaseResult>(result.Error);

        return Result.Success(new RefreshTokenUseCaseResult(result.Value));
    }
}
