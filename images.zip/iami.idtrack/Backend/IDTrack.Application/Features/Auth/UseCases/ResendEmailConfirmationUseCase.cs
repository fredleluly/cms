using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Request
public record ResendEmailConfirmationUseCase(
    string Email
) : IRequest<Result>;

// Handler
public class ResendEmailConfirmationUseCaseHandler : IRequestHandler<ResendEmailConfirmationUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public ResendEmailConfirmationUseCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result> Handle(ResendEmailConfirmationUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.SendConfirmedEmailAsync(request.Email, cancellationToken);

        if (result.IsSuccess)
            return Result.Success();
        return Result.Failure(result.Error);
    }
}
