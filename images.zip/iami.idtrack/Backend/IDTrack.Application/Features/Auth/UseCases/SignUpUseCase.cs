using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Request
public record SignUpUseCase(
    string Username,
    string Email,
    string FirstName,
    string LastName,
    string Password
) : IRequest<Result>;

// Handler
public class SignUpUSeCaseHandler : IRequestHandler<SignUpUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public SignUpUSeCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result> Handle(SignUpUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.SignUpAsync(
            request.Username,
            request.Email,
            request.FirstName,
            request.LastName,
            request.Password
        );

        if (result.IsSuccess)
            return Result.Success();
        return Result.Failure(result.Error);
    }
}
