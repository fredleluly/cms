using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Request
public record ForgotPasswordUseCase(
    string Email
) : IRequest<Result>;

// Handler
public class ForgotPasswordUSeCaseHandler : IRequestHandler<ForgotPasswordUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public ForgotPasswordUSeCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result> Handle(ForgotPasswordUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.ForgotPasswordAsync(request.Email, cancellationToken);

        if (result.IsSuccess)
            return Result.Success();
        return Result.Failure(result.Error);
    }
}
