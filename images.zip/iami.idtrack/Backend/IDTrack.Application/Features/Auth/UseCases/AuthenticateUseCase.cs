using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Identity.Models;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth.UseCases;

// Response
public record AuthenticateUseCaseResult : AuthenticationResult
{
    public AuthenticateUseCaseResult(AuthenticationResult result) : base(
        result.AccessToken,
        result.RefreshToken,
        result.TokenType,
        result.Scope,
        result.ExpiresIn)
    { }
};

// Request
public record AuthenticateUseCase(string username, string password) : IRequest<Result<AuthenticateUseCaseResult>>;

// Handler
public class AuthenticateUseCaseHandler : IRequestHandler<AuthenticateUseCase, Result<AuthenticateUseCaseResult>>
{
    private readonly IIdentityService _identityService;

    public AuthenticateUseCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result<AuthenticateUseCaseResult>> Handle(AuthenticateUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.SignInAsync(request.username, request.password, cancellationToken);

        if (result.IsSuccess && result.Value != null)
            return Result.Success(new AuthenticateUseCaseResult(result.Value));
        return Result.Failure<AuthenticateUseCaseResult>(result.Error);
    }
}

