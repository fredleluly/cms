using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Direct;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth;

public class AuthorizationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IBaseRequest
    where TResponse : Result
{
    private readonly IAuthenticationService _authenticationService;

    public AuthorizationBehavior(IAuthenticationService authenticationService)
    {
        _authenticationService = authenticationService;
    }

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        // Get all authorization interfaces implemented by the request
        var authInterfaces = request.GetType().GetInterfaces()
            .Where(i => i.Name.StartsWith("IAuthorize"))
            .ToList();

        if (!authInterfaces.Any())
            return await next();

        var user = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        if (user.IsFailure || user.Value is null)
            return FromResult(Result.Failure(IdentityDomainError.UserIsNotAuthenticated));

        var userClaims = user.Value;
        var userRoles = userClaims
            .Where(c => c.Type == ClaimType.Role)
            .Select(c => c.Value.ToLower())
            .ToList();

        // Check if user has ANY of the required roles
        var hasRequiredRole = false;

        if (authInterfaces.Contains(typeof(IAuthorizeAdmin)) && userRoles.Contains(RoleNames.Admin.ToLower()))
        {
            hasRequiredRole = true;
        }
        else if (authInterfaces.Contains(typeof(IAuthorizeLogisticPartner)) && userRoles.Contains(RoleNames.LogisticPartner.ToLower()))
        {
            hasRequiredRole = true;
        }
        else if (authInterfaces.Contains(typeof(IAuthorizeSupplier)) && userRoles.Contains(RoleNames.Supplier.ToLower()))
        {
            hasRequiredRole = true;
        }

        if (!hasRequiredRole)
        {
            return FromResult(Result.Failure(IdentityDomainError.UserIsNotAuthorized));
        }

        return await next();
    }

    private TResponse FromResult(Result result)
    {
        var type = typeof(TResponse);
        var fromResultMethod = typeof(TResponse).GetMethod("FromResult")!;
        return (TResponse)fromResultMethod.Invoke(null, new object[] { result })!;
    }
}
