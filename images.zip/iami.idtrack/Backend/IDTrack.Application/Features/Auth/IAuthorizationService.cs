using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Auth;

public interface IAuthorizationService
{
    public Task<Result<User>> IsUserAuthorizedToUseCaseAsync(User user, IRequest request);
}
