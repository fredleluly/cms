using IDTrack.Application.Features.PickingPreparation.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.ComponentTracking.Picking;

public interface IPickupPointRepository : IPagingService<PickupPoint>
{
    public Task<Result<ICollection<PickupPoint>>> GetPickupPointsByPickNoAsync(string pickNo, CancellationToken cancellationToken);
    public Task<Result<PickupPoint>> GetPickupPointByIdAsync(long id, CancellationToken cancellationToken);
    public Task<Result<PickupPoint>> CreatePickupPointAsync(PickupPoint pickupPoint, CancellationToken cancellationToken);
    public Task<Result<PickupPoint>> UpdatePickupPointAsync(PickupPoint pickupPoint, CancellationToken cancellationToken);
    public Task<Result<PickupPoint>> DeletePickupPointAsync(long id, CancellationToken cancellationToken);
    public Task<Result> DeletePickupPointRangeAsync(ICollection<long> ids, CancellationToken cancellationToken);
    public Task<Result<ICollection<PickupPoint>>> CreateRangeAsync(ICollection<PickupPoint> pickupPoints, CancellationToken cancellationToken);
    public Task<Result<ICollection<PickupPoint>>> CreateOrUpdateRangeAsync(ICollection<PickupPoint> pickupPoints, CancellationToken cancellationToken);
    public Task<Result<ICollection<PickupPoint>>> LoadQueryAsync(IQueryable<PickupPoint> query, CancellationToken cancellationToken);
    public Task<Result<ICollection<PickupPoint>>> GetPickupByActiveOkbsAsync(ICollection<string> okbs, CancellationToken cancellationToken);
    public Task<bool> PickupPointsHasActivityAsync(long pickId, CancellationToken ct);
    public Task<Result<ICollection<PickupPoint>>> GetLastPickupPointOfOkbsAsync(ICollection<string> okbs, CancellationToken cancellationToken);
    public void AttachPickupPoints(ICollection<PickupPoint> pickups);
    public Task<Result<ICollection<PickupPointPDFDto>>> GetPickupPointsByPickNoForPdfAsync(string pickNo, CancellationToken cancellationToken);

    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> query, PagingQuery page, CancellationToken ct) where T : class;
}
