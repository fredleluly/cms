using IDTrack.Application.Features.ComponentTracking.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.ComponentTracking.Picking;

public interface IPickingInstructionRepository : IPagingService<PickingInstruction>
{
    public Task<string> GeneratePickNoAsync(CancellationToken cancellationToken);
    public Task<Result<PickingInstruction>> GetPickingInstructionByIdAsync(long id, CancellationToken cancellationToken);
    public Task<Result<GetPickingInstructionDetailUseCaseResult>> GetPickingInstructionByPickNoAsync(string pickNo, CancellationToken cancellationToken);
    public Task<Result<PickingInstruction>> GetDomainByPickNoAsync(string pickNo, CancellationToken cancellationToken);
    public Task<Result<PickingInstruction>> CreatePickingInstructionAsync(PickingInstruction pickingInstruction, CancellationToken cancellationToken);
    public Task<Result<PickingInstruction>> UpdatePickingInstructionAsync(PickingInstruction pickingInstruction, CancellationToken cancellationToken);
    public Task<Result<PickingInstruction>> DeletePickingInstructionAsync(long id, CancellationToken cancellationToken);
    public Task<PagingResult<QueryLPPickingInstructionUseCaseResult>> QueryLPPickingInstructionAsync(
        QueryLPPickingInstructionUseCase request,
        string transporterCode,
        CancellationToken ct);

    public Task<bool> PickingExistsAsync(string? transporterCode, string? routeCode, CancellationToken ct);
    public Task<bool> PickingExistsAsync(long transporterCode, long routeCode, CancellationToken ct);

    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> qry, PagingQuery page, CancellationToken ct) where T : class;
}
