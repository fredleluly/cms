using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public record UpdatePickingInstructionUseCase(
    long Id,
    ICollection<string> OkbNumbers
) : IRequest<Result>, IAtomicTransaction, IAuthorizeAdmin;

public class UpdatePickingInstructionUseCaseHandler : IRequestHandler<UpdatePickingInstructionUseCase, Result>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IPickingDomainService _pickingDomainService;
    private readonly IOKBRepository _okbRepository;
    private readonly IUnitOfWork _unitOfWork;

    public UpdatePickingInstructionUseCaseHandler(
        IPickingInstructionRepository pickingInstructionRepository, 
        IPickupPointRepository pickupPointRepository, 
        IPickingDomainService pickingDomainService, 
        IOKBRepository okbRepository, 
        IUnitOfWork unitOfWork)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _pickingDomainService = pickingDomainService;
        _okbRepository = okbRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result> Handle(UpdatePickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        // validate if the picking instruction exists
        var picking = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(request.Id, cancellationToken);

        if (picking.IsFailure || picking.Value is null)
            return picking;

        if (picking.Value.PickStatus != PickingInstruction.PickingStatus.New)
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PickingDomainError.CannotEditStartedPickingInstruction);

        // validate if the okb numbers are already in another picking instruction
        var pickupPointInOtherInstructionResult = await _pickupPointRepository.GetPickupByActiveOkbsAsync(request.OkbNumbers, cancellationToken);

        if (pickupPointInOtherInstructionResult.IsFailure || pickupPointInOtherInstructionResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickupPointInOtherInstructionResult.Error);
        }

        if (pickupPointInOtherInstructionResult.Value.Any(e => e.PickingInstructionId != picking.Value.Id))
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PickingDomainError
                .OKBAlreadyInOtherPickingInstruction(
                    string.Join(
                        ", ",
                        pickupPointInOtherInstructionResult.Value
                            .Where(e => e.PickingInstructionId != picking.Value.Id)
                            .SelectMany(e => e.OKBs)
                            .Select(e => e.OkbNo)
                            .Intersect(request.OkbNumbers)
                    )
                ));
        }

        // do insert or update okb numbers
        var result = await _pickingDomainService.InsertOrUpdatePickingOKBAsync(picking.Value, request.OkbNumbers, cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(result.Error);
        }

        await _okbRepository.UpdateOKBPickNoAsync(request.OkbNumbers, picking.Value.PickNo, cancellationToken);
        
        return await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}

