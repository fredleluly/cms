using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public record TogglePickingGeofencingUSeCase(long Id, bool GeofencingEnabled) : IRequest<Result<PickingInstruction>>, IAuthorizeAdmin;

public class TogglePickingGeofencingUSeCaseHandler : IRequestHandler<TogglePickingGeofencingUSeCase, Result<PickingInstruction>>
{
    private readonly IPickingInstructionRepository _pickinginstructionRepository;

    public TogglePickingGeofencingUSeCaseHandler(IPickingInstructionRepository pickingInstructionRepository)
    {
        _pickinginstructionRepository = pickingInstructionRepository;
    }

    public async Task<Result<PickingInstruction>> Handle(TogglePickingGeofencingUSeCase request, CancellationToken cancellationToken)
    {
        var pickingInstruction = await _pickinginstructionRepository.GetPickingInstructionByIdAsync(request.Id, cancellationToken);

        if (pickingInstruction.IsFailure || pickingInstruction.Value is null)
        {
            return Result.Failure<PickingInstruction>(pickingInstruction.Error);
        }

        pickingInstruction.Value.GeofencingEnabled = request.GeofencingEnabled;

        var result = await _pickinginstructionRepository.UpdatePickingInstructionAsync(pickingInstruction.Value, cancellationToken);

        if (result.IsSuccess)
        {
            return Result.Success(pickingInstruction.Value);
        }

        return Result.Failure<PickingInstruction>(result.Error);
    }
}

