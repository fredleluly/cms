using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public record ToggleUntrackPickingInstructionUseCase(long Id, bool Untracked) : IRequest<Result<PickingInstruction>>, IAuthorizeAdmin;

public class ToggleUntrackPickingInstructionUseCaseHandler : IRequestHandler<ToggleUntrackPickingInstructionUseCase, Result<PickingInstruction>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    public ToggleUntrackPickingInstructionUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
    }

    public async Task<Result<PickingInstruction>> Handle(ToggleUntrackPickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        var pickingInstructionResult = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(request.Id, cancellationToken);

        if (pickingInstructionResult.IsFailure || pickingInstructionResult.Value is null)
        {
            return Result.Failure<PickingInstruction>(pickingInstructionResult.Error);
        }

        pickingInstructionResult.Value.Untracked = request.Untracked;

        var result = await _pickingInstructionRepository.UpdatePickingInstructionAsync(pickingInstructionResult.Value, cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.FailedToToggleUntrackPickingInstruction);
        }

        return pickingInstructionResult;
    }
}
