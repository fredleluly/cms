using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public record DeletePickingInstructionUseCase(int Id) : IRequest<Result<PickingInstruction>>, IAuthorizeAdmin;

public class PickingInstructionUseCaseHandler : IRequestHandler<DeletePickingInstructionUseCase, Result<PickingInstruction>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    public PickingInstructionUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
    }

    public async Task<Result<PickingInstruction>> Handle(DeletePickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        var pickingInstruction = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(request.Id, cancellationToken);

        if (pickingInstruction.IsFailure || pickingInstruction.Value is null)
        {
            return Result.Failure<PickingInstruction>(pickingInstruction.Error);
        }

        var result = await _pickingInstructionRepository.DeletePickingInstructionAsync(pickingInstruction.Value.Id, cancellationToken);

        if (result.IsSuccess)
        {
            return Result.Success(pickingInstruction.Value);
        }

        return Result.Failure<PickingInstruction>(result.Error);
    }
}
