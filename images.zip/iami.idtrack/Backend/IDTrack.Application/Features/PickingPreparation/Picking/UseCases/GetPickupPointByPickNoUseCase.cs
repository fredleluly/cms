using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record GetPickupPointsByPickNoUseCase(string PickNo) : IRequest<Result<ICollection<GetPickupPointsByPickNoUseCaseResult>>>, IAuthorizeAdmin;

public class GetPickupPointsByPickNoUseCaseResult : PickupPoint
{
    public new ICollection<OKB> OKBs { get; set; } = new List<OKB>();
}

public class GetPickupPointsByPickNoUseCaseHandler : IRequestHandler<GetPickupPointsByPickNoUseCase, Result<ICollection<GetPickupPointsByPickNoUseCaseResult>>>
{
    private readonly IPickingDomainService _pickingDomainService;

    public GetPickupPointsByPickNoUseCaseHandler(IPickingDomainService pickingDomainService)
    {
        _pickingDomainService = pickingDomainService;
    }

    public async Task<Result<ICollection<GetPickupPointsByPickNoUseCaseResult>>> Handle(GetPickupPointsByPickNoUseCase request, CancellationToken cancellationToken)
    {
        return await _pickingDomainService.GetPickupPointsUseCaseResultByPickNoAsync(request.PickNo, cancellationToken);
    }
}

