using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;
public record DownloadPickingSheetUseCase(string PickNo) 
    : IRequest<Result<byte[]>>, IAuthorizeAdmin, IAuthorizeLogisticPartner;

public record PickingInstructionPDFDto(
    string PickNo,
    string? TransporterCode,
    int? CycleNo,
    DateTime ArrivalDate,
    ICollection<PickupPointPDFDto> PickupPoints
);

public record PickupPointPDFDto(
    string? SupplierAlias,
    ICollection<PickupOKBPDFDto> OKBs
);

public record PickupOKBPDFDto(
    string OkbNo
);

public class DownloadPickingSheetUseCaseHandler : IRequestHandler<DownloadPickingSheetUseCase, Result<byte[]>>
{
    private readonly IPickingDomainService _pickingDomainService;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;

    public DownloadPickingSheetUseCaseHandler(IPickingDomainService fileExportService, IPickingInstructionRepository pickingInstructionRepository, IPickupPointRepository pickupPointRepository)
    {
        _pickingDomainService = fileExportService;
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;

    }
    public async Task<Result<byte[]>> Handle(DownloadPickingSheetUseCase request, CancellationToken cancellationToken)
    {
        var pickingInstruction = await _pickingInstructionRepository.GetPickingInstructionByPickNoAsync(request.PickNo, cancellationToken);
        var pickPointList = await _pickupPointRepository.GetPickupPointsByPickNoForPdfAsync(request.PickNo, cancellationToken);

        if (pickPointList.Value is null)
            return Result.Failure<byte[]>(pickPointList.Error);

        if ( pickingInstruction.Value is null)
            return Result.Failure<byte[]>(pickingInstruction.Error);

        var result = new PickingInstructionPDFDto(
            pickingInstruction.Value.PickNo,
            pickingInstruction.Value.TransporterCode,
            pickingInstruction.Value.CycleNo,
            pickingInstruction.Value.ArrivalDate,
            [.. pickPointList.Value
                .Select(p => new PickupPointPDFDto(
                    p.SupplierAlias,
                    [.. p.OKBs
                        .Select(okb => new PickupOKBPDFDto(
                            okb.OkbNo)
                        )]
                    )
                )]
            );
        var pdfBytes = await _pickingDomainService.DownloadPickingSheetAsync(result);

        return Result.Success(pdfBytes);
    }
}
