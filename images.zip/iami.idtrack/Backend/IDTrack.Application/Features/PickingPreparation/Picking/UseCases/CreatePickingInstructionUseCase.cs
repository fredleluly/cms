using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.Masters.Route;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public class CreatePickingInstructionUseCaseResult : PickingInstruction
{
    public ICollection<PickupPoint> PickupPoints { get; set; } = new List<PickupPoint>();
}

public class CreatePickingInstructionUseCaseValidator : AbstractValidator<CreatePickingInstructionUseCase>
{
    public CreatePickingInstructionUseCaseValidator()
    {
        RuleFor(x => x.TransporterCode)
            .MaximumLength(10)
            .WithMessage("TransporterCode must not exceed 10 characters")
            .NotEmpty()
            .WithMessage("TransporterCode is required");

        RuleFor(x => x.RouteCode)
            .MaximumLength(10)
            .WithMessage("RouteCode must not exceed 10 characters")
            .NotEmpty()
            .WithMessage("RouteCode is required");

        RuleFor(x => x.ArrivalDate)
            .NotEmpty()
            .WithMessage("ArrivalDate is required");

        RuleFor(x => x.ArrivalTime)
            .MaximumLength(5)
            .WithMessage("ArrivalTime must not exceed 5 characters")
            .Matches(@"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$")
            .WithMessage("ArrivalTime must be in HH:mm format")
            .NotEmpty()
            .WithMessage("ArrivalTime is required");

        RuleFor(x => x.CycleNo)
            .GreaterThan(0)
            .WithMessage("CycleNo must be greater than 0")
            .NotEmpty()
            .WithMessage("Cycle No is required");

        // RuleFor(x => x.OkbNumbers)
        //     .NotEmpty()
        //     .WithMessage("OkbNumbers is required");
    }
}

// TODO: add validation for duplicate OkbNumbers
public record CreatePickingInstructionUseCase(
    string TransporterCode,
    string RouteCode,
    int CycleNo,
    DateOnly ArrivalDate,
    string ArrivalTime,
    ICollection<string> OkbNumbers
) : IRequest<Result<CreatePickingInstructionUseCaseResult>>, IAtomicTransaction, IAuthorizeAdmin;

public class CreatePickingInstructionUseCaseHandler : IRequestHandler<CreatePickingInstructionUseCase, Result<CreatePickingInstructionUseCaseResult>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IOKBRepository _okbRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IPickingRouteRepository _pickingRouteRepository;
    private readonly IPickingTransporterRepository _pickingTransporterRepository;
    private readonly IPickingDomainService _pickingDomainService;

    public CreatePickingInstructionUseCaseHandler(
        IPickingInstructionRepository pickingInstructionRepository,
        IOKBRepository okbRepository,
        IPickupPointRepository pickupPointRepository,
        IPickingTransporterRepository pickingTransporterRepository,
        IPickingRouteRepository pickingRouteRepository,
        IPickingDomainService pickingDomainService)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _okbRepository = okbRepository;
        _pickupPointRepository = pickupPointRepository;
        _pickingTransporterRepository = pickingTransporterRepository;
        _pickingRouteRepository = pickingRouteRepository;
        _pickingDomainService = pickingDomainService;
    }

    public async Task<Result<CreatePickingInstructionUseCaseResult>> Handle(CreatePickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        // business validation
        var transporterResult = await _pickingTransporterRepository.GetByTransporterCodeAsync(request.TransporterCode, cancellationToken);
        if (transporterResult.IsFailure || transporterResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(transporterResult.Error);
        }

        var routeResult = await _pickingRouteRepository.GetByRouteCodeAsync(request.RouteCode, cancellationToken);
        if (routeResult.IsFailure || routeResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(routeResult.Error);
        }

        var pickupPointInOtherInstructionResult = await _pickupPointRepository.GetPickupByActiveOkbsAsync(request.OkbNumbers, cancellationToken);

        if (pickupPointInOtherInstructionResult.IsFailure || pickupPointInOtherInstructionResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickupPointInOtherInstructionResult.Error);
        }

        if (pickupPointInOtherInstructionResult.Value.Any())
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PickingDomainError
                .OKBAlreadyInOtherPickingInstruction(
                    string.Join(
                        ", ",
                        pickupPointInOtherInstructionResult.Value
                            .SelectMany(e => e.OKBs)
                            .Select(e => e.OkbNo)
                            .Intersect(request.OkbNumbers)
                    )
                ));
        }

        // business logic start
        var pickNo = await _pickingInstructionRepository.GeneratePickNoAsync(cancellationToken);
        var pickingInstruction = new PickingInstruction
        {
            PickNo = pickNo,
            TransporterCode = request.TransporterCode,
            RouteCode = request.RouteCode,
            ArrivalDate = request.ArrivalDate.ToDateTime(TimeOnly.MinValue),
            ArrivalTime = request.ArrivalTime,
            CycleNo = request.CycleNo
        };

        var saveResult = await _pickingInstructionRepository.CreatePickingInstructionAsync(pickingInstruction, cancellationToken);

        if (saveResult.IsFailure || saveResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(saveResult.Error);
        }

        var createdPickingInstruction = saveResult.Value;

        var foundOkbs = await _okbRepository.GetOKBsByListAsync(request.OkbNumbers, cancellationToken);

        var notFoundOKBs = foundOkbs.Count > 0 ? request.OkbNumbers.Except(foundOkbs.Select(o => o.DnNo)).ToList() : new List<string>();

        if (notFoundOKBs.Count > 0)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PartDeliveryDomainError.OKBNotFound(string.Join(", ", notFoundOKBs)));
        }

        var result = await _pickingDomainService.InsertOrUpdatePickingOKBAsync(createdPickingInstruction, request.OkbNumbers, cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(result.Error);
        }

        var createdPickupPoints = await _pickupPointRepository.GetPickupPointsByPickNoAsync(createdPickingInstruction.PickNo, cancellationToken);

        if (createdPickupPoints.IsFailure || createdPickupPoints.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(createdPickupPoints.Error);
        }

        return Result.Success(new CreatePickingInstructionUseCaseResult
        {
            Id = pickingInstruction.Id,
            PickNo = pickingInstruction.PickNo,
            RouteCode = pickingInstruction.RouteCode,
            TransporterCode = pickingInstruction.TransporterCode,
            CycleNo = pickingInstruction.CycleNo,
            PickDate = pickingInstruction.PickDate,
            ArrivalDate = pickingInstruction.ArrivalDate,
            ArrivalTime = pickingInstruction.ArrivalTime,
            GeofencingEnabled = pickingInstruction.GeofencingEnabled,
            PickupPoints = createdPickupPoints.Value
        });
    }
}
