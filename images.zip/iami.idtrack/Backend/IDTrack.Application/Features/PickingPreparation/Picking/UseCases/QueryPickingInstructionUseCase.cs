using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.Picking.UseCases;

public class QueryPickingInstructionUseCaseValidator : AbstractValidator<QueryPickingInstructionUseCase>
{
    public QueryPickingInstructionUseCaseValidator()
    {
        RuleFor(x => x.ArrivalDate)
            .Must(e => DateOnly.TryParse(e, out _))
            .When(x => !string.IsNullOrWhiteSpace(x.ArrivalDate))
            .WithMessage("ArrivalDate must be a valid date");
    }
}

public record QueryPickingInstructionUseCase(
    string? PickNo = null, 
    string? RouteCode = null, 
    string? TransporterCode= null,
    string? ArrivalDate = null,
    int? Cycle = null,
    bool Undone = false,
    int? Status = null
) : PagingQuery, IRequest<Result<PagingResult<PickingInstruction>>>, IAuthorizeAdmin;

public class QueryPickingInstructionUseCaseHandler : IRequestHandler<QueryPickingInstructionUseCase, Result<PagingResult<PickingInstruction>>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    public QueryPickingInstructionUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
    }

    public async Task<Result<PagingResult<PickingInstruction>>> Handle(QueryPickingInstructionUseCase request, CancellationToken cancellationToken)
    { 
        var query = _pickingInstructionRepository.Query();

        var predicate = PredicateBuilder.True<PickingInstruction>();

        if(!string.IsNullOrWhiteSpace(request.Search))
        {
            predicate = predicate.And(x => x.TransporterCode.Contains(request.Search) || x.PickNo.Contains(request.Search) || x.RouteCode.Contains(request.Search));
        }

        if (!string.IsNullOrWhiteSpace(request.TransporterCode))
        {
            predicate = predicate.And(x => x.TransporterCode.Contains(request.TransporterCode));
        }

        if (!string.IsNullOrWhiteSpace(request.PickNo))
        {
            predicate = predicate.And(x => x.PickNo.Contains(request.PickNo));
        }

        if (!string.IsNullOrWhiteSpace(request.RouteCode))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(request.RouteCode));
        }

        if (!string.IsNullOrWhiteSpace(request.ArrivalDate))
        {
            var arrivalDate = DateTime.Parse(request.ArrivalDate);
            predicate = predicate.And(x => x.ArrivalDate.Date == arrivalDate.Date);
        }

        if (request.Cycle.HasValue)
            predicate = predicate.And(x => x.CycleNo == request.Cycle);

        if (request.Status.HasValue)
            predicate = predicate.And(x => x.PickStatus == request.Status.Value);

        else if (request.Undone)
            predicate = predicate.And(x => x.PickStatus < PickingInstruction.PickingStatus.GateIn);

        query = query.Where(predicate).OrderByDescending(x => x.CreateTime);

        return await _pickingInstructionRepository.LoadPageAsync(query, request, cancellationToken);
    }
}
