using IDTrack.Application.Features.ComponentTracking.Picking.UseCases;
using IDTrack.Application.Features.Monitoring.UseCases;
using IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;
using IDTrack.Application.Features.PickingPreparation.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.PickingPreparation.Picking;

public interface IPickingDomainService
{
    public Task<Result> InsertOrUpdatePickingOKBAsync(PickingInstruction pickingInstruction, ICollection<string> okbNumbers, CancellationToken ct);
    public Task<Result> AssignPickingOKBAsync(PickingInstruction pickingInstruction, ICollection<string> okbNumbers, CancellationToken ct);
    public Task<Result<GetPickingSessionUseCaseResult>> GetActivePickingSessionByDriverIdAsync(int driverId, CancellationToken cancellationToken);
    public Task<Result<ICollection<GetMonitoringDataUseCaseResult>>> GetMonitoringDataAsync(GetMonitoringDataUseCase request, CancellationToken ct);
    public Task<PagingResult<OKB>> QueryOKBToBeProcessedAsync(QueryDelayedOrUnassignedOKBUseCase pagingQuery, CancellationToken ct);
    public Task<Result> RemoveOKBFromPickupPointAsync(
        PickupPoint pickupPoint, 
        string okbNo, 
        CancellationToken ct);

    public Task<Result<ICollection<GetPickupPointsByPickNoUseCaseResult>>> GetPickupPointsUseCaseResultByPickNoAsync(
        string pickNo, CancellationToken ct);

    public Task<byte[]> DownloadPickingSheetAsync(PickingInstructionPDFDto pickingInstruction);

}
