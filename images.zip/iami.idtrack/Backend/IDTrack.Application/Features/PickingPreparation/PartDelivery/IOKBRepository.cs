using IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.PickingPreparation.PartDelivery;

public interface IOKBRepository : IPagingService<OKB>
{
    public Task<ICollection<OKB>> GetOKBsByListAsync(ICollection<string> okbNumbers, CancellationToken ct);
    public Task<Result<OKB>> GetOkbByOkbNoAsync(string okbNo, CancellationToken ct);
    public Task<PagingResult<OKB>> QueryOKBsAsync(QueryOKBUseCase query, CancellationToken ct);
    public Task<Result> UpdateOKBPickNoAsync(ICollection<string> okbNumbers, string pickNo, CancellationToken ct);
    public Task<Result> RemovePickNoAsync(ICollection<string> okbNumbers, CancellationToken ct);
}
