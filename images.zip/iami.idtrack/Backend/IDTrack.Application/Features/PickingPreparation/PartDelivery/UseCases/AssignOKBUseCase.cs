using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;

public record AssignOKBsUseCase(
    ICollection<string> Okbs,
    long DestPickingInstructionId
) : IRequest<Result>, IAtomicTransaction, IAuthorizeAdmin;

public class AssignOKBsUseCaseHandler : IRequestHandler<AssignOKBsUseCase, Result>
{
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickingDomainService _pickingDomainService;
    private readonly IOKBRepository _okbRepository;

    public AssignOKBsUseCaseHandler(IPickupPointRepository pickupPointRepository, IPickingInstructionRepository pickingInstructionRepository, IPickingDomainService pickingDomainService, IOKBRepository okbRepository)
    {
        _pickupPointRepository = pickupPointRepository;
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickingDomainService = pickingDomainService;
        _okbRepository = okbRepository;
    }

    public async Task<Result> Handle(AssignOKBsUseCase request, CancellationToken cancellationToken)
    {
        var pickingInstruction = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(request.DestPickingInstructionId, cancellationToken);

        if (pickingInstruction.IsFailure || pickingInstruction.Value is null)
        {
            return Result.Failure(pickingInstruction.Error);
        }

        // validate destination picking instruction status
        if (pickingInstruction.Value.PickStatus > PickingInstruction.PickingStatus.InProgress)
        {
            return PickingDomainError.CannotAssignOKBToCompletedPickingInstruction;
        }

        var pickupPointsResult = await _pickupPointRepository.GetPickupByActiveOkbsAsync(request.Okbs, cancellationToken);

        if (pickupPointsResult.IsFailure || pickupPointsResult.Value is null)
        {
            return Result.Failure(pickupPointsResult.Error);
        }

        // validate if okbs are already in other active picking instruction
        if (pickupPointsResult.Value.Count > 0)
        {
            var foundOkbs = pickupPointsResult.Value.SelectMany(e => e.OKBs).Select(e => e.OkbNo).Intersect(request.Okbs).ToList();
            return PickingDomainError.OKBAlreadyInOtherPickingInstruction(string.Join(", ", foundOkbs));
        }

        var assignResult = await _pickingDomainService.AssignPickingOKBAsync(pickingInstruction.Value, request.Okbs, cancellationToken);

        if (assignResult.IsFailure)
        {
            return Result.Failure(assignResult.Error);
        }
        
        return await _okbRepository.UpdateOKBPickNoAsync(request.Okbs, pickingInstruction.Value.PickNo, cancellationToken);
    }
}

