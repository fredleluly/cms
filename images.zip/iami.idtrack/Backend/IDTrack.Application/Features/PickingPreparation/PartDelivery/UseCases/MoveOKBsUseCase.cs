using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;

public record MoveOKBsUseCase(
    long DestPickingInstructionId,
    ICollection<string> Okbs
) : IRequest<Result>, IAtomicTransaction, IAuthorizeAdmin;

public class MoveOKBsUseCaseHandler : IRequestHandler<MoveOKBsUseCase, Result>
{
    private readonly IPickingDomainService _pickingDomainService;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IOKBRepository _okbRepository;
    private readonly IUnitOfWork _unitOfWork;

    public MoveOKBsUseCaseHandler(
        IPickingDomainService pickingDomainService,
        IPickingInstructionRepository pickingInstructionRepository,
        IPickupPointRepository pickupPointRepository,
        IUnitOfWork unitOfWork,
        IOKBRepository okbRepository)
    {
        _pickingDomainService = pickingDomainService;
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _unitOfWork = unitOfWork;
        _okbRepository = okbRepository;
    }

    public async Task<Result> Handle(MoveOKBsUseCase request, CancellationToken cancellationToken)
    {
        var destPickingInstruction = await _pickingInstructionRepository
            .GetPickingInstructionByIdAsync(request.DestPickingInstructionId, cancellationToken);

        if (destPickingInstruction.IsFailure || destPickingInstruction.Value is null)
        {
            return Result.Failure(destPickingInstruction.Error);
        }

        var pickupPointsResult = await _pickupPointRepository.GetPickupByActiveOkbsAsync(request.Okbs, cancellationToken);

        if (pickupPointsResult.IsFailure || pickupPointsResult.Value is null)
        {
            return pickupPointsResult;
        }

        var pickupPointToBeDeleted = new List<long>();
        foreach (var okb in request.Okbs)
        {
            var sourcePickupPoint = pickupPointsResult.Value.FirstOrDefault(e => e.OKBs.Any(e => e.OkbNo == okb));

            if (sourcePickupPoint is null)
            {
                continue;
            }

            await _pickingDomainService.RemoveOKBFromPickupPointAsync(sourcePickupPoint, okb, cancellationToken);

            if (sourcePickupPoint.OKBs.Count == 0)
            {
                pickupPointToBeDeleted.Add(sourcePickupPoint.Id);
            }
        }

        if (pickupPointToBeDeleted.Count > 0)
        {
            await _pickupPointRepository.DeletePickupPointRangeAsync(pickupPointToBeDeleted, cancellationToken);
        }

        var persistRemoveResult = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (persistRemoveResult.IsFailure)
        {
            return persistRemoveResult;
        }

        var assignResult = await _pickingDomainService.AssignPickingOKBAsync(destPickingInstruction.Value, request.Okbs, cancellationToken);

        if (assignResult.IsFailure)
        {
            return assignResult;
        }

        return await _okbRepository.UpdateOKBPickNoAsync(request.Okbs, destPickingInstruction.Value.PickNo, cancellationToken);
    }
}
