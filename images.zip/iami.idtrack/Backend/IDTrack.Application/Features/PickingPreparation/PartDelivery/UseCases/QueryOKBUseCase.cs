using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;

public record QueryOKBUseCase(
    string? VendorSite,
    string? TransporterCode,
    string? RouteCode,
    string? OkbNo,
    int? Status
) : PagingQuery, IRequest<Result<PagingResult<OKB>>>, IAuthorizeAdmin
{
    public RangeQuery<DateOnly?>? ArrivalDate { get; set; }
    public RangeQuery<string?>? ArrivalTime { get; set; }
};

public class QueryOKBUseCaseHandler : IRequestHandler<QueryOKBUseCase, Result<PagingResult<OKB>>>
{
    private readonly IOKBRepository _okbRepository;

    public QueryOKBUseCaseHandler(IOKBRepository okbRepository)
    {
        _okbRepository = okbRepository;
    }

    public async Task<Result<PagingResult<OKB>>> Handle(QueryOKBUseCase request, CancellationToken cancellationToken)
    {
        return await _okbRepository.QueryOKBsAsync(request, cancellationToken);
    }
}

