using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;

public record QueryDelayedOrUnassignedOKBUseCase(
    string? OkbNo,
    string? PickNo,
    string? VendorSite,
    string? TransporterCode,
    string? RouteCode
) : PagingQuery, IRequest<Result<PagingResult<OKB>>>, IAuthorizeAdmin
{
    public RangeQuery<DateOnly?>? ArrivalDate { get; set; }
    public RangeQuery<string?>? ArrivalTime { get; set; }
};

public class QueryDelayedOrUnassignedOKBUseCaseHandler : IRequestHandler<QueryDelayedOrUnassignedOKBUseCase, Result<PagingResult<OKB>>>
{
    private readonly IPickingDomainService _pickingDomainService;

    public QueryDelayedOrUnassignedOKBUseCaseHandler(IPickingDomainService pickingDomainService)
    {
        _pickingDomainService = pickingDomainService;
    }

    public async Task<Result<PagingResult<OKB>>> Handle(QueryDelayedOrUnassignedOKBUseCase request, CancellationToken cancellationToken)
    {
        return await _pickingDomainService.QueryOKBToBeProcessedAsync(request, cancellationToken);
    }
}
