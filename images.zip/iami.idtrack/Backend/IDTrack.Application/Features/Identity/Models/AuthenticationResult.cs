using System.Text.Json.Serialization;

namespace IDTrack.Application.Features.Identity.Models;

public record AuthenticationResult(
    [property: JsonPropertyName("access_token")]
    string AccessToken,
    [property: JsonPropertyName("refresh_token")]
    string RefreshToken,
    [property: JsonPropertyName("token_type")]
    string TokenType,
    [property: JsonPropertyName("scope")]
    string? Scope,
    [property: JsonPropertyName("expires_in")]
    int? ExpiresIn
);
