using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Identity;

public interface IUserDeviceService{
    public Task<Result<string>> GetUserDeviceIdfromHeadersAsync(CancellationToken cancellationToken = default);
}