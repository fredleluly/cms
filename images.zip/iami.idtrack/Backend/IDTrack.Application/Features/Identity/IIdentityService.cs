using System.Security.Claims;
using IDTrack.Application.Features.Identity.Models;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Entities;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Identity;

public interface IIdentityService
{
    public bool AutoEmailConfirmedSetting { get; }
    //public bool SendEmailVerificationSetting { get; }
    public Task<Result> CreateUserAsync(string username, string email, string firstName, string lastName, string? phoneNumber, Boolean lockoutEnabled, Boolean disabled, string password, IList<string> roles);
    public Task<Result> UpdateUserAsync(int userId, string firstName, string lastName, string? phoneNumber, Boolean lockoutEnabled, Boolean disabled, IList<string> roles);
    public Task<Result> DeleteUserAsync(int userId);
    public Task<User?> GetUserByIdAsync(int userId);
    public Task<User?> GetUserByNameAsync(string username);
    public Task<User?> GetUserByEmailAsync(string email);
    public Task<IEnumerable<string>> GetUserRolesAsync(int userId);
    public Task<IEnumerable<Claim>> GetUserClaimsAsync(int userId);
    public Task<IEnumerable<Claim>> GetRoleClaimsAsync(string roleName);
    public Task<IEnumerable<Role>> GetAllRolesAsync();
    public Task<Result> UpdateAssignedUserRoles(int userId, IList<string> roles);
    public Task<Result> ChangePasswordAsync(int userId, string oldPassword, string newPassword);
    public Task<string> GenerateEmailConfirmationTokenAsync(string email);
    public Task<Result> ConfirmedEmailAsync(string email, string token);
    public Task<string> GeneratePasswordResetTokenAsync(string email);
    public Task<Result> ResetPasswordAsync(string email, string token, string newPassword);
    public Task<Result> SignUpAsync(string username, string email, string firstName, string lastName, string password);
    public Task<Result<AuthenticationResult>> SignInAsync(string username, string password, CancellationToken ct = default);
    public Task<Result> SignOutAsync(string refreshTokenId, CancellationToken ct = default);
    public Task<Result<AuthenticationResult>> RefreshTokenAsync(string jwtToken, string refreshToken, CancellationToken ct = default);
    public Task<Result> ForgotPasswordAsync(string email, CancellationToken ct = default);
    public Task<Result> SendConfirmedEmailAsync(string email, CancellationToken ct = default);
}
