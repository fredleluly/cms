using MediatR;
using IDTrack.Domain.Models;
using IDTrack.Application.Behaviors.Interfaces;

namespace IDTrack.Application.Features.Identity.UseCases.DeleteUserUseCase;

//Request
public record DeleteUserUseCase(int UserId): IRequest<Result>, IAuthorizeAdmin;

//Handler
public class DeleteUserUseCaseHandler : IRequestHandler<DeleteUserUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public DeleteUserUseCaseHandler(IIdentityService identityService){
        _identityService = identityService;
    }

    public async Task<Result> Handle(DeleteUserUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.DeleteUserAsync(request.UserId);

        if (result.IsSuccess)
            return Result.Success(result);
        return Result.Failure(result.Error);
    }
}
