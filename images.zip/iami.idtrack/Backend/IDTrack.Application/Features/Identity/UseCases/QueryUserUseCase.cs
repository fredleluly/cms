using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Identity.UseCases;

public record QueryUserUseCase(
    string? UserName = null,
    string? WarehouseCode = null,
    string? PlantCode = null,
    string? Role = null
) : PagingQuery, IRequest<Result<PagingResult<QueryUserUseCaseResult>>>, IAuthorizeAdmin;

public record QueryUserUseCaseResult(
    int Id,
    string Username,
	string Fullname,
    string Email,
    string? PhoneNumber,
    string? PlantCode,
	string? WarehouseCode,
    string? VendorCode,
    string? TransporterCode,
	bool Disabled,
    bool EmailConfirmed,
    bool LockoutEnabled,
    string[] Roles
);

public class QueryUserUseCaseHandler : IRequestHandler<QueryUserUseCase, Result<PagingResult<QueryUserUseCaseResult>>>
{
    private readonly IUserRepository _userRepository;

    public QueryUserUseCaseHandler(IUserRepository userRepository)
    {
        _userRepository = userRepository;
    }

    public async Task<Result<PagingResult<QueryUserUseCaseResult>>> Handle(QueryUserUseCase request, CancellationToken cancellationToken)
    {
        return Result.Success(await _userRepository.LoadPageAsync(request, cancellationToken));
    }
}
