using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Identity.UseCases;

public record GetAllRolesUseCase(): IRequest<Result<IEnumerable<Role>>>, IAuthorizeAdmin;

public class GetAllRolesUseCaseHandler : IRequestHandler<GetAllRolesUseCase, Result<IEnumerable<Role>>>
{
    private readonly IIdentityService _identityService;

    public GetAllRolesUseCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result<IEnumerable<Role>>> Handle(GetAllRolesUseCase request, CancellationToken cancellationToken)
    {
        var roles = await _identityService.GetAllRolesAsync();

        if (roles == null)
        {
            return Result.Failure<IEnumerable<Role>>(IdentityDomainError.CannotGetRoles);
        }

        return Result<IEnumerable<Role>>.Success(roles.Select(r => new Role
        {
            Id = r.Id,
            Name = r.Name,
            RoleDescription = r.RoleDescription
        }));
    }
}
