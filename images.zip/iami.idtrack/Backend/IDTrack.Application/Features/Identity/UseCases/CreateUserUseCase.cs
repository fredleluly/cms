using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Identity.UseCases.CreateUserUseCase;

//Request 
public record CreateUserUseCase(
    string Username, 
    string Email, 
    string FirstName, 
    string LastName, 
    string? PhoneNumber, 
    bool LockoutEnabled, 
    string Password, 
    IList<string> Roles
) : IRequest<Result>, IAuthorizeAdmin;

//Handler
public class CreateUserUseCaseHandler : IRequestHandler<CreateUserUseCase, Result>
{
    private readonly IIdentityService _identityService;

    public CreateUserUseCaseHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result> Handle(CreateUserUseCase request, CancellationToken cancellationToken)
    {
        var result = await _identityService.CreateUserAsync(
            request.Username, 
            request.Email, 
            request.FirstName, 
            request.LastName, 
            request.PhoneNumber, 
            request.LockoutEnabled, 
            false, 
            request.Password, 
            request.Roles);

        if (result.IsSuccess)
            return Result.Success();
        return Result.Failure(result.Error);
    }
}
