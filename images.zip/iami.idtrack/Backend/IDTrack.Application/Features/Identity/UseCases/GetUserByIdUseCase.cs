using MediatR;
using IDTrack.Domain.Models;
using IDTrack.Domain.Features.Identity;
using IDTrack.Application.Behaviors.Interfaces;

namespace IDTrack.Application.Features.Identity.UseCases.GetUserByIdUseCase;

// Request
public record GetUserByIdUseCase(int UserId) : IRequest<Result<GetUserByIdUseCaseResult>>, IAuthorizeAdmin;

// Response
public record GetUserByIdUseCaseResult(
    int Id,
    string UserName,
    string Email,
    bool EmailConfirmed,
    string Fullname,
    bool Disabled,
    string? PhoneNumber,
    bool LockoutEnabled
);

// Handler
public class GetUserByIdHandler : IRequestHandler<GetUserByIdUseCase, Result<GetUserByIdUseCaseResult>>
{
    private readonly IIdentityService _identityService;

    public GetUserByIdHandler(IIdentityService identityService)
    {
        _identityService = identityService;
    }

    public async Task<Result<GetUserByIdUseCaseResult>> Handle(GetUserByIdUseCase request, CancellationToken cancellationToken)
    {
        var user = await _identityService.GetUserByIdAsync(request.UserId);

        if (user is not null)
        {
            return Result.Success(new GetUserByIdUseCaseResult(
                (int)user.Id,
                user.Username!,
                user.Email!,
                user.EmailConfirmed,
                user.Fullname,
                user.Disabled,
                user.PhoneNumber,
                user.LockoutEnabled
            ));
        }
        
        return Result.Failure<GetUserByIdUseCaseResult>(IdentityDomainError.UserNotFound(request.UserId.ToString()));
    }
}
