using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Internationalization;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Identity.UseCases.UpdateUserUseCase;

// Request
public record UpdateUserUseCase(
    int UserId,
    bool Disabled,
    IList<string> Roles,
    string? VendorCode = null,
    string? TransporterCode = null
) : IRequest<Result>, IIdentityAtomicTransaction, IAuthorizeAdmin;

// Handler
public class UpdateUSerUSeCaseHandler : IRequestHandler<UpdateUserUseCase, Result>
{
    private readonly IIdentityService _identityService;
    private readonly IUserRepository _userRepository;
    private readonly IDomainErrorLocalizer _localizer;

    public UpdateUSerUSeCaseHandler(IIdentityService identityService, IUserRepository userRepository, IDomainErrorLocalizer localizer)
    {
        _identityService = identityService;
        _userRepository = userRepository;
        _localizer = localizer;
    }

    public async Task<Result> Handle(UpdateUserUseCase request, CancellationToken cancellationToken)
    {
        var user = await _identityService.GetUserByIdAsync(request.UserId);

        if (user is null)
            return IdentityDomainError.UserNotFound(request.UserId.ToString());

        if (request.Roles.Contains(RoleNames.Supplier) && request.VendorCode is null)
            return IdentityDomainError.VendorCodeRequiredForSupplier;

        if (request.Roles.Contains(RoleNames.LogisticPartner) && request.TransporterCode is null)
            return IdentityDomainError.TransporterCodeRequiredForLogisticPartner;

        if ((request.VendorCode is not null && request.TransporterCode is not null) ||
            (request.Roles.Contains(RoleNames.Supplier) && request.Roles.Contains(RoleNames.LogisticPartner))
        )
            return IdentityDomainError.UserCanEitherBeSupplierOrLogisticPartner;

        if (request.VendorCode is not null && !request.Roles.Contains(RoleNames.Supplier))
            return IdentityDomainError.PleaseAddSupplierToUserRole;

        if (request.TransporterCode is not null && !request.Roles.Contains(RoleNames.LogisticPartner))
            return IdentityDomainError.PleaseAddLogisticPartnerToUserRole;

        if (request.Disabled)
            user.Disable();
        else
            user.Enable();

        if (request.VendorCode is not null)
            user.SetSupplier(request.VendorCode);
        else
            user.RemoveSupplierClaim();

        if (request.TransporterCode is not null)
            user.SetLogisticPartner(request.TransporterCode);
        else
            user.RemoveLogisticPartnerClaim();

        var result = await _userRepository.UpdateUserAsync(user, cancellationToken);

        if (result.IsFailure)
            return result;

        var roleResult = await _identityService.UpdateAssignedUserRoles(user.Id, request.Roles);

        if (roleResult.IsFailure)
            return roleResult;

        return Result.Success();
    }
}
