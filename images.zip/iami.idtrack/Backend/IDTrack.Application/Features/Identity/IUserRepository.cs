using IDTrack.Application.Features.Identity.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Identity;

public interface IUserRepository : IPagingService<User>
{
    public Task<Result> UpdateUserAsync(User user, CancellationToken ct = default);
    public Task<PagingResult<QueryUserUseCaseResult>> LoadPageAsync(QueryUserUseCase req, CancellationToken ct);
    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> qry, PagingQuery page, CancellationToken ct) where T : class;

    public IQueryable<User> QueryDrivers();
}
