using IDTrack.Domain.Features.PickingGR;

namespace IDTrack.Application.Features.PickingGR;

public interface IPickingGRDomainService
{
    public Task<byte[]> DownloadLPBAsync(GoodReceive goodReceive);
}
