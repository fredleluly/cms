using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Domain.Features.PickingGR.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingGR.UseCase;

public record GetPickingGRDetailUseCase(int Id) : IRequest<Result<GetPickingGRDetailUseCaseResult>>, IAuthorizeAdmin;

public record GetPickingGRDetailUseCaseResult(
    string GRNo,
    DateTime GRDate,
    string PONo,
    DateTime PODate,
    string PlantReceiver,
    string InvoiceNo,
    string VendorNo,
    string VendorPlant,
    ICollection<GoodReceiveDetail> GRItems
);

public class GetPickingGRDetailUseCaseHandler : IRequestHandler<GetPickingGRDetailUseCase, Result<GetPickingGRDetailUseCaseResult>>
{
    private readonly IPickingGRRepository _queryPickingGRUseCase;

    public GetPickingGRDetailUseCaseHandler(IPickingGRRepository queryPickingGRUseCase)
    {
        _queryPickingGRUseCase = queryPickingGRUseCase;
    }
    public async Task<Result<GetPickingGRDetailUseCaseResult>> Handle(GetPickingGRDetailUseCase request, CancellationToken cancellationToken)
    {
        var grDetail = await _queryPickingGRUseCase.GetByIdAsync(request.Id, cancellationToken);

        return grDetail;
    }
}
