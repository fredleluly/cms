using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingGR;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingGR.UseCase;

public record QueryPickingGRUseCase(
    string? GRNo = null,
    DateTime? GRDate = null,
    string? PlantReceiver = null,
    string? InvoiceNo = null,
    string? VendorNo = null
) : PagingQuery, IRequest<Result<PagingResult<GoodReceive>>>, IAuthorizeAdmin;

public class QueryPickingGRUseCaseHandler : IRequestHandler<QueryPickingGRUseCase, Result<PagingResult<GoodReceive>>>
{
    private readonly IPickingGRRepository _queryPickingGRUseCase;

    public QueryPickingGRUseCaseHandler(IPickingGRRepository queryPickingGRUseCase)
    {
        _queryPickingGRUseCase = queryPickingGRUseCase;
    }

    public async Task<Result<PagingResult<GoodReceive>>> Handle(QueryPickingGRUseCase request, CancellationToken cancellationToken)
    {
        var query = _queryPickingGRUseCase.Query();

        var predicate = PredicateBuilder.True<GoodReceive>();

        if (!string.IsNullOrEmpty(request.GRNo))
        {
            predicate = predicate.And(x => x.GRNo.Contains(request.GRNo));
        }

        if (request.GRDate.HasValue)
        {
            predicate = predicate.And(x => x.GRDate == request.GRDate.Value);
        }

        query = query.Where(predicate);

        return await _queryPickingGRUseCase.LoadPageAsync(query, request, cancellationToken);
    }
}

