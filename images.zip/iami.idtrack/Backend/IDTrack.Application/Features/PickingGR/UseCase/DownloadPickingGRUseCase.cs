using IDTrack.Application.Features.PickingGR;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingGR.UseCase;
public record DownloadPickingGRUseCase(string GRNo) : IRequest<Result<byte[]>>;

public class DownloadPickingGRUseCaseHandler : IRequestHandler<DownloadPickingGRUseCase, Result<byte[]>>
{
    private readonly IPickingGRDomainService _pickingGRDomainService;
    private readonly IPickingGRRepository _pickingGRRepository;

    public DownloadPickingGRUseCaseHandler(IPickingGRDomainService pickingGRDomainService, IPickingGRRepository pickingGRRepository)
    {
        _pickingGRDomainService = pickingGRDomainService;
        _pickingGRRepository = pickingGRRepository;
    }
    public async Task<Result<byte[]>> Handle(DownloadPickingGRUseCase request, CancellationToken cancellationToken)
    {
        var goodReceive = await _pickingGRRepository.GetGoodReceiveByGRNoAsync(request.GRNo, cancellationToken);

        if ( goodReceive.Value is null)
            return Result.Failure<byte[]>(goodReceive.Error);

        var pdfBytes = await _pickingGRDomainService.DownloadLPBAsync(goodReceive.Value);

        return Result.Success(pdfBytes);
    }
}