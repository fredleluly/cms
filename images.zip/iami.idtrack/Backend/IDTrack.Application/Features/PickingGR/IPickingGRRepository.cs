using IDTrack.Application.Features.PickingGR.UseCase;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingGR;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.PickingGR;

public interface IPickingGRRepository : IPagingService<GoodReceive>
{
    public Task<Result<GoodReceive>> AddAsync(GoodReceive goodReceive, CancellationToken ct);
    public Task<Result<GetPickingGRDetailUseCaseResult>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<GoodReceive>> UpdateAsync(GoodReceive goodReceive, CancellationToken ct);
    public Task<Result<GoodReceive>> DeleteAsync(long id, CancellationToken ct);
    public Task<Result<GoodReceive>> GetGoodReceiveByGRNoAsync(string grNo, CancellationToken ct);
}
