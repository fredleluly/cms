using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public interface IDirectDeliveryRepository : IPagingService<DirectDelivery>
{
    public Task<Result> CreateDirectDeliveryAsync(DirectDelivery directDelivery, CancellationToken ct);
    public Task<Result> UpdateDirectDeliveryAsync(DirectDelivery directDelivery, CancellationToken ct);
    public Task<Result> DeleteDirectDeliveryAsync(long id, CancellationToken ct);
    public Task<Result<DirectDelivery>> GetDirectDeliveryByIdAsync(long id, CancellationToken ct);
    public Task<Result<DirectDelivery>> GetActiveDirectDeliveryByCreatorAsync(long userId, CancellationToken ct);
}
