namespace IDTrack.Application.Features.ComponentTracking.Direct;

public interface IAuthorizeSupplier { }
