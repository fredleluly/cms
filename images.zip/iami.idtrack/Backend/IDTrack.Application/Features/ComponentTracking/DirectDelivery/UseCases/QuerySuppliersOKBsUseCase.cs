using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.PartDelivery.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record QuerySuppliersOKBsUseCase() : PagingQuery, IRequest<Result<PagingResult<OKB>>>, IAuthorizeSupplier;

public class QuerySuppliersOKBsUseCaseHandlers : IRequestHandler<QuerySuppliersOKBsUseCase, Result<PagingResult<OKB>>>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IOKBRepository _okbRepository;

    public QuerySuppliersOKBsUseCaseHandlers(IAuthenticationService authenticationService, IOKBRepository okbRepository)
    {
        _authenticationService = authenticationService;
        _okbRepository = okbRepository;
    }

    public async Task<Result<PagingResult<OKB>>> Handle(QuerySuppliersOKBsUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();
        
        if (claimResult.IsFailure || claimResult.Value is null)
        {
            return Result.Failure<PagingResult<OKB>>(claimResult.Error);
        }

        var claims = claimResult.Value;

        var supplierCodeClaim = claims.FirstOrDefault(c => c.Type == ClaimType.SupplierId);

        var supplierCode = supplierCodeClaim!.Value;

        var okbList = await _okbRepository
            .LoadPageAsync(
                _okbRepository.Query().Where(o => o.VendorCode == supplierCode && o.DeliveryType == DeliveryType.Direct && o.RcvStatus == 0), 
                request, 
                cancellationToken);

        return Result.Success(okbList);
    }
}

