using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record CancelDirectDeliverySessionUseCase(long DeliveryId) : PagingQuery, IRequest<Result>, IAuthorizeSupplier;

public class CancelDirectDeliverySessionUseCaseHandlers : IRequestHandler<CancelDirectDeliverySessionUseCase, Result>
{
    private readonly IDirectDeliveryRepository _directDeliveryRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IUserDeviceService _userDeviceService;

    public CancelDirectDeliverySessionUseCaseHandlers(
        IDirectDeliveryRepository directDeliveryRepository, 
        IAuthenticationService authenticationService, 
        IUnitOfWork unitOfWork, IUserDeviceService userDeviceService)
    {
        _directDeliveryRepository = directDeliveryRepository;
        _authenticationService = authenticationService;
        _unitOfWork = unitOfWork;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(CancelDirectDeliverySessionUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var delivery = await _directDeliveryRepository.GetDirectDeliveryByIdAsync(request.DeliveryId, cancellationToken);

        if (delivery.IsFailure || delivery.Value is null)
        {
            return DirectDeliveryDomainError.DeliveryNotFound;
        }

        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();
        var userSupplierCode = claimResult.Value!.First(e => e.Type == ClaimType.SupplierId).Value;

        if (userSupplierCode != delivery.Value.SupplierCode.ToString())
        {
            return DirectDeliveryDomainError.DeliveryMismatch;
        }

        // Check if the delivery status is already completed
        if (delivery.Value.Status == DirectDelivery.DirectDeliveryStatus.Delivered)
        {
            return DirectDeliveryDomainError.FailedToDeleteDelivery(delivery.Error.ToString());
        }

        var result = delivery.Value.Cancel(deviceId.Value);

        if (result.IsFailure)
        {
            return Result.Failure<DirectDelivery>(result.Error);
        }

        return await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}
