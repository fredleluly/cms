using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.ComponentTracking.Direct;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Direct.UseCases;

public record AddOkbToDeliverySessionUseCase(long DeliveryId, string OkbNo) : IRequest<Result>, IAuthorizeSupplier;

public class AddOkbToDeliverySessionUseCaseHandler : IRequestHandler<AddOkbToDeliverySessionUseCase, Result>
{
    private readonly ISender _sender;
    private readonly IDirectDeliveryRepository _directDeliveryRepository;
    private readonly IOKBRepository _okbRepository;
    private readonly IAuthenticationService _authenticationService;

    public AddOkbToDeliverySessionUseCaseHandler(
        IDirectDeliveryRepository directDeliveryRepository,
        ISender sender,
        IOKBRepository okbRepository,
        IAuthenticationService authenticationService)
    {
        _directDeliveryRepository = directDeliveryRepository;
        _sender = sender;
        _okbRepository = okbRepository;
        _authenticationService = authenticationService;
    }

    public async Task<Result> Handle(AddOkbToDeliverySessionUseCase request, CancellationToken cancellationToken)
    {
        var result = await _sender.Send(new CheckOkbForDeliveryUseCase(request.OkbNo));

        if (result.IsFailure)
        {
            return result;
        }

        var okb = result.Value;

        var delivery = await _directDeliveryRepository.GetDirectDeliveryByIdAsync(request.DeliveryId, cancellationToken);

        if (delivery.IsFailure || delivery.Value is null)
        {
            return delivery.Error;
        }

        if (delivery.Value.Status == DirectDelivery.DirectDeliveryStatus.Delivered)
        {
            return DirectDeliveryDomainError.DeliveryCompleted;
        }
        
        var addResult = delivery.Value.AddOkb(request.OkbNo);

        if (addResult.IsFailure)
        {
            return addResult;
        }

        return await _directDeliveryRepository.UpdateDirectDeliveryAsync(delivery.Value, cancellationToken);
    }
}

