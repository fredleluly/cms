using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.PartDelivery.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record CheckOkbForDeliveryUseCase(string OkbNo) : IRequest<Result<OKB>>, IAuthorizeSupplier;

public class CheckOkbForDeliveryUseCaseHandler : IRequestHandler<CheckOkbForDeliveryUseCase, Result<OKB>>
{
    private readonly IOKBRepository _okbRepository;
    private readonly IAuthenticationService _authenticationService;

    public CheckOkbForDeliveryUseCaseHandler(IOKBRepository okbRepository, IAuthenticationService authenticationService)
    {
        _okbRepository = okbRepository;
        _authenticationService = authenticationService;
    }

    public async Task<Result<OKB>> Handle(CheckOkbForDeliveryUseCase request, CancellationToken cancellationToken)
    {
        var okb = await _okbRepository.GetOkbByOkbNoAsync(request.OkbNo, cancellationToken);

        if (okb.IsFailure || okb.Value is null)
        {
            return okb;
        }

        var user = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        var userClaims = user.Value!;

        var userSupplierCode = userClaims
            .FirstOrDefault(claim => 
                claim.Type == ClaimType.SupplierId)?.Value;

        if (userSupplierCode != okb.Value.VendorCode)
        {
            return Result.Failure<OKB>(DirectDeliveryDomainError.OKBSupplierMismatch(request.OkbNo));
        }

        if (okb.Value.DeliveryType != DeliveryType.Direct)
            return Result.Failure<OKB>(DirectDeliveryDomainError.OKBNotFound(request.OkbNo));

        return okb;
    }
}

