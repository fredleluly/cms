using IDTrack.Application.Features.ComponentTracking.Direct;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Direct.UseCases;

public record CancelOkbFromDeliverySessionUseCase(long DeliveryId, string OkbNo) : IRequest<Result>, IAuthorizeSupplier;

public class CancelOkbFromDeliverySessionUseCaseHandler : IRequestHandler<CancelOkbFromDeliverySessionUseCase, Result>
{
    private readonly IDirectDeliveryRepository _directDeliveryRepository;

    public CancelOkbFromDeliverySessionUseCaseHandler(IDirectDeliveryRepository directDeliveryRepository)
    {
        _directDeliveryRepository = directDeliveryRepository;
    }

    public async Task<Result> Handle(CancelOkbFromDeliverySessionUseCase request, CancellationToken cancellationToken)
    {
        var delivery = await _directDeliveryRepository.GetDirectDeliveryByIdAsync(request.DeliveryId, cancellationToken);

        if (delivery.IsFailure || delivery.Value is null)
        {
            return delivery.Error;
        }

        var cancelResult = delivery.Value.CancelOkb(request.OkbNo);

        if (cancelResult.IsFailure)
        {
            return cancelResult;
        }

        return await _directDeliveryRepository.UpdateDirectDeliveryAsync(delivery.Value, cancellationToken);
    }
}
