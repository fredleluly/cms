using IDTrack.Application.Features.Auth;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record QueryDirectDeliveryHistoryUseCase() : PagingQuery, IRequest<Result<PagingResult<DirectDelivery>>>, IAuthorizeSupplier;

public class QueryDirectDeliveryHistoryUseCaseHandlers : IRequestHandler<QueryDirectDeliveryHistoryUseCase, Result<PagingResult<DirectDelivery>>>
{
    private readonly IAuthenticationService _authenticationService;

    private readonly IDirectDeliveryRepository _directDeliveryRepository;

    public QueryDirectDeliveryHistoryUseCaseHandlers(IDirectDeliveryRepository directDeliveryRepository, IAuthenticationService authenticationService)
    {
        _authenticationService = authenticationService;
        _directDeliveryRepository = directDeliveryRepository;
    }

    public async Task<Result<PagingResult<DirectDelivery>>> Handle(QueryDirectDeliveryHistoryUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();
        var userSupplierCode = claimResult.Value!.First(e => e.Type == ClaimType.SupplierId).Value;

        var qry = _directDeliveryRepository.Query();

        qry = qry.Where(e => e.SupplierCode == userSupplierCode);

        var directDeliveryList = await _directDeliveryRepository.LoadPageAsync(qry, request, cancellationToken);
        
        return directDeliveryList;
    }
}
