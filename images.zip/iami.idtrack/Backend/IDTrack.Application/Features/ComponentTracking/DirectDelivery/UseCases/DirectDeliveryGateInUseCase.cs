using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Masters.GateIn;
using IDTrack.Application.Geofencing;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record DirectDeliveryGateInUseCase(long DeliveryId, string GateInCode, string Latitude, string Longitude) : IRequest<Result>, IAuthorizeSupplier;

public class DirectDeliveryGateInUseCaseHandlers : IRequestHandler<DirectDeliveryGateInUseCase, Result>
{
    private readonly IDirectDeliveryRepository _deliveryRepository;
    private readonly IGeofencingService _geofencingService;
    private readonly IPickingGateInRepository _gateInRepository;
    private readonly IAppConfigurationService _appConfigurationService;

    private readonly IUserDeviceService _userDeviceService;

    public DirectDeliveryGateInUseCaseHandlers(
        IDirectDeliveryRepository deliveryRepository,
        IGeofencingService geofencingService,
        IPickingGateInRepository gateInRepository,
        IAppConfigurationService appConfigurationService,
        IUserDeviceService userDeviceService)
    {
        _deliveryRepository = deliveryRepository;
        _geofencingService = geofencingService;
        _gateInRepository = gateInRepository;
        _appConfigurationService = appConfigurationService;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(DirectDeliveryGateInUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var delivery = await _deliveryRepository.GetDirectDeliveryByIdAsync(request.DeliveryId, cancellationToken);

        if (delivery.IsFailure || delivery.Value is null)
        {
            return DirectDeliveryDomainError.DeliveryNotFound;
        }

        var gateInResult = await _gateInRepository.GetByTokenAsync(request.GateInCode, cancellationToken);

        if (gateInResult.IsFailure || gateInResult.Value is null)
        {
            return gateInResult.Error;
        }

        // validate if user's coordinates is within the radius of the gate in
        var geofenceEnabled = await _appConfigurationService.IsDirectDlvGeofenceEnabledAsync(cancellationToken);

        if (geofenceEnabled) 
        {
            var distanceResult = await _geofencingService.CalculateDistanceBetweenTwoPointsAsync(
                request.Latitude, 
                request.Longitude, 
                gateInResult.Value.Lat,
                gateInResult.Value.Lng);

            if (distanceResult.IsFailure)
                return distanceResult.Error;

            var maximumDistance = await _appConfigurationService.GetGeofenceRadiusInMeterAsync(cancellationToken);

            if (distanceResult.Value > maximumDistance)
                return DirectDeliveryDomainError.GateInOutsideRadius(distanceResult.Value.ToString());
        }

        delivery.Value.Complete(deviceId.Value);

        await _deliveryRepository.UpdateDirectDeliveryAsync(delivery.Value, cancellationToken);

        return Result.Success();
    }
}
