using IDTrack.Application.Features.Auth;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record GetDeliverySessionUseCase() : IRequest<Result<DirectDelivery>>, IAuthorizeSupplier;

public class GetDeliverySessionUseCaseHandler : IRequestHandler<GetDeliverySessionUseCase, Result<DirectDelivery>>
{
    private IAuthenticationService _authenticationService;
    private IDirectDeliveryRepository _directDeliveryRepository;

    public GetDeliverySessionUseCaseHandler(IAuthenticationService authenticationService, IDirectDeliveryRepository directDeliveryRepository)
    {
        _authenticationService = authenticationService;
        _directDeliveryRepository = directDeliveryRepository;
    }

    public async Task<Result<DirectDelivery>> Handle(GetDeliverySessionUseCase request, CancellationToken cancellationToken)
    {
        var userClaimsResult = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        if (userClaimsResult.IsFailure || userClaimsResult.Value is null)
        {
            return Result.Failure<DirectDelivery>(userClaimsResult.Error);
        }

        var userId = userClaimsResult.Value.First(claim => claim.Type == "sub").Value;

        var deliveryResult = await _directDeliveryRepository.GetActiveDirectDeliveryByCreatorAsync(long.Parse(userId), cancellationToken);

        if (deliveryResult.IsFailure || deliveryResult.Value is null)
        {
            return Result.Failure<DirectDelivery>(deliveryResult.Error);
        }

        return deliveryResult;
    }
}

