using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Features.Direct.Entities;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public record StartDeliveryUseCase(string SupplierCode, ICollection<string> OkbNumbers) : IRequest<Result>, IAuthorizeSupplier;

public class StartDeliveryUseCaseHandler : IRequestHandler<StartDeliveryUseCase, Result>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IOKBRepository _okbRepository;
    private readonly IDirectDeliveryRepository _directDeliveryRepository;
    private readonly IUserDeviceService _userDeviceService;

    public StartDeliveryUseCaseHandler(
        IAuthenticationService authenticationService, 
        IOKBRepository okbRepository, 
        IDirectDeliveryRepository directDeliveryRepository,
        IUserDeviceService userDeviceService)
    {
        _authenticationService = authenticationService;
        _okbRepository = okbRepository;
        _directDeliveryRepository = directDeliveryRepository;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(StartDeliveryUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var user = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        if (user.IsFailure || user.Value is null)
            return IdentityDomainError.UserIsNotAuthenticated;

        var userClaims = user.Value;

        // validate if user has the same supplier id in claims and in request
        if (!userClaims.Any(claim => 
            claim.Type == ClaimType.SupplierId && 
            claim.Value == request.SupplierCode))
        {
            return IdentityDomainError.UserIsNotAuthorized;
        }

        // validate if all OKB is from the request's supplier
        var foundOkbs = await _okbRepository.GetOKBsByListAsync(request.OkbNumbers, cancellationToken);
        var notFoundOKBs = new List<string>();
        var mismatchedOKBs = new List<string>();

        foreach (var okbNo in request.OkbNumbers)
        {
            var foundOkb = foundOkbs.FirstOrDefault(okb => okb.DnNo == okbNo);

            if (foundOkb is null)
            {
                notFoundOKBs.Add(okbNo);
                continue;
            }
            
            if (foundOkb.VendorCode != request.SupplierCode)
            {
                mismatchedOKBs.Add(okbNo);
                continue;
            }
        }

        if (notFoundOKBs.Any())
            return DirectDeliveryDomainError.OKBNotFound(string.Join(", ", notFoundOKBs));

        if (mismatchedOKBs.Any())
            return DirectDeliveryDomainError.OKBSupplierMismatch(string.Join(", ", mismatchedOKBs));

        var directDelivery = new DirectDelivery
        {
            SupplierCode = request.SupplierCode,
            DeliveryDate = DateTime.Now,
            DirectOKBs = foundOkbs.Select(okb => new DirectOKB
            {
                OkbNo = okb.DnNo
            }).ToList()
        };

        directDelivery.Start(deviceId.Value);

        return await _directDeliveryRepository.CreateDirectDeliveryAsync(directDelivery, cancellationToken);
    }
}
