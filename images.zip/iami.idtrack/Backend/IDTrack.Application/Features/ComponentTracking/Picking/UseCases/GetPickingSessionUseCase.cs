using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record GetPickingSessionUseCase() : IRequest<Result<GetPickingSessionUseCaseResult>>, IAuthorizeLogisticPartner;

public record GetPickingSessionUseCaseResult(
    long Id,
    string PickNo,
    string RouteName,
    string TransporterName,
    string? TransporterCode,
    int? CycleNo,
    DateTime PickDate,
    DateTime ArrivalDate,
    string ArrivalTime,
    DateTime? PickStartTime,
    ICollection<PickupPointDto> PickupPoints
);

public class GetPickingSessionUseCaseHandler : IRequestHandler<GetPickingSessionUseCase, Result<GetPickingSessionUseCaseResult>>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IPickingDomainService _pickingDomainService;

    public GetPickingSessionUseCaseHandler(
        IAuthenticationService authenticationService, 
        IPickingDomainService pickingDomainService)
    {
        _authenticationService = authenticationService;
        _pickingDomainService = pickingDomainService;
    }

    public async Task<Result<GetPickingSessionUseCaseResult>> Handle(GetPickingSessionUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();

        var userId = await _authenticationService.GetAuthenticatedUserIdAsync(cancellationToken);

        var pickingInstruction = await _pickingDomainService.GetActivePickingSessionByDriverIdAsync(userId.Value!, cancellationToken);

        if (pickingInstruction.Value is null)
            return Result.Failure<GetPickingSessionUseCaseResult>(pickingInstruction.Error);

        return pickingInstruction;
    }
}

