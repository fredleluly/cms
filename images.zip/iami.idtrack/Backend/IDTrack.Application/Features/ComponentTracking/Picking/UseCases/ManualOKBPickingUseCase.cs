using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Features.Picking.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record ManualOkbPickingUseCase(
    long PickingInstructionId,
    ICollection<string> Okbs,
    bool MarkAsGateIn = false
) : IRequest<BulkResult>, IAtomicTransaction;

public class ManualOkbPickingUseCaseHandler : IRequestHandler<ManualOkbPickingUseCase, BulkResult>
{
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IUnitOfWork _unitOfWork;

    public ManualOkbPickingUseCaseHandler(
        IPickupPointRepository pickupPointRepository, 
        IPickingInstructionRepository pickingInstructionRepository, 
        IUnitOfWork unitOfWork)
    {
        _pickupPointRepository = pickupPointRepository;
        _pickingInstructionRepository = pickingInstructionRepository;
        _unitOfWork = unitOfWork;
    }

    public async Task<BulkResult> Handle(ManualOkbPickingUseCase request, CancellationToken cancellationToken)
    {
        var pickingInstructionResult = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(request.PickingInstructionId, cancellationToken);
        
        if (pickingInstructionResult.IsFailure || pickingInstructionResult.Value is null)
        {
            return BulkResult.Failure(pickingInstructionResult.Error);
        }

        var pickingInstruction = pickingInstructionResult.Value;

        var pickupPointsResult = await _pickupPointRepository.GetPickupPointsByPickNoAsync(pickingInstruction.PickNo, cancellationToken);

        if (pickupPointsResult.IsFailure || pickupPointsResult.Value is null)
        {
            return BulkResult.Failure(pickupPointsResult.Error);
        }

        var pickupPoints = pickupPointsResult.Value;

        // validate not found okbs
        var foundOkbs = pickupPoints.SelectMany(p => p.OKBs).Where(okb => request.Okbs.Contains(okb.OkbNo)).ToList();
        
        if (foundOkbs.Count != request.Okbs.Count)
        {
            var notFoundOkbs = request.Okbs.Except(foundOkbs.Select(okb => okb.OkbNo)).ToList();
            return BulkResult.Failure(PickingDomainError.OKBNotFoundInPickingInstruction(string.Join(", ", notFoundOkbs)));
        }

        _pickupPointRepository.AttachPickupPoints(pickupPoints);
        foundOkbs.ForEach(okb => okb.Pick());

        var result = await _pickupPointRepository.CreateOrUpdateRangeAsync(pickupPoints, cancellationToken);

        if (result.IsFailure)
        {
            return BulkResult.Failure(result.Error);
        }

        if (request.MarkAsGateIn)
        {
            pickingInstruction.GateIn();
            await _pickingInstructionRepository.UpdatePickingInstructionAsync(pickingInstruction, cancellationToken);

            var okbToBeDelayed = pickupPoints
                .SelectMany(p => p.OKBs)
                .Except(foundOkbs)
                .Where(e => e.Status == PickupOKB.PickupOKBStatus.Unpicked)
                .ToList();

            okbToBeDelayed.ForEach(okb => okb.Delay(okb.DelayReason ?? "Marked delay by admin"));
        }

        var saveChangesResult = await _unitOfWork.SaveChangesAsync(cancellationToken);
        if (saveChangesResult.IsFailure)
            return BulkResult.Failure(saveChangesResult.Error);

        return BulkResult.Success();
    }
}

