using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Masters.GateIn;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Application.Geofencing;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record PickingGateInUseCase(
    string PickNo, 
    string GateInToken, 
    string Latitude, 
    string Longitude
) : IRequest<Result>, IAuthorizeLogisticPartner;

public class PickingGateInUseCaseHandler : IRequestHandler<PickingGateInUseCase, Result>
{
    private readonly IPickingGateInRepository _pickingGateInRepository;
    private readonly IGeofencingService _geofencingService;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IAppConfigurationService _appConfigurationService;
    private readonly PickingEventSource _evtSrc;
    private readonly IUserDeviceService _userDeviceService;

    public PickingGateInUseCaseHandler(IPickingGateInRepository pickingGateInRepository, IGeofencingService geofencingService, IPickingInstructionRepository pickingInstructionRepository, IAuthenticationService authenticationService, IAppConfigurationService appConfigurationService, PickingEventSource evtSrc, IUserDeviceService userDeviceService)
    {
        _pickingGateInRepository = pickingGateInRepository;
        _geofencingService = geofencingService;
        _pickingInstructionRepository = pickingInstructionRepository;
        _authenticationService = authenticationService;
        _appConfigurationService = appConfigurationService;
        _evtSrc = evtSrc;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(PickingGateInUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);
        // validate logistic partner
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        if (claimResult.IsFailure || claimResult.Value is null)
            return claimResult;

        var transporterCode = claimResult.Value.FirstOrDefault(e => e.Type == ClaimType.LogisticPartnerId)!.Value;

        var pickingInstruction = await _pickingInstructionRepository.GetDomainByPickNoAsync(request.PickNo, cancellationToken);

        if (pickingInstruction.IsFailure || pickingInstruction.Value is null)
            return pickingInstruction;

        if (pickingInstruction.Value.TransporterCode != transporterCode)
            return PickingDomainError.LogisticPartnerCodeMismatch;

        // validate geofence
        var globalGeofenceEnabled = await _appConfigurationService.IsPickingGeofenceEnabledAsync(cancellationToken);

        var gateInResult = await _pickingGateInRepository.GetByTokenAsync(request.GateInToken, cancellationToken);
        if (gateInResult.IsFailure || gateInResult.Value is null)
            return gateInResult;

        if (pickingInstruction.Value.GeofencingEnabled && globalGeofenceEnabled)
        {
            if (gateInResult.Value.Lat is not null && gateInResult.Value.Lng is not null)
            {
                var distance = await _geofencingService.CalculateDistanceBetweenTwoPointsAsync(
                    request.Latitude, 
                    request.Longitude, 
                    gateInResult.Value.Lat,
                    gateInResult.Value.Lng
                );

                if (distance.IsFailure)
                    return distance;

                var maxDistance = await _appConfigurationService.GetGeofenceRadiusInMeterAsync(cancellationToken);

                if (distance.Value > maxDistance)
                    return Result.Failure(PickingDomainError.DeviceIsNotInScanRadius);
            }
        }

        // gate in logic
        var result = pickingInstruction.Value.GateIn(deviceId.Value);

        if (result.IsFailure)
            return result;

        _evtSrc.SendEvent(new PickingInstructionNotification(
            pickingInstruction.Value.Id, 
            pickingInstruction.Value.PickStatus ?? 0, 
            pickingInstruction.Value.PickStartTime,
            pickingInstruction.Value.GateInTime));
        return await _pickingInstructionRepository.UpdatePickingInstructionAsync(pickingInstruction.Value, cancellationToken);
    }
}

