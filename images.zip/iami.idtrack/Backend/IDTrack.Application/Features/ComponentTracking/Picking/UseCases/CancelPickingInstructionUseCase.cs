using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record CancelPickingInstructionUseCase(string PickNo) : IRequest<Result>, IAuthorizeLogisticPartner;

public class CancelPickingInstructionUseCaseHandler : IRequestHandler<CancelPickingInstructionUseCase, Result>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly PickingEventSource _evtSource;

    public CancelPickingInstructionUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository, IPickupPointRepository pickupPointRepository, IAuthenticationService authenticationService, PickingEventSource evtSource)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _authenticationService = authenticationService;
        _evtSource = evtSource;
    }
    public async Task<Result> Handle(CancelPickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();

        var logisticPartnerCode = claimResult.Value!.First(e => e.Type == ClaimType.LogisticPartnerId).Value;

        var pickingInstructionResult = await _pickingInstructionRepository.GetDomainByPickNoAsync(request.PickNo, cancellationToken);

        if (pickingInstructionResult.Value?.TransporterCode != logisticPartnerCode)
            return Result.Failure<PickingInstruction>(pickingInstructionResult.Error);

        if (pickingInstructionResult.IsFailure || pickingInstructionResult.Value is null)
        {
            return Result.Failure<PickingInstruction>(pickingInstructionResult.Error);
        }

        if (pickingInstructionResult.Value.PickStatus > PickingInstruction.PickingStatus.InProgress)
        {
            return Result.Failure<PickingInstruction>(pickingInstructionResult.Error);
        }

        var pickPointList = await _pickupPointRepository.GetPickupPointsByPickNoAsync(pickingInstructionResult.Value.PickNo, cancellationToken);

        if (pickPointList.Value is null)
            return Result.Failure<PickingInstruction>(pickPointList.Error);

        if (await _pickupPointRepository.PickupPointsHasActivityAsync(pickingInstructionResult.Value.Id, cancellationToken))
        {
            return Result.Failure<PickupPoint>(PickingDomainError.CannotCancelPickingInstruction);
        }

        pickingInstructionResult.Value.DriverId = null;
        pickingInstructionResult.Value.PickStartTime = null;
        pickingInstructionResult.Value.PickStatus = PickingInstruction.PickingStatus.New;

        var result = await _pickingInstructionRepository.UpdatePickingInstructionAsync(pickingInstructionResult.Value, cancellationToken);

        if (result.IsSuccess)
        {
            _evtSource.SendEvent(new PickingInstructionNotification(
                pickingInstructionResult.Value.Id, (short)pickingInstructionResult.Value.PickStatus));
            return Result.Success(pickingInstructionResult.Value);
        }

        return Result.Failure(result.Error);
    }
}
