using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record StartPickingUseCase(string PickNo) : IRequest<Result>, IAuthorizeLogisticPartner;

public record StartPickingUseCaseHandler : IRequestHandler<StartPickingUseCase, Result>
{
    private readonly IAuthenticationService _authenticationService;
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly PickingEventSource _evtSrc;
    private readonly IUserDeviceService _userDeviceService;

    public StartPickingUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository, IPickupPointRepository pickupPointRepository, IAuthenticationService authenticationService, PickingEventSource evtSrc, IUserDeviceService userDeviceService)
    {
        _authenticationService = authenticationService;
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _evtSrc = evtSrc;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(StartPickingUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();

        var logisticPartnerCode = claimResult.Value!.First(e => e.Type == ClaimType.LogisticPartnerId).Value;

        var user = await _authenticationService.GetAuthenticatedUserIdAsync(cancellationToken);

        var pickingInstruction = await _pickingInstructionRepository.GetDomainByPickNoAsync(request.PickNo, cancellationToken);

        if (pickingInstruction.Value?.TransporterCode != logisticPartnerCode)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickingInstruction.Error);

        if (pickingInstruction.Value is null)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickingInstruction.Error);

        var pickPointList = await _pickupPointRepository.GetPickupPointsByPickNoAsync(request.PickNo, cancellationToken);

        if (pickPointList.Value is null || pickPointList.Value.Count == 0)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickPointList.Error);

        var result = pickingInstruction.Value.Start(user.Value!, deviceId.Value);
        if (result.IsFailure)
            return result;

        _evtSrc.SendEvent(new PickingInstructionNotification(pickingInstruction.Value.Id, pickingInstruction.Value.PickStatus ?? 0, pickingInstruction.Value.PickStartTime));
        return await _pickingInstructionRepository.UpdatePickingInstructionAsync(pickingInstruction.Value, cancellationToken);
    }
}
