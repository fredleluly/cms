using IDTrack.Application.Features.Auth;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record QueryLPPickingInstructionUseCase(
    short? Status,
    string? PickNo
) : PagingQuery, IRequest<Result<PagingResult<QueryLPPickingInstructionUseCaseResult>>>, IAuthorizeLogisticPartner;

public class QueryLPPickingInstructionUseCaseResult
{
    public required string PickNo { get; init; }
    public required string RouteCode { get; init; }
    public int? CycleNo { get; set; }
    public DateTime PickDate { get; init; }
    public required string TransporterCode { get; init; }
    public int TotalPickupPoint { get; set; }
    public int TotalOkb { get; set; }
    public required string RouteName { get; set; }
    public short? Status { get; set; }
    public string? GRNo { get; set; }
};

public class QueryLPPickingInstructionUseCaseHandler : IRequestHandler<QueryLPPickingInstructionUseCase, Result<PagingResult<QueryLPPickingInstructionUseCaseResult>>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    private readonly IAuthenticationService _authenticationService;

    public QueryLPPickingInstructionUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository, IAuthenticationService authenticationService)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _authenticationService = authenticationService;
    }

    public async Task<Result<PagingResult<QueryLPPickingInstructionUseCaseResult>>> Handle(QueryLPPickingInstructionUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();

        var logisticPartnerCode = claimResult.Value!.First(e => e.Type == ClaimType.LogisticPartnerId).Value;

        var pickingInstructionList = await _pickingInstructionRepository.QueryLPPickingInstructionAsync(request, logisticPartnerCode, cancellationToken);

        return pickingInstructionList;
    }
}
