using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Domain.Features.Picking.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record CompletePickupPointUseCase(
    long PickupPointId,
    string? DelayReason = null
) : IRequest<Result>, IAuthorizeLogisticPartner;

public class CompletePickupPointUseCaseHandler : IRequestHandler<CompletePickupPointUseCase, Result>
{
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly PickingEventSource _evtSrc;
    private readonly IUserDeviceService _userDeviceService;

    public CompletePickupPointUseCaseHandler(IPickupPointRepository pickupPointRepository, PickingEventSource evtSrc, IUserDeviceService userDeviceService)
    {
        _pickupPointRepository = pickupPointRepository;
        _evtSrc = evtSrc;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(CompletePickupPointUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var pickupPointResult = await _pickupPointRepository
            .GetPickupPointByIdAsync(request.PickupPointId, cancellationToken);

        if (pickupPointResult.IsFailure || pickupPointResult.Value is null)
            return pickupPointResult;

        var pickupPoint = pickupPointResult.Value;

        if (request.DelayReason is not null)
            pickupPoint.DelayRestOfOKB(request.DelayReason, deviceId.Value);

        var result = pickupPoint.Complete(deviceId.Value);

        if (result.IsFailure)
            return result;

        _evtSrc.SendEvent(new PickupPointNotification(
            pickupPoint.Id,
            pickupPoint.Status,
            pickupPoint.OKBs
                .Where(e => e.Status == PickupOKB.PickupOKBStatus.Delayed)
                .Select(e => e.OkbNo)
                .ToList()));
        return await _pickupPointRepository.UpdatePickupPointAsync(pickupPoint, cancellationToken);
    }
}

