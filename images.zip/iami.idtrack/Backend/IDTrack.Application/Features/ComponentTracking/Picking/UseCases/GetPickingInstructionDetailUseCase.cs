using IDTrack.Application.Features.Auth;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record GetPickingInstructionDetailUseCase(string PickNo) : IRequest<Result<GetPickingInstructionDetailUseCaseResult>>, IAuthorizeLogisticPartner;

public record GetPickingInstructionDetailUseCaseResult(
    long Id,
    string PickNo,
    string RouteName,
    string TransporterName,
    string? TransporterCode,
    int? CycleNo,
    DateTime PickDate,
    DateTime ArrivalDate,
    string ArrivalTime,
    short Status,
    string? GRNo,
    ICollection<PickupPointDto> PickupPoints
);

public record PickupPointDto(
    long Id,
    string? SupplierName,
    string? SupplierAddress,
    ICollection<PickupOKBDto> OKBs,
    int? PickStatus = null,
    string? Latitude = null,
    string? Longitude = null
);

public record PickupOKBDto(
    string OkbNo,
    int Status,
    bool IsAdvanced
);

public class GetPickingInstructionDetailUseCaseHandler : IRequestHandler<GetPickingInstructionDetailUseCase, Result<GetPickingInstructionDetailUseCaseResult>>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;

    private readonly IPickupPointRepository _pickupPointRepository;

    private readonly IAuthenticationService _authenticationService;

    public GetPickingInstructionDetailUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository, IPickupPointRepository pickupPointRepository, IAuthenticationService authenticationService)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _authenticationService = authenticationService;
    }

    public async Task<Result<GetPickingInstructionDetailUseCaseResult>> Handle(GetPickingInstructionDetailUseCase request, CancellationToken cancellationToken)
    {
        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();

        var logisticPartnerCode = claimResult.Value!.First(e => e.Type == ClaimType.LogisticPartnerId).Value;

        var pickingInstruction = await _pickingInstructionRepository.GetPickingInstructionByPickNoAsync(request.PickNo, cancellationToken);

        if (pickingInstruction.Value?.TransporterCode != logisticPartnerCode)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickingInstruction.Error);

        if (pickingInstruction.Value is null)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickingInstruction.Error);

        var pickPointList = await _pickupPointRepository.GetPickupPointsByPickNoAsync(request.PickNo, cancellationToken);

        if (pickPointList.Value is null)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(pickPointList.Error);

        var result = new GetPickingInstructionDetailUseCaseResult(
            pickingInstruction.Value.Id,
            pickingInstruction.Value.PickNo,
            pickingInstruction.Value.RouteName,
            pickingInstruction.Value.TransporterName,
            pickingInstruction.Value.TransporterCode,
            pickingInstruction.Value.CycleNo,
            pickingInstruction.Value.PickDate,
            pickingInstruction.Value.ArrivalDate,
            pickingInstruction.Value.ArrivalTime,
            pickingInstruction.Value.Status,
            pickingInstruction.Value.GRNo,
            pickPointList.Value
                .Select(p => new PickupPointDto(
                    p.Id,
                    p.Supplier?.VendorName,
                    p.Supplier?.Address,
                    p.OKBs
                        .Select(okb => new PickupOKBDto(
                            okb.OkbNo,
                            okb.Status,
                            okb.IsAdvanced)
                        ).ToList(),
                    p.Status,
                    p.Supplier?.Lat,
                    p.Supplier?.Lng)
                ).ToList()
            );

        return Result.Success(result);
    }
}
