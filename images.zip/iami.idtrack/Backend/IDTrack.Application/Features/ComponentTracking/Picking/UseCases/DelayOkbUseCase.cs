using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record DelayOkbUseCase(long PickupPointId, string Reason) : IRequest<Result>;
