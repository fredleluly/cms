using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Features.Monitoring;
using IDTrack.Application.Geofencing;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.ComponentTracking.Picking.UseCases;

public record ScanPickingOkbUseCase(
    long PickupPointId,
    string OkbNo,
    string Latitude,
    string Longitude
) : IRequest<Result>, IAuthorizeLogisticPartner, IAtomicTransaction;

public class ScanPickingOkbUseCaseHandler : IRequestHandler<ScanPickingOkbUseCase, Result>
{
    private readonly IPickingInstructionRepository _pickingInstructionRepository;
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IAuthenticationService _authenticationService;
    private readonly IPartSupplierRepository _partSupplierRepository;
    private readonly IGeofencingService _geofencingService;
    private readonly IAppConfigurationService _appConfigurationService;
    private readonly PickingEventSource _pickingEventSource;
    private readonly IUserDeviceService _userDeviceService;

    public ScanPickingOkbUseCaseHandler(IPickingInstructionRepository pickingInstructionRepository, IPickupPointRepository pickupPointRepository, IAuthenticationService authenticationService, IPartSupplierRepository partSupplierRepository, IGeofencingService geofencingService, IAppConfigurationService appConfigurationService, PickingEventSource pickingEventSource, IUserDeviceService userDeviceService)
    {
        _pickingInstructionRepository = pickingInstructionRepository;
        _pickupPointRepository = pickupPointRepository;
        _authenticationService = authenticationService;
        _partSupplierRepository = partSupplierRepository;
        _geofencingService = geofencingService;
        _appConfigurationService = appConfigurationService;
        _pickingEventSource = pickingEventSource;
        _userDeviceService = userDeviceService;
    }

    public async Task<Result> Handle(ScanPickingOkbUseCase request, CancellationToken cancellationToken)
    {
        var deviceId = await _userDeviceService.GetUserDeviceIdfromHeadersAsync(cancellationToken);

        var claimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync();
        var logisticPartnerCode = claimResult.Value!.First(e => e.Type == ClaimType.LogisticPartnerId).Value;

        var pickupPointResult = await _pickupPointRepository.GetPickupPointByIdAsync(request.PickupPointId, cancellationToken);

        if (pickupPointResult.IsFailure || pickupPointResult.Value is null)
        {
            return pickupPointResult;
        }

        var pickupPoint = pickupPointResult.Value;

        // picking logic
        var result = pickupPoint.PickOkb(request.OkbNo, deviceId.Value);

        if (result.IsFailure)
            return result;

        // validate radius
        var pickingInstructionResult = await _pickingInstructionRepository.GetPickingInstructionByIdAsync(pickupPoint.PickingInstructionId, cancellationToken);
        if (pickingInstructionResult.IsFailure || pickingInstructionResult.Value is null)
            return pickingInstructionResult;

        var globalGeofenceEnabled = await _appConfigurationService.IsPickingGeofenceEnabledAsync(cancellationToken);

        if (pickingInstructionResult.Value.GeofencingEnabled && globalGeofenceEnabled)
        {
            var vendorResult = await _partSupplierRepository.GetByCodeAsync(pickupPoint.VendorCode, cancellationToken);
            if (vendorResult.IsFailure || vendorResult.Value is null)
                return vendorResult;

            if (vendorResult.Value.Lat is not null && vendorResult.Value.Lng is not null)
            {
                var distance = await _geofencingService.CalculateDistanceBetweenTwoPointsAsync(
                    request.Latitude,
                    request.Longitude,
                    vendorResult.Value.Lat,
                    vendorResult.Value.Lng
                );

                if (distance.IsFailure)
                    return distance;

                var maxDistance = await _appConfigurationService.GetGeofenceRadiusInMeterAsync(cancellationToken);

                if (distance.Value > maxDistance)
                    return Result.Failure(PickingDomainError.DeviceIsNotInScanRadius);
            }
        }

        var updateResult = await _pickupPointRepository.UpdatePickupPointAsync(pickupPoint, cancellationToken);

        if (updateResult.IsSuccess)
            _pickingEventSource.SendEvent(new OKBScannedNotification(pickupPoint.Id, pickupPoint.PickingInstructionId, request.OkbNo));

        return result;
    }
}
