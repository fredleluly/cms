namespace IDTrack.Application.Features.ComponentTracking.Picking;

public interface IAuthorizeLogisticPartner{}
