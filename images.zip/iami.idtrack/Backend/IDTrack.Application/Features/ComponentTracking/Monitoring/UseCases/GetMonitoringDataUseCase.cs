using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Monitoring.UseCases;

public record GetMonitoringDataUseCase(
    DateOnly ArrivalDate
) : IRequest<Result<ICollection<GetMonitoringDataUseCaseResult>>>, IAuthorizeAdmin;

public class GetMonitoringDataUseCaseResult : PickingInstruction
{
    public ICollection<PickupPoint> PickupPoints { get; set; } = new List<PickupPoint>();
}

public class GetMonitoringDataUseCaseHandler : IRequestHandler<GetMonitoringDataUseCase, Result<ICollection<GetMonitoringDataUseCaseResult>>>
{
    private readonly IPickingDomainService _pickingDomainService;

    public GetMonitoringDataUseCaseHandler(IPickingDomainService pickingDomainService)
    {
        _pickingDomainService = pickingDomainService;
    }

    public async Task<Result<ICollection<GetMonitoringDataUseCaseResult>>> Handle(GetMonitoringDataUseCase request, CancellationToken cancellationToken)
    {
        return await _pickingDomainService.GetMonitoringDataAsync(request, cancellationToken);
    }
}

