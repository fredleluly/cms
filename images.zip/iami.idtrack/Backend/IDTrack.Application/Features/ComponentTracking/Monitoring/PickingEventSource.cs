using MediatR;

namespace IDTrack.Application.Features.Monitoring;

public record OKBScannedNotification(
    long PickupPointId,
    long PickingInstructionId,
    string OkbNo
) : INotification
{
    public string EventType { get; } = "okb_scanned";
}

public record PickupPointNotification(
    long PickupPointId,
    int Status,
    ICollection<string>? DelayedOkbs = null
) : INotification
{
    public string EventType { get; } = "pickup_point";
}

public record PickingInstructionNotification(
    long PickingInstructionId,
    int Status,
    DateTime? PickStartTime = null,
    DateTime? GateInTime = null
) : INotification
{
    public string EventType { get; } = "picking_instruction";
}

public class PickingEventSource
{
    private List<TaskCompletionSource<INotification>> _tcs = new List<TaskCompletionSource<INotification>>();
    private object _lock = new object();

    public void SendEvent(INotification notification)
    {
        lock(_lock) 
        {
            foreach (var tcs in _tcs.ToList())
            {
                if (!tcs.TrySetResult(notification))
                {
                    _tcs.Remove(tcs);
                }
            }
        }
    }

    public async Task<INotification> WaitForEventAsync(TaskCompletionSource<INotification> tcs, int timeoutInMinute, CancellationToken ct)
    {
        var cancellationTask = Task.Delay(TimeSpan.FromMinutes(timeoutInMinute), ct);

        try 
        { 
            using (ct.Register(() => {
                lock (_lock) {
                    tcs.TrySetCanceled();
                    _tcs.Remove(tcs);
                }
            }))
            {
                var completedTask = await Task.WhenAny(tcs.Task, cancellationTask);

                if (completedTask == cancellationTask)
                {
                    throw new OperationCanceledException(ct);
                }

                var result = await tcs.Task;

                lock (_lock)
                    _tcs.Remove(tcs);

                return result;
            }
        } 
        finally 
        {
            lock (_lock)
                _tcs.Remove(tcs);
        }
    }

    public void AddTaskCompletionSource(TaskCompletionSource<INotification> tcs)
    {
        lock (_lock)
            _tcs.Add(tcs);
    }
}
