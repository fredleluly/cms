using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Transporter.UseCase;

// Request validator
public class CreatePickingTransporterUseCaseValidator : AbstractValidator<CreatePickingTransporterUseCase>
{
    public CreatePickingTransporterUseCaseValidator()
    {
        RuleFor(x => x.TransporterCode)
            .NotEmpty()
            .WithMessage("Transporter Code cannot be empty")
            .MaximumLength(10)
            .WithMessage("Transporter Name cannot be more than 10 characters");

        RuleFor(x => x.TransporterName)
            .NotEmpty()
            .WithMessage("Transporter Name cannot be empty")
            .MaximumLength(50)
            .WithMessage("Transporter Name cannot be more than 50 characters");

        RuleFor(x => x.TransporterDesc100)
            .MaximumLength(100)
            .WithMessage("Transporter Name cannot be more than 100 characters");

        RuleFor(x => x.Address)
            .MaximumLength(150)
            .WithMessage("Address cannot be more than 150 characters");

        RuleFor(x => x.City)
            .MaximumLength(60)
            .WithMessage("City cannot be more than 60 characters");

        RuleFor(x => x.PostalCode)
            .MaximumLength(10)
            .WithMessage("Postal Code cannot be more than 10 characters")
            .Matches(@"^\d*$")
            .WithMessage("Postal Code must contain only digits");

        RuleFor(x => x.RegionCode)
            .MaximumLength(5)
            .WithMessage("Region Code cannot be more than 5 characters");

        RuleFor(x => x.CountryCode)
            .MaximumLength(5)
            .WithMessage("Country Code cannot be more than 5 characters");

        RuleFor(x => x.ContactName)
            .MaximumLength(60)
            .WithMessage("Contact Name cannot be more than 60 characters");

        RuleFor(x => x.PhoneNo1)
            .MaximumLength(30)
            .WithMessage("Phone Number 1 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Phone Number 1 must contain only digits");

        RuleFor(x => x.PhoneNo2)
            .MaximumLength(30)
            .WithMessage("Phone Number 2 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Phone Number 2 must contain only digits");

        RuleFor(x => x.FaxNo1)
            .MaximumLength(30)
            .WithMessage("Fax Number 1 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Fax Number 1 must contain only digits");

        RuleFor(x => x.FaxNo2)
            .MaximumLength(30)
            .WithMessage("Fax Number 2 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Fax Number 2 must contain only digits");

        RuleFor(x => x.Email)
            .NotEmpty()
            .WithMessage("Email cannot be empty")
            .MaximumLength(500)
            .WithMessage("Email cannot be more than 500 characters")
            .Matches(@"^([\w\.\-]+@[\w\-]+\.[a-zA-Z]{2,})(;[\w\.\-]+@[\w\-]+\.[a-zA-Z]{2,})*$")
            .WithMessage("Each email must be a valid email address and separated by a semicolon (;)");


        RuleFor(x => x.TaxCode)
            .MaximumLength(30)
            .WithMessage("Tax Code cannot be more than 30 characters");

        RuleFor(x => x.VendorDesc100)
            .MaximumLength(100)
            .WithMessage("Vendor Description cannot be more than 100 characters");

        RuleFor(x => x.VendorType)
            .MaximumLength(5)
            .WithMessage("Vendor Type cannot be more than 5 characters");
    }
}

// Request
public record CreatePickingTransporterUseCase(
    string TransporterCode,
    string TransporterName,
    string? TransporterDesc100,
    string? Address,
    string? City,
    string? PostalCode,
    string? RegionCode,
    string? CountryCode,
    string? ContactName,
    string? PhoneNo1,
    string? PhoneNo2,
    string? FaxNo1,
    string? FaxNo2,
    string? Email,
    string? TaxCode,
    string? VendorDesc100,
    string? VendorType
) : IRequest<Result<PickingTransporter>>, IAuthorizeAdmin;

// Handler
public class CreatePickingTransporterUseCaseHandler : IRequestHandler<CreatePickingTransporterUseCase, Result<PickingTransporter>>
{
    private readonly IPickingTransporterRepository _TransporterRepository;

    public CreatePickingTransporterUseCaseHandler(IPickingTransporterRepository TransporterRepository)
    {
        _TransporterRepository = TransporterRepository;
    }

    public async Task<Result<PickingTransporter>> Handle(CreatePickingTransporterUseCase request, CancellationToken cancellationToken)
    {
        var transporter = new PickingTransporter
        {
            TransporterCode = request.TransporterCode,
            TransporterName = request.TransporterName,
            TransporterDesc100 = request.TransporterDesc100,
            Address = request.Address,
            City = request.City,
            PostalCode = request.PostalCode,
            RegionCode = request.RegionCode,
            CountryCode = request.CountryCode,
            ContactName = request.ContactName,
            PhoneNo1 = request.PhoneNo1,
            PhoneNo2 = request.PhoneNo2,
            FaxNo1 = request.FaxNo1,
            FaxNo2 = request.FaxNo2,
            Email = request.Email,
            TaxCode = request.TaxCode,
            VendorDesc100 = request.VendorDesc100,
            VendorType = request.VendorType
        };

        var result = await _TransporterRepository.AddAsync(transporter, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(transporter);

        return Result.Failure<PickingTransporter>(result.Error);
    }
}
