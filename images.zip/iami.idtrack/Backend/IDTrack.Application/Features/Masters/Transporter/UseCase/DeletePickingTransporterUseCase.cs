using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Transporter.UseCase;

// Request
public record DeletePickingTransporterUseCase(
    int Id
) : IRequest<Result<PickingTransporter>>, IAuthorizeAdmin;

// Handler
public class DeletePickingTransporterUseCaseHandler : IRequestHandler<DeletePickingTransporterUseCase, Result<PickingTransporter>>
{
    private readonly IPickingTransporterRepository _transporterRepository;
    private readonly IPickingInstructionRepository _instructionRepository;

    public DeletePickingTransporterUseCaseHandler(
        IPickingTransporterRepository transporterRepository, 
        IPickingInstructionRepository instructionRepository)
    {
        _transporterRepository = transporterRepository;
        _instructionRepository = instructionRepository;
    }

    public async Task<Result<PickingTransporter>> Handle(DeletePickingTransporterUseCase request, CancellationToken cancellationToken)
    {
        var transporter = await _transporterRepository.GetByIdAsync(request.Id, cancellationToken);

        if (transporter.IsFailure || transporter.Value is null)
            return Result.Failure<PickingTransporter>(transporter.Error);

        if (await _instructionRepository.PickingExistsAsync(transporter.Value.TransporterCode, null, cancellationToken))
            return Result.Failure<PickingTransporter>(PickingTransporterDomainError.CannotDeletePickingTransporterWithTransactionData);

        var result = await _transporterRepository.DeleteAsync(transporter.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(transporter.Value);

        return Result.Failure<PickingTransporter>(result.Error);
    }
}
