using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Transporter.UseCase;

// Request
public record QueryPickingTransporterUseCase(
    string? TransporterCode = null,
    string? TransporterName = null
) : PagingQuery, IRequest<Result<PagingResult<PickingTransporter>>>, IAuthorizeAdmin;

// Handler
public class QueryPickingTransporterUseCaseHandler : IRequestHandler<QueryPickingTransporterUseCase, Result<PagingResult<PickingTransporter>>>
{
    private readonly IPickingTransporterRepository _transporterRepository;

    public QueryPickingTransporterUseCaseHandler(IPickingTransporterRepository transporterRepository)
    {
        _transporterRepository = transporterRepository;
    }

    public async Task<Result<PagingResult<PickingTransporter>>> Handle(QueryPickingTransporterUseCase request, CancellationToken cancellationToken)
    {
        var query = _transporterRepository.Query();

        var predicate = PredicateBuilder.True<PickingTransporter>();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            predicate = predicate.And(x => x.TransporterCode.Contains(request.Search) || x.TransporterName.Contains(request.Search));
        }

        if (!string.IsNullOrWhiteSpace(request.TransporterCode))
        {
            predicate = predicate.And(x => x.TransporterCode.Contains(request.TransporterCode));
        }

        if (!string.IsNullOrWhiteSpace(request.TransporterName))
        {
            predicate = predicate.And(x => x.TransporterName.Contains(request.TransporterName));
        }

        query = query.Where(predicate);

        return await _transporterRepository.LoadPageAsync(query, request, cancellationToken);
    }
}
