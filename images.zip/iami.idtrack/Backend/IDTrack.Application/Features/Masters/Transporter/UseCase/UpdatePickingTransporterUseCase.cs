using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Transporter.UseCase;

// Request validator
public class UpdatePickingTransporterUseCaseValidator : AbstractValidator<UpdatePickingTransporterUseCase>
{
    public UpdatePickingTransporterUseCaseValidator()
    {
        RuleFor(x => x.TransporterCode)
            .NotEmpty()
            .WithMessage("Transporter Code cannot be empty")
            .MaximumLength(10)
            .WithMessage("Transporter Name cannot be more than 10 characters");

        RuleFor(x => x.TransporterName)
            .NotEmpty()
            .WithMessage("Transporter Name cannot be empty")
            .MaximumLength(50)
            .WithMessage("Transporter Name cannot be more than 50 characters");

        RuleFor(x => x.TransporterDesc100)
            .MaximumLength(100)
            .WithMessage("Transporter Name cannot be more than 100 characters");

        RuleFor(x => x.Address)
            .MaximumLength(150)
            .WithMessage("Address cannot be more than 150 characters");

        RuleFor(x => x.City)
            .MaximumLength(60)
            .WithMessage("City cannot be more than 60 characters");

        RuleFor(x => x.PostalCode)
            .MaximumLength(10)
            .WithMessage("Postal Code cannot be more than 10 characters")
            .Matches(@"^\d*$")
            .WithMessage("Postal Code must contain only digits");

        RuleFor(x => x.RegionCode)
            .MaximumLength(5)
            .WithMessage("Region Code cannot be more than 5 characters");

        RuleFor(x => x.CountryCode)
            .MaximumLength(5)
            .WithMessage("Country Code cannot be more than 5 characters");

        RuleFor(x => x.ContactName)
            .MaximumLength(60)
            .WithMessage("Contact Name cannot be more than 60 characters");

        RuleFor(x => x.PhoneNo1)
            .MaximumLength(30)
            .WithMessage("Phone Number 1 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Phone Number 1 must contain only digits");

        RuleFor(x => x.PhoneNo2)
            .MaximumLength(30)
            .WithMessage("Phone Number 2 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Phone Number 2 must contain only digits");

        RuleFor(x => x.FaxNo1)
            .MaximumLength(30)
            .WithMessage("Fax Number 1 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Fax Number 1 must contain only digits");

        RuleFor(x => x.FaxNo2)
            .MaximumLength(30)
            .WithMessage("Fax Number 2 cannot be more than 30 characters")
            .Matches(@"^\d*$")
            .WithMessage("Fax Number 2 must contain only digits");

        RuleFor(x => x.Email)
            .NotEmpty()
            .WithMessage("Email cannot be empty")
            .MaximumLength(500)
            .WithMessage("Email cannot be more than 500 characters")
            .Matches(@"^([\w\.\-]+@[\w\-]+\.[a-zA-Z]{2,})(;[\w\.\-]+@[\w\-]+\.[a-zA-Z]{2,})*$")
            .WithMessage("Each email must be a valid email address and separated by a semicolon (;)");

        RuleFor(x => x.TaxCode)
            .MaximumLength(30)
            .WithMessage("Tax Code cannot be more than 30 characters");

        RuleFor(x => x.VendorDesc100)
            .MaximumLength(100)
            .WithMessage("Vendor Description cannot be more than 100 characters");

        RuleFor(x => x.VendorType)
            .MaximumLength(5)
            .WithMessage("Vendor Type cannot be more than 5 characters");
    }
}

// Request
public record UpdatePickingTransporterUseCase(
    int Id,
    string TransporterCode,
    string TransporterName,
    string? TransporterDesc100 = null,
    string? Address = null,
    string? City = null,
    string? PostalCode = null,
    string? RegionCode = null,
    string? CountryCode = null,
    string? ContactName = null,
    string? PhoneNo1 = null,
    string? PhoneNo2 = null,
    string? FaxNo1 = null,
    string? FaxNo2 = null,
    string? Email = null,
    string? TaxCode = null,
    string? VendorDesc100 = null,
    string? VendorType = null
) : IRequest<Result<PickingTransporter>>, IAuthorizeAdmin;

// Handler
public class UpdatePickingTransporterUseCaseHandler : IRequestHandler<UpdatePickingTransporterUseCase, Result<PickingTransporter>>
{
    private readonly IPickingTransporterRepository _transporterRepository;

    public UpdatePickingTransporterUseCaseHandler(IPickingTransporterRepository transporterRepository)
    {
        _transporterRepository = transporterRepository;
    }

    public async Task<Result<PickingTransporter>> Handle(UpdatePickingTransporterUseCase request, CancellationToken cancellationToken)
    {
        var transporter = await _transporterRepository.GetByIdAsync(request.Id, cancellationToken);

        if (transporter.IsFailure || transporter.Value is null)
            return Result.Failure<PickingTransporter>(transporter.Error);

        transporter.Value.TransporterCode = request.TransporterCode;
        transporter.Value.TransporterName = request.TransporterName;
        transporter.Value.TransporterDesc100 = request.TransporterDesc100;
        transporter.Value.Address = request.Address;
        transporter.Value.City = request.City;
        transporter.Value.PostalCode = request.PostalCode;
        transporter.Value.RegionCode = request.RegionCode;
        transporter.Value.CountryCode = request.CountryCode;
        transporter.Value.ContactName = request.ContactName;
        transporter.Value.PhoneNo1 = request.PhoneNo1;
        transporter.Value.PhoneNo2 = request.PhoneNo2;
        transporter.Value.FaxNo1 = request.FaxNo1;
        transporter.Value.FaxNo2 = request.FaxNo2;
        transporter.Value.Email = request.Email;
        transporter.Value.TaxCode = request.TaxCode;
        transporter.Value.VendorDesc100 = request.VendorDesc100;
        transporter.Value.VendorType = request.VendorType;

        var result = await _transporterRepository.UpdateAsync(transporter.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(transporter.Value);

        return Result.Failure<PickingTransporter>(result.Error);
    }
}
