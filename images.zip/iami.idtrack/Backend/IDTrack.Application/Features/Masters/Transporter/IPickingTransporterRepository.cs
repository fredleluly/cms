using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.Transporter;

public interface IPickingTransporterRepository : IPagingService<PickingTransporter>
{
    public Task<Result<PickingTransporter>> AddAsync(PickingTransporter Transporter, CancellationToken ct);
    public Task<Result<PickingTransporter>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PickingTransporter>> UpdateAsync(PickingTransporter Transporter, CancellationToken ct);
    public Task<Result<PickingTransporter>> DeleteAsync(long id, CancellationToken ct);
    public Task<Result<PickingTransporter>> GetByTransporterCodeAsync(string transporterCode, CancellationToken ct);
}
