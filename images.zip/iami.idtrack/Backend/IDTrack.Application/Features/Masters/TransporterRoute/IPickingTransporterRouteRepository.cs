using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.TransporterRoute;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.TransporterRoute;

public interface IPickingTransporterRouteRepository : IPagingService<PickingTransporterRoute>
{
    public Task<Result<PickingTransporterRoute>> AddAsync(PickingTransporterRoute Transporter, CancellationToken ct);
    public Task<Result<PickingTransporterRoute>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PickingTransporterRoute>> UpdateAsync(PickingTransporterRoute Transporter, CancellationToken ct);
    public Task<Result<PickingTransporterRoute>> DeleteAsync(long id, CancellationToken ct);
}
