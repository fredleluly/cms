using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Masters.TransporterRoute;
using IDTrack.Domain.Features.Masters.TransporterRoute.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.TransporterRoute.UseCase;

// Request validator
public class CreatePickingTransporterRouteUseCaseValidator : AbstractValidator<CreatePickingTransporterRouteUseCase>
{
    public CreatePickingTransporterRouteUseCaseValidator()
    {
        RuleFor(x => x.TransporterId)
            .NotEmpty()
            .WithMessage("Transporter Id cannot be empty");

        RuleFor(x => x.RouteId)
            .NotEmpty()
            .WithMessage("Route Id cannot be empty");
            
        RuleFor(x => x.Cycles)
            .NotEmpty()
            .WithMessage("Please insert cycle(s)")
            .ForEach(x => x.SetValidator(new CreateCycleDtoValidator()));
    }
}

public class CreateCycleDtoValidator : AbstractValidator<CreateCycleDto>
{
    public CreateCycleDtoValidator()
    {
        RuleFor(x => x.ArrivalPlan)
            .NotEmpty()
            .WithMessage("Arrival plan cannot be empty.")
            .Must(x => TimeOnly.TryParseExact(x, "HH:mm", out _))
            .WithMessage("Invalid time.");

        RuleFor(x => x.DeparturePlan)
            .NotEmpty()
            .WithMessage("Departure plan cannot be empty.")
            .Must(x => TimeOnly.TryParseExact(x, "HH:mm", out _))
            .WithMessage("Invalid time.");
    }
}

// Request
public record CreateCycleDto(string DeparturePlan, string ArrivalPlan);

public record CreatePickingTransporterRouteUseCase(
    long TransporterId,
    long RouteId,
    ICollection<CreateCycleDto> Cycles
) : IRequest<Result<PickingTransporterRoute>>, IAuthorizeAdmin;

// Handler
public class CreatePickingTransporterRouteUseCaseHandler : IRequestHandler<CreatePickingTransporterRouteUseCase, Result<PickingTransporterRoute>>
{
    private readonly IPickingTransporterRouteRepository _repository;

    public CreatePickingTransporterRouteUseCaseHandler(IPickingTransporterRouteRepository repository)
    {
        _repository = repository;
    }

    public async Task<Result<PickingTransporterRoute>> Handle(CreatePickingTransporterRouteUseCase request, CancellationToken cancellationToken)
    {
        var entity = new PickingTransporterRoute
        {
            PickingRouteId = request.RouteId,
            PickingTransporterId = request.TransporterId,
        };

        entity.UpdateCycle(request.Cycles.Select(c => new Cycle
        {
            DeparturePlan = TimeOnly.ParseExact(c.DeparturePlan, "HH:mm"),
            ArrivalPlan = TimeOnly.ParseExact(c.ArrivalPlan, "HH:mm")
        }).ToList());

        var result = await _repository.AddAsync(entity, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(entity);

        return Result.Failure<PickingTransporterRoute>(result.Error);
    }
}
