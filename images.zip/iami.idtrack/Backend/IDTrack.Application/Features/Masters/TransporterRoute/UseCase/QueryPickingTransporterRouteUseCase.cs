using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.TransporterRoute;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.TransporterRoute.UseCase;

// Request
public record QueryPickingTransporterRouteUseCase(
    string? TransporterCode = null,
    string? TransporterName = null,
    string? RouteCode = null,
    string? RouteName = null
) : PagingQuery, IRequest<Result<PagingResult<PickingTransporterRoute>>>, IAuthorizeAdmin;

// Handler
public class QueryPickingTransporterRouteUseCaseHandler : IRequestHandler<QueryPickingTransporterRouteUseCase, Result<PagingResult<PickingTransporterRoute>>>
{
    private readonly IPickingTransporterRouteRepository _transporterRouteRepo;

    public QueryPickingTransporterRouteUseCaseHandler(IPickingTransporterRouteRepository transporterRepository)
    {
        _transporterRouteRepo = transporterRepository;
    }

    public async Task<Result<PagingResult<PickingTransporterRoute>>> Handle(QueryPickingTransporterRouteUseCase request, CancellationToken cancellationToken)
    {
        var transporterRoutePredicate = PredicateBuilder.True<PickingTransporterRoute>();

        if (!string.IsNullOrWhiteSpace(request.TransporterCode))
            transporterRoutePredicate = transporterRoutePredicate.And(e => e.Transporter!.TransporterCode.Contains(request.TransporterCode));

        if (!string.IsNullOrWhiteSpace(request.TransporterName))
            transporterRoutePredicate = transporterRoutePredicate.And(e => e.Transporter!.TransporterName.Contains(request.TransporterName));

        if (!string.IsNullOrWhiteSpace(request.RouteCode))
            transporterRoutePredicate = transporterRoutePredicate.And(e => e.Route!.RouteCode.Contains(request.RouteCode));

        if (!string.IsNullOrWhiteSpace(request.RouteName))
            transporterRoutePredicate = transporterRoutePredicate.And(e => e.Route!.RouteName.Contains(request.RouteName));

        var query = _transporterRouteRepo
            .Query()
            .Where(transporterRoutePredicate);


        return await _transporterRouteRepo.LoadPageAsync(query, request, cancellationToken);
    }
}
