using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Masters.TransporterRoute;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.TransporterRoute.UseCase;

// Request
public record DeletePickingTransporterRouteUseCase(
    int Id
) : IRequest<Result<PickingTransporterRoute>>, IAuthorizeAdmin;

// Handler
public class DeletePickingTransporterRouteUseCaseHandler : IRequestHandler<DeletePickingTransporterRouteUseCase, Result<PickingTransporterRoute>>
{
    private readonly IPickingTransporterRouteRepository _transporterRouteRepository;
    private readonly IPickingInstructionRepository _instructionRepository;

    public DeletePickingTransporterRouteUseCaseHandler(
        IPickingTransporterRouteRepository transporterRouteRepository, 
        IPickingInstructionRepository instructionRepository)
    {
        _transporterRouteRepository = transporterRouteRepository;
        _instructionRepository = instructionRepository;
    }

    public async Task<Result<PickingTransporterRoute>> Handle(DeletePickingTransporterRouteUseCase request, CancellationToken cancellationToken)
    {
        var transporterRoute = await _transporterRouteRepository.GetByIdAsync(request.Id, cancellationToken);

        if (transporterRoute.IsFailure || transporterRoute.Value is null)
            return Result.Failure<PickingTransporterRoute>(transporterRoute.Error);

        if (await _instructionRepository.PickingExistsAsync(transporterRoute.Value.PickingTransporterId, transporterRoute.Value.PickingRouteId, cancellationToken))
            return Result.Failure<PickingTransporterRoute>(PickingTransporterRouteDomainError.CannotDeletePickingTransporterRouteWithTransactionData);

        var result = await _transporterRouteRepository.DeleteAsync(transporterRoute.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(transporterRoute.Value);

        return Result.Failure<PickingTransporterRoute>(result.Error);
    }
}
