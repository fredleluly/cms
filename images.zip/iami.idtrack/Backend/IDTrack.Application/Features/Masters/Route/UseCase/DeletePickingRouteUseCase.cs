using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Route.UseCase;

// Request
public record DeletePickingRouteUseCase(
    int Id
) : IRequest<Result<PickingRoute>>, IAuthorizeAdmin;

// Handler
public class DeletePickingRouteUseCaseHandler : IRequestHandler<DeletePickingRouteUseCase, Result<PickingRoute>>
{
    private readonly IPickingRouteRepository _routeRepository;
    private readonly IPickingInstructionRepository _instructionRepository;

    public DeletePickingRouteUseCaseHandler(
        IPickingRouteRepository routeRepository, 
        IPickingInstructionRepository instructionRepository)
    {
        _routeRepository = routeRepository;
        _instructionRepository = instructionRepository;
    }

    public async Task<Result<PickingRoute>> Handle(DeletePickingRouteUseCase request, CancellationToken cancellationToken)
    {
        var route = await _routeRepository.GetByIdAsync(request.Id, cancellationToken);

        if (route.IsFailure || route.Value is null)
            return Result.Failure<PickingRoute>(route.Error);

        if (await _instructionRepository.PickingExistsAsync(null, route.Value.RouteCode, cancellationToken))
            return Result.Failure<PickingRoute>(PickingRouteDomainError.CannotDeletePickingRouteWithTransactionData);

        var result = await _routeRepository.DeleteAsync(route.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(route.Value);

        return Result.Failure<PickingRoute>(result.Error);
    }
}
