using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Route.UseCase;

// Request
public record QueryPickingRouteUseCase(
    string? RouteCode = null,
    string? RouteName = null
) : PagingQuery, IRequest<Result<PagingResult<PickingRoute>>>, IAuthorizeAdmin;

// Handler
public class QueryPickingRouteUseCaseHandler : IRequestHandler<QueryPickingRouteUseCase, Result<PagingResult<PickingRoute>>>
{
    private readonly IPickingRouteRepository _routeRepository;

    public QueryPickingRouteUseCaseHandler(IPickingRouteRepository routeRepository)
    {
        _routeRepository = routeRepository;
    }

    public async Task<Result<PagingResult<PickingRoute>>> Handle(QueryPickingRouteUseCase request, CancellationToken cancellationToken)
    {
        var query = _routeRepository.Query();

        var predicate = PredicateBuilder.True<PickingRoute>();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(request.Search) || x.RouteName.Contains(request.Search));
        }

        if (!string.IsNullOrWhiteSpace(request.RouteCode))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(request.RouteCode));
        }

        if (!string.IsNullOrWhiteSpace(request.RouteName))
        {
            predicate = predicate.And(x => x.RouteName.Contains(request.RouteName));
        }

        query = query.Where(predicate);

        return await _routeRepository.LoadPageAsync(query, request, cancellationToken);
    }
}
