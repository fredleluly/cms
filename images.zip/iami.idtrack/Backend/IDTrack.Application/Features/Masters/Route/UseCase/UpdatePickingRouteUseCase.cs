using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Route.UseCase;

// Request validator
public class UpdatePickingRouteUseCaseValidator : AbstractValidator<UpdatePickingRouteUseCase>
{
    public UpdatePickingRouteUseCaseValidator()
    {
        RuleFor(x => x.RouteCode)
            .NotEmpty()
            .WithMessage("Route Code cannot be empty")
            .MaximumLength(10)
            .WithMessage("Route Name cannot be more than 10 characters");

        RuleFor(x => x.RouteName)
            .NotEmpty()
            .WithMessage("Route Name cannot be empty")
            .MaximumLength(50)
            .WithMessage("Route Name cannot be more than 50 characters");

        RuleFor(x => x.RouteDesc100)
            .MaximumLength(100)
            .WithMessage("Route Name cannot be more than 100 characters");
    }
}

// Request
public record UpdatePickingRouteUseCase(
    int Id,
    string RouteCode,
    string RouteName,
    string? RouteDesc100 = null
) : IRequest<Result<PickingRoute>>, IAuthorizeAdmin;

// Handler
public class UpdatePickingRouteUseCaseHandler : IRequestHandler<UpdatePickingRouteUseCase, Result<PickingRoute>>
{
    private readonly IPickingRouteRepository _routeRepository;

    public UpdatePickingRouteUseCaseHandler(IPickingRouteRepository routeRepository)
    {
        _routeRepository = routeRepository;
    }

    public async Task<Result<PickingRoute>> Handle(UpdatePickingRouteUseCase request, CancellationToken cancellationToken)
    {
        var route = await _routeRepository.GetByIdAsync(request.Id, cancellationToken);

        if (route.IsFailure || route.Value is null)
            return Result.Failure<PickingRoute>(route.Error);

        route.Value.RouteCode = request.RouteCode;
        route.Value.RouteName = request.RouteName;
        route.Value.RouteDesc100 = request.RouteDesc100;

        var result = await _routeRepository.UpdateAsync(route.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(route.Value);

        return Result.Failure<PickingRoute>(result.Error);
    }
}
