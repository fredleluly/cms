using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.Route;

public interface IPickingRouteRepository : IPagingService<PickingRoute>
{
    public Task<Result<PickingRoute>> AddAsync(PickingRoute route, CancellationToken ct);
    public Task<Result<PickingRoute>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PickingRoute>> UpdateAsync(PickingRoute route, CancellationToken ct);
    public Task<Result<PickingRoute>> DeleteAsync(long id, CancellationToken ct);
    public Task<Result<PickingRoute>> GetByRouteCodeAsync(string routeCode, CancellationToken ct);
    public Task<BulkResult> CheckRouteNameExistenceAsync(IEnumerable<string> routeCodes, int startRow, CancellationToken ct);
}
