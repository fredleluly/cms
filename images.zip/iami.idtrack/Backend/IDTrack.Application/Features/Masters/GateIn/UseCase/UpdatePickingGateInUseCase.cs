using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.GateIn.UseCase;

// Request validator
public class UpdatePickingGateInUseCaseValidator : AbstractValidator<UpdatePickingGateInUseCase>
{
    public UpdatePickingGateInUseCaseValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .WithMessage("Name cannot be empty")
            .MaximumLength(30)
            .WithMessage("Name cannot be more than 30 characters");

        RuleFor(x => x.Lat)
            .MaximumLength(120)
            .WithMessage("Lat cannot be more than 120 characters")
            .Must(lat => lat != null && decimal.TryParse(lat.ToString(), out _))
            .WithMessage("Latitude must be a valid number");

        RuleFor(x => x.Lng)
            .MaximumLength(120)
            .WithMessage("Lat cannot be more than 120 characters")
            .Must(lng => lng != null && decimal.TryParse(lng.ToString(), out _))
            .WithMessage("Longitude must be a valid number");
    }
}

// Request
public record UpdatePickingGateInUseCase(
    int Id,
    string Token,
    string Name,
    string Lat,
    string Lng
) : IRequest<Result<PickingGateIn>>, IAuthorizeAdmin;

// Handler
public class UpdatePickingGateInUseCaseHandler : IRequestHandler<UpdatePickingGateInUseCase, Result<PickingGateIn>>
{
    private readonly IPickingGateInRepository _gateInRepository;

    public UpdatePickingGateInUseCaseHandler(IPickingGateInRepository gateInRepository)
    {
        _gateInRepository = gateInRepository;
    }

    public async Task<Result<PickingGateIn>> Handle(UpdatePickingGateInUseCase request, CancellationToken cancellationToken)
    {
        var gateIn = await _gateInRepository.GetByIdAsync(request.Id, cancellationToken);

        if (gateIn.IsFailure || gateIn.Value is null)
            return Result.Failure<PickingGateIn>(gateIn.Error);

        if (gateIn.Value.Name != request.Name)
        {
            var nameExistsResult = await _gateInRepository.ExistsByNameAsync(request.Name, cancellationToken);

            if (nameExistsResult.Value)
            {
                return Result.Failure<PickingGateIn>(PickingGateInDomainError.FailedToUpdatePickingGateIn("A gate-in with the same name already exists"));
            }
        }

        gateIn.Value.Token = request.Token;
        gateIn.Value.Name = request.Name;
        gateIn.Value.Lat = request.Lat;
        gateIn.Value.Lng = request.Lng;

        var result = await _gateInRepository.UpdateAsync(gateIn.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(gateIn.Value);

        return Result.Failure<PickingGateIn>(result.Error);
    }
}
