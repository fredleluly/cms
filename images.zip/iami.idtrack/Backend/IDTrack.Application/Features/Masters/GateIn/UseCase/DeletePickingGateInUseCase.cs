using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.GateIn.UseCase;

// Request
public record DeletePickingGateInUseCase(
    int Id
) : IRequest<Result<PickingGateIn>>, IAuthorizeAdmin;

// Handler
public class DeletePickingGateInUseCaseHandler : IRequestHandler<DeletePickingGateInUseCase, Result<PickingGateIn>>
{
    private readonly IPickingGateInRepository _gateInRepository;

    public DeletePickingGateInUseCaseHandler(IPickingGateInRepository gateInRepository)
    {
        _gateInRepository = gateInRepository;
    }

    public async Task<Result<PickingGateIn>> Handle(DeletePickingGateInUseCase request, CancellationToken cancellationToken)
    {
        var gateIn = await _gateInRepository.GetByIdAsync(request.Id, cancellationToken);

        if (gateIn.IsFailure || gateIn.Value is null)
            return Result.Failure<PickingGateIn>(gateIn.Error);

        var result = await _gateInRepository.DeleteAsync(gateIn.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(gateIn.Value);

        return Result.Failure<PickingGateIn>(result.Error);
    }
}
