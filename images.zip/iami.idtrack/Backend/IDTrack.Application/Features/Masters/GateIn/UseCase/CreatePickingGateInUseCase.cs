using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.GateIn.UseCase;

// Request validator
public class CreatePickingGateInUseCaseValidator : AbstractValidator<CreatePickingGateInUseCase>
{
    public CreatePickingGateInUseCaseValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty()
            .WithMessage("Name cannot be empty")
            .MaximumLength(30)
            .WithMessage("Name cannot be more than 30 characters");

        RuleFor(x => x.Lat)
            .MaximumLength(120)
            .WithMessage("Lat cannot be more than 120 characters")
            .Must(lat => lat != null && decimal.TryParse(lat.ToString(), out _))
            .WithMessage("Latitude must be a valid number");

        RuleFor(x => x.Lng)
            .MaximumLength(120)
            .WithMessage("Lat cannot be more than 120 characters")
            .Must(lng => lng != null && decimal.TryParse(lng.ToString(), out _))
            .WithMessage("Longitude must be a valid number");
    }
}

// Request
public record CreatePickingGateInUseCase(
    string Name,
    string Lat,
    string Lng
) : IRequest<Result<PickingGateIn>>, IAuthorizeAdmin;

// Handler
public class CreatePickingGateInUseCaseHandler : IRequestHandler<CreatePickingGateInUseCase, Result<PickingGateIn>>
{
    private readonly IPickingGateInRepository _gateInRepository;

    public CreatePickingGateInUseCaseHandler(IPickingGateInRepository gateInRepository)
    {
        _gateInRepository = gateInRepository;
    }

    public async Task<Result<PickingGateIn>> Handle(CreatePickingGateInUseCase request, CancellationToken cancellationToken)
    {
        var nameExistsResult = await _gateInRepository.ExistsByNameAsync(request.Name, cancellationToken);

        if (nameExistsResult.Value)
        {
            return Result.Failure<PickingGateIn>(PickingGateInDomainError.GateInNameAlreadyExist);
        }

        var gateIn = new PickingGateIn
        {
            Token = Guid.NewGuid().ToString(),
            Name = request.Name,
            Lat = request.Lat,
            Lng = request.Lng
        };

        var result = await _gateInRepository.AddAsync(gateIn, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(gateIn);

        return Result.Failure<PickingGateIn>(result.Error);
    }
}
