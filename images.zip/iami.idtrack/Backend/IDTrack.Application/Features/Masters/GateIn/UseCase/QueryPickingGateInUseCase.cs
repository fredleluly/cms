using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.GateIn.UseCase;

// Request
public record QueryPickingGateInUseCase() : PagingQuery, IRequest<Result<PagingResult<PickingGateIn>>>, IAuthorizeAdmin;

// Handler
public class QueryPickingGateInUseCaseHandler : IRequestHandler<QueryPickingGateInUseCase, Result<PagingResult<PickingGateIn>>>
{
    private readonly IPickingGateInRepository _gateInRepository;

    public QueryPickingGateInUseCaseHandler(IPickingGateInRepository gateInRepository)
    {
        _gateInRepository = gateInRepository;
    }

    public async Task<Result<PagingResult<PickingGateIn>>> Handle(QueryPickingGateInUseCase request, CancellationToken cancellationToken)
    {
        var query = _gateInRepository.Query();

        var predicate = PredicateBuilder.True<PickingGateIn>();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            predicate = predicate.And(x => x.Token.Contains(request.Search) || x.Name.Contains(request.Search));
        }

        query = query.Where(predicate);

        return await _gateInRepository.LoadPageAsync(query, request, cancellationToken);
    }
}
