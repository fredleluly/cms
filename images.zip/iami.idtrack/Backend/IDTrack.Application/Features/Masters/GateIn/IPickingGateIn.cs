using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.GateIn;

public interface IPickingGateInRepository : IPagingService<PickingGateIn>
{
    public Task<Result<PickingGateIn>> AddAsync(PickingGateIn gateIn, CancellationToken ct);
    public Task<Result<PickingGateIn>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PickingGateIn>> GetByTokenAsync(string token, CancellationToken ct);
    public Task<Result<PickingGateIn>> UpdateAsync(PickingGateIn gateIn, CancellationToken ct);
    public Task<Result<PickingGateIn>> DeleteAsync(long id, CancellationToken ct);
    public Task<Result<bool>> ExistsByNameAsync(string name, CancellationToken cancellationToken);
}
