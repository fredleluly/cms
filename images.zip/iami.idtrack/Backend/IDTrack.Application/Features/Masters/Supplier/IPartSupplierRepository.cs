using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Supplier;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.Supplier;

public interface IPartSupplierRepository : IPagingService<PartSupplier>
{
    public Task<Result<PartSupplier>> AddAsync(PartSupplier supplier, CancellationToken ct);
    public Task<Result<PartSupplier>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PartSupplier>> UpdateAsync(PartSupplier supplier, CancellationToken ct);
    public Task<Result<PartSupplier>> DeleteAsync(long id, CancellationToken ct);
    public Task<Result<PartSupplier>> GetByCodeAsync(string code, CancellationToken ct);

    public Task<PagingResult<T>> LoadPageAsync<T>(
        IQueryable<T> query,
        PagingQuery page,
        CancellationToken ct) where T : class;
}
