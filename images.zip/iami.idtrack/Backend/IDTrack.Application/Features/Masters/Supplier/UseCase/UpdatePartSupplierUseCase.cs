using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Domain.Features.Masters.Supplier;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Supplier.UseCase;

// Request validator
public class UpdatePartSupplierUseCaseValidator : AbstractValidator<UpdatePartSupplierUseCase>
{
    public UpdatePartSupplierUseCaseValidator()
    {
        RuleFor(x => x.Lat)
            .MaximumLength(120)
            .WithMessage("Latitude cannot be more than 120 characters");

        RuleFor(x => x.Lng)
            .MaximumLength(120)
            .WithMessage("Longitude cannot be more than 120 characters");
    }
}

// Request
public record UpdatePartSupplierUseCase(
    int Id,
    string? Lat = null,
    string? Lng = null
) : IRequest<Result<PartSupplier>>, IAuthorizeAdmin;

// Handler
public class UpdatePartSupplierUseCaseHandler : IRequestHandler<UpdatePartSupplierUseCase, Result<PartSupplier>>
{
    private readonly IPartSupplierRepository _supplierRepository;

    public UpdatePartSupplierUseCaseHandler(IPartSupplierRepository supplierRepository)
    {
        _supplierRepository = supplierRepository;
    }

    public async Task<Result<PartSupplier>> Handle(UpdatePartSupplierUseCase request, CancellationToken cancellationToken)
    {
        var supplier = await _supplierRepository.GetByIdAsync(request.Id, cancellationToken);

        if (supplier.IsFailure || supplier.Value is null)
            return Result.Failure<PartSupplier>(supplier.Error);

        supplier.Value.Lat = request.Lat;
        supplier.Value.Lng = request.Lng;

        var result = await _supplierRepository.UpdateAsync(supplier.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(supplier.Value);

        return Result.Failure<PartSupplier>(result.Error);
    }
}
