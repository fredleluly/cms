using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Features.Masters.Supplier;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.Supplier.UseCase;

// Request
public record QueryPartSupplierUseCase(
    string? VendorCode = null,
    string? VendorName = null,
    string? City = null,
    string? PostalCode = null,
    string? RegionCode = null,
    string? CountryCode = null
) : PagingQuery, IRequest<Result<PagingResult<PartSupplier>>>, IAuthorizeAdmin;

// Handler
public class QueryPartSupplierUseCaseHandler : IRequestHandler<QueryPartSupplierUseCase, Result<PagingResult<PartSupplier>>>
{
    private readonly IPartSupplierRepository _supplierRepository;
    private readonly IAuthenticationService _authenticationService;

    public QueryPartSupplierUseCaseHandler(IPartSupplierRepository supplierRepository, IAuthenticationService authenticationService)
    {
        _supplierRepository = supplierRepository;
        _authenticationService = authenticationService;
    }

    public async Task<Result<PagingResult<PartSupplier>>> Handle(QueryPartSupplierUseCase request, CancellationToken cancellationToken)
    {
        var query = _supplierRepository.Query();

        var userClaimResult = await _authenticationService.GetAuthenticatedUserClaimsAsync(cancellationToken);

        var userClaim = userClaimResult.Value!;

        if (!userClaim.Any(x => x.Type == ClaimType.Role && x.Value.ToLower() == RoleNames.Admin))
        {
            var vendorCode = userClaim.First(x => x.Type == ClaimType.SupplierId).Value;

            query = query.Where(x => x.VendorCode == vendorCode);
            return Result.Success(await _supplierRepository.LoadPageAsync(query, request, cancellationToken));
        }

        var predicate = PredicateBuilder.True<PartSupplier>();

        if (!string.IsNullOrWhiteSpace(request.Search))
        {
            predicate = predicate.And(x => x.VendorCode.Contains(request.Search) || x.VendorName != null && x.VendorName.Contains(request.Search));
        }

        if (!string.IsNullOrWhiteSpace(request.VendorCode))
        {
            predicate = predicate.And(x => x.VendorCode.Contains(request.VendorCode));
        }

        if (!string.IsNullOrWhiteSpace(request.VendorName))
        {
            predicate = predicate.And(x => x.VendorName != null && x.VendorName.Contains(request.VendorName));
        }

        if (!string.IsNullOrWhiteSpace(request.City))
        {
            predicate = predicate.And(x => x.City != null && x.City.Contains(request.City));
        }

        if (!string.IsNullOrWhiteSpace(request.PostalCode))
        {
            predicate = predicate.And(x => x.PostalCode != null && x.PostalCode.Contains(request.PostalCode));
        }

        if (!string.IsNullOrWhiteSpace(request.RegionCode))
        {
            predicate = predicate.And(x => x.RegionCode != null && x.RegionCode.Contains(request.RegionCode));
        }

        if (!string.IsNullOrWhiteSpace(request.CountryCode))
        {
            predicate = predicate.And(x => x.CountryCode != null && x.CountryCode.Contains(request.CountryCode));
        }

        query = query.Where(predicate);

        return Result.Success(await _supplierRepository.LoadPageAsync(query, request, cancellationToken));
    }
}
