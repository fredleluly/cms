using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.CapacityFactor;

public interface ICapacityFactorByVariantDomainService
{
    public Task<BulkResult<ICollection<CapacityFactorByVariant>>> ReadCapacityFactorsFromExcelAsync(Stream file, CancellationToken cancellationToken);
    public Task<BulkResult<ICollection<CapacityFactorByVariant>>> ReadCapacityFactorsFromExcelAsync(Stream file, Func<CapacityFactorByVariant, ICollection<Error>>? validate, CancellationToken cancellationToken);
    public Task<Stream> DownloadTruckCapacityFactorTemplateAsync(CancellationToken cancellationToken);
}
