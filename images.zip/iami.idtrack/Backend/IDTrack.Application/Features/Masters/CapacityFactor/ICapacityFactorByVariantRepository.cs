using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.CapacityFactor;

public interface ICapacityFactorByVariantRepository : IPagingService<CapacityFactorByVariant>
{
    public Task<Result<CapacityFactorByVariant>> AddAsync(CapacityFactorByVariant capacityFactor, CancellationToken ct);
    public Task<Result<CapacityFactorByVariant>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<CapacityFactorByVariant>> UpdateAsync(CapacityFactorByVariant capacityFactor, CancellationToken ct);
    public Task<Result<CapacityFactorByVariant>> DeleteAsync(long id, CancellationToken ct);
    public Task<HashSet<Tuple<string, string>>> GetAllMtVariantKeysAsync(CancellationToken ct);
    public Task<BulkResult> MergeBulkAsync(IEnumerable<CapacityFactorByVariant> capacityFactors, CancellationToken ct);
}
