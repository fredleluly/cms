using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.CapacityFactor;

public interface ICapacityFactorByPartDomainService
{
    public Task<BulkResult<ICollection<CapacityFactorByPart>>> ReadRouteCapacityFromExcelAsync(Stream file, CancellationToken cancellationToken);
    public Task<BulkResult<ICollection<CapacityFactorByPart>>> ReadRouteCapacityFromExcelAsync(Stream file, Func<CapacityFactorByPart, ICollection<Error>>? validate, CancellationToken cancellationToken);
    public Task<Stream> DownloadTemplateAsync(CancellationToken cancellationToken);
}
