using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

// Request validator
public class UpdateCapacityFactorByPartUseCaseValidator : AbstractValidator<UpdateCapacityFactorByPartUseCase>
{
    public UpdateCapacityFactorByPartUseCaseValidator()
    {
        RuleFor(e => e.Id)
            .NotEmpty()
            .WithMessage("Id cannot be empty");

        RuleFor(e => e.RouteCode)
            .NotEmpty()
            .WithMessage("RouteCode cannot be empty.")
            .MaximumLength(10)
            .WithMessage("RouteCode cannot exceed 10 characters.");

        RuleFor(e => e.PartNo)
            .NotEmpty()
            .WithMessage("PartNo cannot be empty.")
            .MaximumLength(50)
            .WithMessage("PartNo cannot exceed 50 characters.");

        RuleFor(e => e.CapacityFactor)
            .NotNull()
            .WithMessage("CapacityFactor cannot be null.")
            .GreaterThanOrEqualTo(0)
            .WithMessage("CapacityFactor must be greater than or equal to zero.");
    }
}

// Request
public record UpdateCapacityFactorByPartUseCase(
    long Id,
    string RouteCode,
    string PartNo,
    decimal CapacityFactor
) : IRequest<Result<CapacityFactorByPart>>, IAuthorizeAdmin;

// Handler
public class UpdateCapacityFactorByPartUseCaseHandler : IRequestHandler<UpdateCapacityFactorByPartUseCase, Result<CapacityFactorByPart>>
{
    private readonly ICapacityFactorByPartRepository _capacityFactorRepository;

    public UpdateCapacityFactorByPartUseCaseHandler(ICapacityFactorByPartRepository routeCapacityRepository)
    {
        _capacityFactorRepository = routeCapacityRepository;
    }

    public async Task<Result<CapacityFactorByPart>> Handle(UpdateCapacityFactorByPartUseCase request, CancellationToken cancellationToken)
    {
        var routeCapacity = await _capacityFactorRepository.GetByIdAsync(request.Id, cancellationToken);

        if (routeCapacity.IsFailure || routeCapacity.Value is null)
            return Result.Failure<CapacityFactorByPart>(routeCapacity.Error);

        routeCapacity.Value.CapacityFactor = request.CapacityFactor;

        routeCapacity.Value.PartNo = request.PartNo;

        routeCapacity.Value.RouteCode = request.RouteCode;

        var result = await _capacityFactorRepository.UpdateAsync(routeCapacity.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(routeCapacity.Value);

        return Result.Failure<CapacityFactorByPart>(result.Error);
    }
}
