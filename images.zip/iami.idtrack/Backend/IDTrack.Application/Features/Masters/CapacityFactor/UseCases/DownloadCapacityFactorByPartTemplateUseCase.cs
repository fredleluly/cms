using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

public record DownloadCapacityFactorByPartTemplateUseCase() : IRequest<Stream>, IAuthorizeAdmin;

public class DownloadCapacityFactorByPartTemplateUseCaseHandler : IRequestHandler<DownloadCapacityFactorByPartTemplateUseCase, Stream>
{
    private readonly ICapacityFactorByPartDomainService _routePartCapacityDomainService;

    public DownloadCapacityFactorByPartTemplateUseCaseHandler(ICapacityFactorByPartDomainService routePartCapacityDomainService)
    {
        _routePartCapacityDomainService = routePartCapacityDomainService;
    }

    public async Task<Stream> Handle(DownloadCapacityFactorByPartTemplateUseCase request, CancellationToken cancellationToken)
    {
        var stream = await _routePartCapacityDomainService.DownloadTemplateAsync(cancellationToken);

        stream.Position = 0;
        return stream;
    }
}
