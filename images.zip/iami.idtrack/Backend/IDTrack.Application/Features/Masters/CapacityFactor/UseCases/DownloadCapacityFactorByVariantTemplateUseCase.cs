using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using MediatR;

namespace IDTrack.Application.Features.CapacityFactor.UseCase;

public record DownloadCapacityFactorByVariantTemplateUseCase() : IRequest<Stream>, IAuthorizeAdmin;

public class DownloadCapacityFactorByVariantTemplateUseCaseHandler : IRequestHandler<DownloadCapacityFactorByVariantTemplateUseCase, Stream>
{
    private readonly ICapacityFactorByVariantDomainService _truckCapacityFactorDomainService;

    public DownloadCapacityFactorByVariantTemplateUseCaseHandler(ICapacityFactorByVariantDomainService truckCapacityFactorDomainService)
    {
        _truckCapacityFactorDomainService = truckCapacityFactorDomainService;
    }

    public async Task<Stream> Handle(DownloadCapacityFactorByVariantTemplateUseCase request, CancellationToken cancellationToken)
    {
        var stream = await _truckCapacityFactorDomainService.DownloadTruckCapacityFactorTemplateAsync(cancellationToken);

        stream.Position = 0;
        return stream;
    }
}

