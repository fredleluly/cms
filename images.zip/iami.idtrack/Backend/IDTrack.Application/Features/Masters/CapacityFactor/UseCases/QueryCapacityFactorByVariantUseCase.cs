using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCase;

// Request
public record QueryCapacityFactorByVariantUseCase(
    string? Katashiki = null,
    string? Suffix = null,
    string? RouteCode = null
) : PagingQuery, IRequest<Result<PagingResult<CapacityFactorByVariant>>>, IAuthorizeAdmin;

// Handler
public class QueryCapacityFactorByVariantUseCaseHandler : IRequestHandler<QueryCapacityFactorByVariantUseCase, Result<PagingResult<CapacityFactorByVariant>>>
{
    private readonly ICapacityFactorByVariantRepository _repository;

    public QueryCapacityFactorByVariantUseCaseHandler(ICapacityFactorByVariantRepository capacityFactorRepository)
    {
        _repository = capacityFactorRepository;
    }

    public async Task<Result<PagingResult<CapacityFactorByVariant>>> Handle(QueryCapacityFactorByVariantUseCase request, CancellationToken cancellationToken)
    {
        var query = _repository.Query();

        var predicate = PredicateBuilder.True<CapacityFactorByVariant>();

        if (!string.IsNullOrWhiteSpace(request.Katashiki))
        {
            predicate = predicate.And(x => x.Katashiki.Contains(request.Katashiki));
        }

        if (!string.IsNullOrWhiteSpace(request.Suffix))
        {
            predicate = predicate.And(x => x.Suffix.Contains(request.Suffix));
        }

        if (!string.IsNullOrWhiteSpace(request.RouteCode))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(request.RouteCode));
        }

        query = query.Where(predicate);

        return await _repository.LoadPageAsync(query, request, cancellationToken);
    }
}
