using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

// Request
public record QueryCapacityFactorByPartUseCase(
    string? RouteCode = null,
    string? PartNo = null,
    decimal? CapacityFactor = null
) : PagingQuery, IRequest<Result<PagingResult<CapacityFactorByPart>>>, IAuthorizeAdmin;

// Handler
public class QueryCapacityFactorByPartUseCaseHandler : IRequestHandler<QueryCapacityFactorByPartUseCase, Result<PagingResult<CapacityFactorByPart>>>
{
    private readonly ICapacityFactorByPartRepository _repository;

    public QueryCapacityFactorByPartUseCaseHandler(ICapacityFactorByPartRepository routeCapacityRepository)
    {
        _repository = routeCapacityRepository;
    }

    public async Task<Result<PagingResult<CapacityFactorByPart>>> Handle(QueryCapacityFactorByPartUseCase request, CancellationToken cancellationToken)
    {
        var query = _repository.Query();

        var predicate = PredicateBuilder.True<CapacityFactorByPart>();

        if (!string.IsNullOrWhiteSpace(request.RouteCode))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(request.RouteCode));
        }

        if (!string.IsNullOrWhiteSpace(request.PartNo))
        {
            predicate = predicate.And(x => x.PartNo.Contains(request.PartNo));
        }

        if (request.CapacityFactor.HasValue)
        {
            predicate = predicate.And(x => x.CapacityFactor == request.CapacityFactor.Value);
        }

        query = query.Where(predicate);

        return await _repository.LoadPageAsync(query, request, cancellationToken);
    }
}
