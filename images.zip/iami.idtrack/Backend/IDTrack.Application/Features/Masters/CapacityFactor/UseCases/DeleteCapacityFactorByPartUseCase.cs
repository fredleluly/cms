using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

// Request
public record DeleteCapacityFactorByPartUseCase(
    int Id
) : IRequest<Result<CapacityFactorByPart>>, IAuthorizeAdmin;

// Handler
public class DeleteCapacityFactorByPartUseCaseHandler : IRequestHandler<DeleteCapacityFactorByPartUseCase, Result<CapacityFactorByPart>>
{
    private readonly ICapacityFactorByPartRepository _repository;

    public DeleteCapacityFactorByPartUseCaseHandler(ICapacityFactorByPartRepository routeCapacityRepository)
    {
        _repository = routeCapacityRepository;
    }

    public async Task<Result<CapacityFactorByPart>> Handle(DeleteCapacityFactorByPartUseCase request, CancellationToken cancellationToken)
    {
        var routeCapacity = await _repository.GetByIdAsync(request.Id, cancellationToken);

        if (routeCapacity.IsFailure || routeCapacity.Value is null)
            return Result.Failure<CapacityFactorByPart>(routeCapacity.Error);

        var result = await _repository.DeleteAsync(routeCapacity.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(routeCapacity.Value);

        return Result.Failure<CapacityFactorByPart>(result.Error);
    }
}
