using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Application.Features.Masters.Route;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCase;

public class UploadCapacityFactorByVariantUseCase : IRequest<BulkResult>, IAuthorizeAdmin
{
    public required IFormFile File { get; set; }
}

public class UploadCapacityFactorByVariantUseCaseHandler : IRequestHandler<UploadCapacityFactorByVariantUseCase, BulkResult>
{
    private readonly ICapacityFactorByVariantDomainService _capacityFactorDomainService;
    private readonly ICapacityFactorByVariantRepository _capacityFactorRepository;
    private readonly IPickingRouteRepository _pickingRouteRepository;

    public UploadCapacityFactorByVariantUseCaseHandler(
        ICapacityFactorByVariantDomainService capacityFactorDomainService, 
        ICapacityFactorByVariantRepository capacityFactorRepository, 
        IPickingRouteRepository pickingRouteRepository)
    {
        _capacityFactorDomainService = capacityFactorDomainService;
        _capacityFactorRepository = capacityFactorRepository;
        _pickingRouteRepository = pickingRouteRepository;
    }

    public async Task<BulkResult> Handle(UploadCapacityFactorByVariantUseCase request, CancellationToken cancellationToken)
    {
        var validator = new CreateCapacityFactorByVariantUseCaseValidator();

        var allRoutes = (await _pickingRouteRepository.LoadPageAsync(_pickingRouteRepository.Query(), new PagingQuery(1, int.MaxValue), cancellationToken))
            .Rows
            .Select(e => e.RouteCode)
            .ToHashSet();

        var allVariant = await _capacityFactorRepository.GetAllMtVariantKeysAsync(cancellationToken);

        var nonExistingVariant = new HashSet<Tuple<string, string>>();
        var nonExistingRoute = new HashSet<string>();

        var result = await _capacityFactorDomainService
            .ReadCapacityFactorsFromExcelAsync(
                request.File.OpenReadStream(), 
                (cf) => {
                    ICollection<Error> errors = new List<Error>();

                    validator
                        .Validate(CreateCapacityFactorByVariantUseCase.FromDomain(cf))
                        .Errors
                        .ToList()
                        .ForEach(e => errors.Add(new Error(e.ErrorCode, e.ErrorMessage)));

                    if (!allRoutes.Any(e => e == cf.RouteCode) && !nonExistingRoute.Any(e => e == cf.RouteCode))
                    {
                        errors.Add(PickingRouteDomainError.PickingRouteNotFound(cf.RouteCode));
                        nonExistingRoute.Add(cf.RouteCode);
                    }

                    if (!allVariant.Any(e => e.Item1 == cf.Katashiki && e.Item2 == cf.Suffix) &&
                        !nonExistingVariant.Any(e => e.Item1 == cf.Katashiki && e.Item2 == cf.Suffix) 
                    )
                    {
                        errors.Add(CapacityFactorByVariantDomainError.VariantNotFound(cf.Katashiki, cf.Suffix));
                        nonExistingVariant.Add(new Tuple<string, string>(cf.Katashiki, cf.Suffix));
                    }

                    return errors;
                },
                cancellationToken);

        if (result.IsFailure || result.Value is null)
            return result;

        var routeCheckResult = await _pickingRouteRepository
            .CheckRouteNameExistenceAsync(
                result.Value.GroupBy(e => e.RouteCode).Select(x => x.Key), 
                3,
                cancellationToken);

        if (routeCheckResult.IsFailure)
            return routeCheckResult;

        var capacityFactors = result.Value;
        var insertResult = await _capacityFactorRepository.MergeBulkAsync(capacityFactors, cancellationToken);

        return result;
    }
}
