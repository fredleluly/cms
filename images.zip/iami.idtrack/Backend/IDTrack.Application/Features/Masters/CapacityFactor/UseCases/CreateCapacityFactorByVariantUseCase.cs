using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCase;

// Request validator
public class CreateCapacityFactorByVariantUseCaseValidator : AbstractValidator<CreateCapacityFactorByVariantUseCase>
{
    public CreateCapacityFactorByVariantUseCaseValidator()
    {
        RuleFor(x => x.Suffix)
            .NotEmpty()
            .WithMessage("Suffix cannot be empty")
            .MaximumLength(2)
            .WithMessage("Suffix cannot be more than 2 characters");

        RuleFor(x => x.Katashiki)
            .NotEmpty()
            .WithMessage("Katashiki cannot be empty")
            .MaximumLength(20)
            .WithMessage("Katashiki cannot be more than 20 characters");

        RuleFor(x => x.RouteCode)
            .NotEmpty()
            .WithMessage("Route Code cannot be empty")
            .MaximumLength(10)
            .WithMessage("Route Code cannot be more than 10 characters");

        RuleFor(e => e.CapacityFactorInPercentage)
            .NotEmpty()
            .WithMessage("Capacity Factor cannot be empty")
            .Must(capacityFactor => decimal.TryParse(capacityFactor.ToString(), out _))
            .WithMessage("Capacity Factor must be a valid number")
            .GreaterThan(0)
            .WithMessage("Capacity Factor must be greater than 0%.")
            .LessThanOrEqualTo(100)
            .WithMessage("Capacity Factor must be less than or equal 100%.");
    }
}

// Request
public record CreateCapacityFactorByVariantUseCase(
    string Suffix,
    string Katashiki,
    string RouteCode,
    decimal CapacityFactorInPercentage
) : IRequest<Result<CapacityFactorByVariant>>, IAuthorizeAdmin
{
    public static CreateCapacityFactorByVariantUseCase FromDomain(CapacityFactorByVariant capacityFactor)
    {
        return new CreateCapacityFactorByVariantUseCase(
            capacityFactor.Suffix,
            capacityFactor.Katashiki,
            capacityFactor.RouteCode,
            capacityFactor.CapacityFactorInPercentage
        );
    }
}

// Handler
public class CreateTruckCapacityFactorUseCaseHandler : IRequestHandler<CreateCapacityFactorByVariantUseCase, Result<CapacityFactorByVariant>>
{
    private readonly ICapacityFactorByVariantRepository _repository;

    public CreateTruckCapacityFactorUseCaseHandler(ICapacityFactorByVariantRepository capacityFactorRepository)
    {
        _repository = capacityFactorRepository;
    }

    public async Task<Result<CapacityFactorByVariant>> Handle(CreateCapacityFactorByVariantUseCase request, CancellationToken cancellationToken)
    {
        var capacityFactor = new CapacityFactorByVariant
        {
            Suffix = request.Suffix,
            Katashiki = request.Katashiki,
            RouteCode = request.RouteCode,
            CapacityFactorInPercentage = request.CapacityFactorInPercentage
        };

        var result = await _repository.AddAsync(capacityFactor, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(capacityFactor);

        return Result.Failure<CapacityFactorByVariant>(result.Error);
    }
}
