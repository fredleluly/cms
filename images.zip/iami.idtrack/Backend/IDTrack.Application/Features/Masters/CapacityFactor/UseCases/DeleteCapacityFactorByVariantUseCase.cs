using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCase;

// Request
public record DeleteCapacityFactorByVariantUseCase(
    int Id
) : IRequest<Result<CapacityFactorByVariant>>, IAuthorizeAdmin;

// Handler
public class DeleteCapacityFactorByVariantUseCaseHandler : IRequestHandler<DeleteCapacityFactorByVariantUseCase, Result<CapacityFactorByVariant>>
{
    private readonly ICapacityFactorByVariantRepository _repository;

    public DeleteCapacityFactorByVariantUseCaseHandler(ICapacityFactorByVariantRepository capacityFactorRepository)
    {
        _repository = capacityFactorRepository;
    }

    public async Task<Result<CapacityFactorByVariant>> Handle(DeleteCapacityFactorByVariantUseCase request, CancellationToken cancellationToken)
    {
        var capacityFactor = await _repository.GetByIdAsync(request.Id, cancellationToken);

        if (capacityFactor.IsFailure || capacityFactor.Value is null)
            return Result.Failure<CapacityFactorByVariant>(capacityFactor.Error);

        var result = await _repository.DeleteAsync(capacityFactor.Value.Id, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(capacityFactor.Value);

        return Result.Failure<CapacityFactorByVariant>(result.Error);
    }
}
