using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

// Request validator
public class CreateCapacityFactorByPartUseCaseValidator : AbstractValidator<CreateCapacityFactorByPartUseCase>
{
    public CreateCapacityFactorByPartUseCaseValidator()
    {
        RuleFor(e => e.RouteCode)
            .NotEmpty()
            .WithMessage("RouteCode cannot be empty.")
            .MaximumLength(10)
            .WithMessage("RouteCode cannot exceed 10 characters.");

        RuleFor(e => e.PartNo)
            .NotEmpty()
            .WithMessage("PartNo cannot be empty.")
            .MaximumLength(50)
            .WithMessage("PartNo cannot exceed 50 characters.");

        RuleFor(e => e.CapacityFactor)
            .NotNull()
            .WithMessage("CapacityFactor cannot be null.")
            .GreaterThanOrEqualTo(0)
            .WithMessage("CapacityFactor must be greater than or equal to zero.");
    }
}

// Request
public record CreateCapacityFactorByPartUseCase(
    string RouteCode,
    string PartNo,
    decimal CapacityFactor
) : IRequest<Result<CapacityFactorByPart>>, IAuthorizeAdmin
{
    public static CreateCapacityFactorByPartUseCase FromDomain(CapacityFactorByPart routeCapacity)
    {
        return new CreateCapacityFactorByPartUseCase(
            routeCapacity.RouteCode,
            routeCapacity.PartNo,
            routeCapacity.CapacityFactor
        );
    }
}

// Handler
public class CreateCapacityFactorByPartUseCaseHandler : IRequestHandler<CreateCapacityFactorByPartUseCase, Result<CapacityFactorByPart>>
{
    private readonly ICapacityFactorByPartRepository _repository;

    public CreateCapacityFactorByPartUseCaseHandler(ICapacityFactorByPartRepository routeCapacityRepository)
    {
        _repository = routeCapacityRepository;
    }

    public async Task<Result<CapacityFactorByPart>> Handle(CreateCapacityFactorByPartUseCase request, CancellationToken cancellationToken)
    {
        var capacityFactor = new CapacityFactorByPart
        {
            RouteCode = request.RouteCode,
            PartNo = request.PartNo,
            CapacityFactor = request.CapacityFactor
        };

        var result = await _repository.AddAsync(capacityFactor, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(capacityFactor);

        return Result.Failure<CapacityFactorByPart>(result.Error);
    }
}
