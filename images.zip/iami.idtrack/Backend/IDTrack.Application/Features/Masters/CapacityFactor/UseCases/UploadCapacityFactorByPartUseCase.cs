using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Application.Features.Masters.Route;
using IDTrack.Domain.Models;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCases;

public class UploadCapacityFactorByPartUseCase : IRequest<BulkResult>, IAuthorizeAdmin
{
    public required IFormFile File { get; set; }
}

public class UploadCapacityFactorByPartUseCaseHandler : IRequestHandler<UploadCapacityFactorByPartUseCase, BulkResult>
{
    private readonly ICapacityFactorByPartDomainService _routeCapacityDomainService;
    private readonly ICapacityFactorByPartRepository _routeCapacityRepository;
    private readonly IPickingRouteRepository _pickingRouteRepository;

    public UploadCapacityFactorByPartUseCaseHandler(
        ICapacityFactorByPartDomainService routeCapacityDomainService,
        ICapacityFactorByPartRepository routeCapacityRepository,
        IPickingRouteRepository pickingRouteRepository)
    {
        _routeCapacityDomainService = routeCapacityDomainService;
        _routeCapacityRepository = routeCapacityRepository;
        _pickingRouteRepository = pickingRouteRepository;
    }

    public async Task<BulkResult> Handle(UploadCapacityFactorByPartUseCase request, CancellationToken cancellationToken)
    {
        var validator = new CreateCapacityFactorByPartUseCaseValidator();
        var result = await _routeCapacityDomainService
            .ReadRouteCapacityFromExcelAsync(
                request.File.OpenReadStream(),
                (cf) =>
                {
                    ICollection<Error> errors = new List<Error>();

                    validator
                        .Validate(CreateCapacityFactorByPartUseCase.FromDomain(cf))
                        .Errors
                        .ToList()
                        .ForEach(e => errors.Add(new Error(e.ErrorCode, e.ErrorMessage)));

                    return errors;
                },
                cancellationToken);

        if (result.IsFailure || result.Value is null)
            return result;

        var routeCheckResult = await _pickingRouteRepository
            .CheckRouteNameExistenceAsync(
                result.Value.GroupBy(e => e.RouteCode).Select(x => x.Key),
                3,
                cancellationToken);

        if (routeCheckResult.IsFailure)
            return routeCheckResult;

        var capacityFactors = result.Value;
        var insertResult = await _routeCapacityRepository.MergeBulkAsync(capacityFactors, cancellationToken);

        return result;
    }
}
