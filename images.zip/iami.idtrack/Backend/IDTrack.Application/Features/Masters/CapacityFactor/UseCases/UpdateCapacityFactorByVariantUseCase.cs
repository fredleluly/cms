using FluentValidation;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.Masters.CapacityFactor.UseCase;

// Request validator
public class UpdateCapacityFactorByVariantUseCaseValidator : AbstractValidator<UpdateCapacityFactorByVariantUseCase>
{
    public UpdateCapacityFactorByVariantUseCaseValidator()
    {
        RuleFor(e => e.Id)
            .NotEmpty()
            .WithMessage("Id cannot be empty");

        RuleFor(e => e.CapacityFactorInPercentage)
            .NotEmpty()
            .WithMessage("Capacity Factor cannot be empty")
            .Must(capacityFactor => decimal.TryParse(capacityFactor.ToString(), out _))
            .WithMessage("Capacity Factor must be a valid number")
            .GreaterThan(0)
            .WithMessage("Capacity Factor must be greater than 0%.")
            .LessThanOrEqualTo(100)
            .WithMessage("Capacity Factor must be less than or equal 100%.");
    }
}

// Request
public record UpdateCapacityFactorByVariantUseCase(
    long Id,
    decimal CapacityFactorInPercentage
) : IRequest<Result<CapacityFactorByVariant>>, IAuthorizeAdmin;

// Handler
public class UpdateCapacityFactorByVariantUseCaseHandler : IRequestHandler<UpdateCapacityFactorByVariantUseCase, Result<CapacityFactorByVariant>>
{
    private readonly ICapacityFactorByVariantRepository _capacityFactorRepository;

    public UpdateCapacityFactorByVariantUseCaseHandler(ICapacityFactorByVariantRepository capacityFactorRepository)
    {
        _capacityFactorRepository = capacityFactorRepository;
    }

    public async Task<Result<CapacityFactorByVariant>> Handle(UpdateCapacityFactorByVariantUseCase request, CancellationToken cancellationToken)
    {
        var capacityFactor = await _capacityFactorRepository.GetByIdAsync(request.Id, cancellationToken);

        if (capacityFactor.IsFailure || capacityFactor.Value is null)
            return Result.Failure<CapacityFactorByVariant>(capacityFactor.Error);


        capacityFactor.Value.CapacityFactorInPercentage = request.CapacityFactorInPercentage;

        var result = await _capacityFactorRepository.UpdateAsync(capacityFactor.Value, cancellationToken);

        if (result.IsSuccess)
            return Result.Success(capacityFactor.Value);

        return Result.Failure<CapacityFactorByVariant>(result.Error);
    }
}
