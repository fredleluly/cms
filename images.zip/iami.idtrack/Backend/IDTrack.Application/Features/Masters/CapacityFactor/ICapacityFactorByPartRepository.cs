using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.Masters.CapacityFactor;

public interface ICapacityFactorByPartRepository : IPagingService<CapacityFactorByPart>
{
    public Task<Result<CapacityFactorByPart>> AddAsync(CapacityFactorByPart routePartCapacity, CancellationToken ct);
    public Task<Result<CapacityFactorByPart>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<CapacityFactorByPart>> UpdateAsync(CapacityFactorByPart routePartCapacity, CancellationToken ct);
    public Task<Result<CapacityFactorByPart>> DeleteAsync(long id, CancellationToken ct);
    public Task<BulkResult> MergeBulkAsync(IEnumerable<CapacityFactorByPart> routePartCapacities, CancellationToken ct);
}