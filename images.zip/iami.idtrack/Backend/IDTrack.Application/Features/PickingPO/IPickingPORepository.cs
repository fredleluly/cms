using IDTrack.Application.Features.PickingGR.UseCase;
using IDTrack.Application.Features.PickingPO.UseCase;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.PickingPO;

public interface IPickingPORepository : IPagingService<PurchaseOrder>
{
    public Task<Result<PurchaseOrder>> AddAsync(PurchaseOrder purchaseOrder, CancellationToken ct);
    public Task<Result<GetPickingPODetailUseCaseResult>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<PurchaseOrder>> UpdateAsync(PurchaseOrder purchaseOrder, CancellationToken ct);
    public Task<Result<PurchaseOrder>> DeleteAsync(long id, CancellationToken ct);
}
