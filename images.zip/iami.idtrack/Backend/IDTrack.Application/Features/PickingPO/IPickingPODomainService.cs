namespace IDTrack.Application.Features.PickingPO;

public interface IPickingPODomainService{

}