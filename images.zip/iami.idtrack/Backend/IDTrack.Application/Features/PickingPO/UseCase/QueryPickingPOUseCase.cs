using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPO.UseCase;

public record QueryPickingPOUseCase(
    string? PONo = null,
    string? VendorNo = null,
    string? OrderType = null,
    DateOnly? DeliveryDate = null
) : PagingQuery, IRequest<Result<PagingResult<PurchaseOrder>>>, IAuthorizeAdmin;

public class QueryPickingPOUseCaseHandler : IRequestHandler<QueryPickingPOUseCase, Result<PagingResult<PurchaseOrder>>>
{
    private readonly IPickingPORepository _queryPickingPOUseCase;

    public QueryPickingPOUseCaseHandler(IPickingPORepository queryPickingPOUseCase)
    {
        _queryPickingPOUseCase = queryPickingPOUseCase;
    }

    public async Task<Result<PagingResult<PurchaseOrder>>> Handle(QueryPickingPOUseCase request, CancellationToken cancellationToken)
    {
        var query = _queryPickingPOUseCase.Query();

        var predicate = PredicateBuilder.True<PurchaseOrder>();

        if (!string.IsNullOrEmpty(request.PONo))
        {
            predicate = predicate.And(x => x.PoNo.Contains(request.PONo));
        }

        query = query.Where(predicate);

        return await _queryPickingPOUseCase.LoadPageAsync(query, request, cancellationToken);
    }
}

