using System.Security.Cryptography.X509Certificates;
using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPO.UseCase;

public record QueryIntfSAPUseCase(
    long? TrackSapPickPoId,
    string? IntfGuid = null,
    string? IntfFunc = null,
    string? IntfCompName = null,
    DateTime? IntfTimeStart = null,
    DateTime? IntfTimeEnd = null
) : PagingQuery, IRequest<Result<PagingResult<InterfaceSAP>>>, IAuthorizeAdmin;

public class QueryIntfSAPUseCaseHandler : IRequestHandler<QueryIntfSAPUseCase, Result<PagingResult<InterfaceSAP>>>
{
    private readonly IInterfaceSAPRepository _interfaceSAPRepository;

    public QueryIntfSAPUseCaseHandler(IInterfaceSAPRepository interfaceSAPRepository)
    {
        _interfaceSAPRepository = interfaceSAPRepository;
    }

    public async Task<Result<PagingResult<InterfaceSAP>>> Handle(QueryIntfSAPUseCase request, CancellationToken cancellationToken)
    {
        var query = _interfaceSAPRepository.Query();

        var predicate = PredicateBuilder.True<InterfaceSAP>();

        if ( request.TrackSapPickPoId.HasValue)
        {
            predicate = predicate.And(x => x.TrackSapPickPoId == request.TrackSapPickPoId);
        }

        if (!string.IsNullOrEmpty(request.IntfGuid))
        {
            predicate = predicate.And(x => x.IntfGuid.Contains(request.IntfGuid));
        }

        if (!string.IsNullOrEmpty(request.IntfFunc))
        {
            predicate = predicate.And(x => x.IntfFunc.Contains(request.IntfFunc));
        }

        if (!string.IsNullOrEmpty(request.IntfCompName))
        {
            predicate = predicate.And(x => x.IntfCompName.Contains(request.IntfCompName));
        }

        if (request.IntfTimeStart.HasValue)
        {
            predicate = predicate.And(x => x.IntfTimeStart == request.IntfTimeStart.Value);
        }

        if (request.IntfTimeEnd.HasValue)
        {
            predicate = predicate.And(x => x.IntfTimeEnd == request.IntfTimeEnd.Value);
        }

        query = query.Where(predicate);

        return await _interfaceSAPRepository.LoadPageAsync(query, request, cancellationToken);
    }
}

