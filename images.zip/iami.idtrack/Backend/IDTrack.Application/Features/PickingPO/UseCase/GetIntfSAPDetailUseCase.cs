using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Application.Features.PickingPO;
using IDTrack.Domain.Features.PickingPO.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.IntfSAP.UseCase;

public record GetIntfSAPDetailUseCase(int TrackSapPickPoId) : IRequest<Result<ICollection<InterfaceSAPRequest>>>, IAuthorizeAdmin;

public class GetIntfSAPDetailUseCaseHandler : IRequestHandler<GetIntfSAPDetailUseCase, Result<ICollection<InterfaceSAPRequest>>>
{
    private readonly IInterfaceSAPRepository _interfaceSAPRepository;

    public GetIntfSAPDetailUseCaseHandler(IInterfaceSAPRepository interfaceSAPRepository)
    {
        _interfaceSAPRepository = interfaceSAPRepository;
    }
    public async Task<Result<ICollection<InterfaceSAPRequest>>> Handle(GetIntfSAPDetailUseCase request, CancellationToken cancellationToken)
    {
        var interfaceSAPDetail = await _interfaceSAPRepository.GetInterfaceDetailAsync(request.TrackSapPickPoId, cancellationToken);

        return interfaceSAPDetail;
    }
}
