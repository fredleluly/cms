using IDTrack.Application.Behaviors.Interfaces;
using IDTrack.Domain.Features.PickingPO.Entities;
using IDTrack.Domain.Models;
using MediatR;

namespace IDTrack.Application.Features.PickingPO.UseCase;

public record GetPickingPODetailUseCase(int Id) : IRequest<Result<GetPickingPODetailUseCaseResult>>, IAuthorizeAdmin;

public record GetPickingPODetailUseCaseResult(
    string PoNo,
    DateTime PoDate,
    string VendorNo,
    string VendorName,
    string ContactName,
    string FaxNo,
    DateTime DeliveryDate,
    string OrderType,
    string PlantCode,
    string PurchaseOrg,
    string PurchaseGroup,
    DateTime ValidStart,
    DateTime ValidEnd,
    string Currency,
    string CostBearer,
    short POStatus,
    ICollection<PurchaseOrderDetail> POItems
);

public class GetPickingPODetailUseCaseHandler : IRequestHandler<GetPickingPODetailUseCase, Result<GetPickingPODetailUseCaseResult>>
{
    private readonly IPickingPORepository _queryPickingPOUseCase;

    public GetPickingPODetailUseCaseHandler(IPickingPORepository queryPickingPOUseCase)
    {
        _queryPickingPOUseCase = queryPickingPOUseCase;
    }
    public async Task<Result<GetPickingPODetailUseCaseResult>> Handle(GetPickingPODetailUseCase request, CancellationToken cancellationToken)
    {
        var poDetail = await _queryPickingPOUseCase.GetByIdAsync(request.Id, cancellationToken);

        return poDetail;
    }
}
