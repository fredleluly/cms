using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Features.PickingPO.Entities;
using IDTrack.Domain.Models;

namespace IDTrack.Application.Features.PickingPO;

public interface IInterfaceSAPRepository : IPagingService<InterfaceSAP>
{
    public Task<Result<InterfaceSAP>> GetByIdAsync(long id, CancellationToken ct);
    public Task<Result<ICollection<InterfaceSAPRequest>>> GetInterfaceDetailAsync(long id, CancellationToken ct);
}
