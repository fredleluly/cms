namespace IDTrack.Application;

public class ApplicationAssemblyReference
{
}
