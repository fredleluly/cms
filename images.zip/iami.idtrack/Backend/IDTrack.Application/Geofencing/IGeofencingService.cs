using IDTrack.Domain.Models;

namespace IDTrack.Application.Geofencing;

public interface IGeofencingService
{
    public Task<Result<double>> CalculateDistanceBetweenTwoPointsAsync(string lat1, string lon1, string lat2, string lon2);
}
