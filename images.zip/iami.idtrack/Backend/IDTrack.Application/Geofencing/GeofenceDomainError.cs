using IDTrack.Domain.Models;

namespace IDTrack.Application.Geofencing;

public static class GeofenceDomainError
{
    public static Error InvalidCoordinates => new(nameof(InvalidCoordinates), "Failed to parse coordinates");
}
