namespace IDTrack.Application.Paging;

public interface IPagingService<T>
    where T : class
{
    public Task<PagingResult<T>> LoadPageAsync(
        IQueryable<T> query,
        PagingQuery page,
        CancellationToken ct);

    public IQueryable<T> Query();
}
