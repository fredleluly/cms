using IDTrack.Domain.Internationalization;
using IDTrack.Domain.Models;
using Microsoft.Extensions.Localization;

namespace IDTrack.Infrastructure.Internationalization;

public class DomainErrorLocalizer : IDomainErrorLocalizer
{
    private readonly IStringLocalizerFactory _factory;

    public DomainErrorLocalizer(IStringLocalizerFactory factory)
    {
        _factory = factory;
    }

    public Error Error<T>(string code, params object[] args)
    {
        var baseName = $"{typeof(T).Name}";
        var localizer = _factory.Create(baseName, typeof(IDomainErrorLocalizer).Assembly.GetName().Name!);

        string message;
        if (args.Length > 0)
            message = localizer[code, args];
        else
            message = localizer[code];

        return new Error(code, message);
    }
}
