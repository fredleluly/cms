namespace IDTrack.Infrastructure.Document;

public static class DocumentConstants
{
    public const string TruckCapacityFactorTemplate = "TruckCapacityFactorTemplate.xlsx";
    public const string RoutePartCapacityTemplate = "RoutePartCapacityFactorTemplate.xlsx";
    public const string PickingLPBTemplate = "LPBTemplate.html";
    public const string IsuzuLogo = "Logo.png";
    public const string TemplateFolder = "Templates";
}
