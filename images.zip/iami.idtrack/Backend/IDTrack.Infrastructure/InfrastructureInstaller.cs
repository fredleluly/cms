using System.Globalization;
using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Email;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Application.Features.ComponentTracking.Direct;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Identity.Models;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Application.Features.Masters.GateIn;
using IDTrack.Application.Features.Masters.Route;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Application.Features.Masters.TransporterRoute;
using IDTrack.Application.Features.PickingGR;
using IDTrack.Application.Features.PickingPO;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Application.Geofencing;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Internationalization;
using IDTrack.Infrastructure.Email;
using IDTrack.Infrastructure.Features.AppConfiguration;
using IDTrack.Infrastructure.Features.Auth;
using IDTrack.Infrastructure.Features.ComponentTracking.Direct;
using IDTrack.Infrastructure.Features.Identity;
using IDTrack.Infrastructure.Features.Identity.Data;
using IDTrack.Infrastructure.Features.Identity.Data.Entities;
using IDTrack.Infrastructure.Features.InterfaceSAPRepository;
using IDTrack.Infrastructure.Features.Masters.CapacityFactor;
using IDTrack.Infrastructure.Features.Masters.GateIn;
using IDTrack.Infrastructure.Features.Masters.Route;
using IDTrack.Infrastructure.Features.Masters.Supplier;
using IDTrack.Infrastructure.Features.Masters.Transporter;
using IDTrack.Infrastructure.Features.Masters.TransporterRoute;
using IDTrack.Infrastructure.Features.PickingGR;
using IDTrack.Infrastructure.Features.PickingPO;
using IDTrack.Infrastructure.Features.PickingPreparation;
using IDTrack.Infrastructure.Geofencing;
using IDTrack.Infrastructure.Internationalization;
using IDTrack.Infrastructure.Persistence;
using IDTrack.Infrastructure.Persistence.Data;
using IDTrack.Infrastructure.Persistence.Interceptors;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace IDTrack.Infrastructure;

public static class InfrastructureInstaller
{
	public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration config)
	{
		services.AddScoped<IUnitOfWork, UnitOfWork>();
		services.AddScoped<IIdentityService, IdentityService>();
        services.AddScoped<IEmailService, EmailService>();
        services.AddIdentity<SecUserInfra, SecRole>()
            .AddEntityFrameworkStores<IdentityContext>()
            .AddDefaultTokenProviders();
        services.AddScoped<AuditableEntityInterceptor>();
		services.AddDbContext<AppDbContext>((sp, opt) =>
		{
			//opt.UseInMemoryDatabase("InMemoryDb");
            //
            var auditableIntercepter = sp.GetService<AuditableEntityInterceptor>()!;
			opt
                .UseSqlServer(config.GetConnectionString("AppDbContext"))
                .AddInterceptors(auditableIntercepter);
		});
		services.AddDbContext<IdentityContext>((sp, opt) =>
		{
			//opt.UseInMemoryDatabase("InMemoryDb");
            //
            var auditableIntercepter = sp.GetService<AuditableEntityInterceptor>()!;
			opt
                .UseSqlServer(config.GetConnectionString("SecDbContext"))
                .AddInterceptors(auditableIntercepter);
		});
        services.Configure<Features.Identity.Models.IdentityOptions>(config.GetSection("Identity"));
        services.Configure<EmailOptions>(config.GetSection("Email"));
        services.Configure<JwtOptions>(config.GetSection("Jwt"));

        services.AddScoped<IPickingRouteRepository, PickingRouteRepository>();
        services.AddScoped<ICapacityFactorByVariantRepository, CapacityFactorByVariantRepository>();
        services.AddScoped<ICapacityFactorByVariantDomainService, CapacityFactorByVariantDomainService>();
        services.AddScoped<IPickingTransporterRepository, PickingTransporterRepository>();
        services.AddScoped<IPartSupplierRepository, PartSupplierRepository>();
        services.AddScoped<IPickingTransporterRouteRepository, PickingTransporterRouteRepository>();
        services.AddScoped<IPickingGateInRepository, PickingGateInRepository>();
        services.AddScoped<IOKBRepository, OKBRepository>();
        services.AddScoped<IPickingInstructionRepository, PickingInstructionRepository>();
        services.AddScoped<IPickupPointRepository, PickupPointRepository>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IDirectDeliveryRepository, DirectDeliveryRepository>();
        services.AddScoped<IGeofencingService, GeofencingService>();
        services.AddScoped<IAppConfigurationService, AppConfigurationService>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<IIdentityUnitOfWork, IdentityUnitOfWork>();
        services.AddScoped<IPickingDomainService, PickingDomainService>();
        services.AddScoped<IDomainErrorLocalizer, DomainErrorLocalizer>();
        services.AddScoped<IPickingGRDomainService, PickingGRDomainService>();
        services.AddScoped<IPickingGRRepository, PickingGRRepository>();
        services.AddScoped<IUserDeviceService, UserDeviceService>();
        services.AddScoped<IPickingPORepository, PickingPORepository>();
        services.AddScoped<IInterfaceSAPRepository, InterfaceSAPRepository>();
        services.AddScoped<ICapacityFactorByPartDomainService, CapacityFactorByPartDomainService>();
        services.AddScoped<ICapacityFactorByPartRepository, CapacityFactorByPartRepository>();
        services.AddLocalization(o => o.ResourcesPath = "Resources");
        services.Configure<RequestLocalizationOptions>(options => {
            var supportedCultures = new List<CultureInfo>
            {
                new CultureInfo("en"),
                new CultureInfo("id"),
            };
            options.DefaultRequestCulture = new RequestCulture("en");
            options.SupportedCultures = supportedCultures;
            options.SupportedUICultures = supportedCultures;
        });

        services.AddScoped<IAuthenticationService, AuthenticationService>();

		return services;
	}
}
