using IDTrack.Application.Email;
using IDTrack.Domain.Models;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Options;
using MimeKit;

namespace IDTrack.Infrastructure.Email;

public class EmailService : IEmailService
{
    private readonly EmailOptions _emailOptions;

    public EmailService(IOptions<EmailOptions> emailOptions)
    {
        _emailOptions = emailOptions.Value;
    }

    private async Task<Result> SendAsync(MimeMessage message, CancellationToken ct = default)
    {
        int retryMax = _emailOptions.RetryMax;
        if (retryMax <= 0)
            retryMax = 1;
        int attempts = 0;
        while (attempts < retryMax)
        {
            try
            {
                using var smtp = new SmtpClient();
                await smtp.ConnectAsync(
                    _emailOptions.Host, 
                    _emailOptions.Port, 
                    (SecureSocketOptions)_emailOptions.SecureSocketOptions,
                    ct);
                if ((SecureSocketOptions)_emailOptions.SecureSocketOptions != SecureSocketOptions.None)
                {
                    if (_emailOptions.RemoveXoAuth2)
                        smtp.AuthenticationMechanisms.Remove("XOAUTH2");
                    await smtp.AuthenticateAsync(
                        _emailOptions.EmailUser, 
                        _emailOptions.EmailPassword, 
                        ct);
                }
                await smtp.SendAsync(message, ct);
                await smtp.DisconnectAsync(true, ct);

                return Result.Success();
            }
            catch (Exception ex)
            {
                //_logger.LogError(0, ex, "MailKit.Send failed attempt {0}", count);
                attempts++;
                if (attempts < retryMax)
                    await Task.Delay(attempts * 200);

                return Result.Failure(new Error(ex.ToString(), ex.Message));
            }
        }
        return Result.Failure(new Error("FailedToSendEmail", "Unknown error occurred when sending email"));
    }

    public async Task<Result> SendSimpleHtmlMessageAddressListAsync(
        string subject, 
        string body, 
        string toList, 
        string? ccList = null, 
        string? bccList = null, 
        CancellationToken ct = default)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_emailOptions.EmailFromName, _emailOptions.EmailFrom));
        message.To.AddRange(InternetAddressList.Parse(toList));
        if (!string.IsNullOrWhiteSpace(ccList))
            message.To.AddRange(InternetAddressList.Parse(ccList));
        if (!string.IsNullOrWhiteSpace(bccList))
            message.To.AddRange(InternetAddressList.Parse(bccList));
        message.Subject = subject;

        message.Body = new TextPart("html")
        {
            Text = body
        };

        return await SendAsync(message, ct);
    }

    public async Task<Result> SendSimpleHtmlMessageAsync(string subject, string body, string toName, string to, string? cc = null, string? bcc = null, CancellationToken ct = default)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_emailOptions.EmailFromName, _emailOptions.EmailFrom));
        message.To.Add(new MailboxAddress(toName, to));
        if (!string.IsNullOrWhiteSpace(cc))
            message.To.Add(MailboxAddress.Parse(cc));
        if (!string.IsNullOrWhiteSpace(bcc))
            message.To.Add(MailboxAddress.Parse(bcc));
        message.Subject = subject;

        message.Body = new TextPart("html")
        {
            Text = body
        };

        return await SendAsync(message, ct);
    }

    public async Task<Result> SendSimpleMessageAddressListAsync(string subject, string body, string toList, string? ccList = null, string? bccList = null, CancellationToken ct = default)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_emailOptions.EmailFromName, _emailOptions.EmailFrom));
        message.To.AddRange(InternetAddressList.Parse(toList));
        if (!string.IsNullOrWhiteSpace(ccList))
            message.To.AddRange(InternetAddressList.Parse(ccList));
        if (!string.IsNullOrWhiteSpace(bccList))
            message.To.AddRange(InternetAddressList.Parse(bccList));
        message.Subject = subject;

        message.Body = new TextPart("plain")
        {
            Text = body
        };

        return await SendAsync(message, ct);
    }

    public async Task<Result> SendSimpleMessage(
        string subject, 
        string body, 
        string toName, 
        string to, 
        string? cc = null, 
        string? bcc = null,
        CancellationToken ct = default)
    {
        var message = new MimeMessage();
        message.From.Add(new MailboxAddress(_emailOptions.EmailFromName, _emailOptions.EmailFrom));
        message.To.Add(new MailboxAddress(toName, to));
        if (!string.IsNullOrWhiteSpace(cc))
            message.To.Add(MailboxAddress.Parse(cc));
        if (!string.IsNullOrWhiteSpace(bcc))
            message.To.Add(MailboxAddress.Parse(bcc));
        message.Subject = subject;

        message.Body = new TextPart("plain")
        {
            Text = body
        };

        return await SendAsync(message, ct);
    }
}
