﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MasterRoutePartCapacity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MS_ROUTE_PART_CAPACITY",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ROUTE_CODE = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    PART_NO = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    CAPACITY_FACTOR = table.Column<decimal>(type: "decimal(18,0)", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    CreateByStr = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UpdateByStr = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MS_ROUTE_PART_CAPACITY", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MS_ROUTE_PART_CAPACITY");
        }
    }
}
