﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class SecRoleSeed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "sec_role",
                columns: new[] { "id", "concurrency_stamp", "create_by", "create_time", "name", "name_normalized", "role_description", "status", "update_by", "update_time" },
                values: new object[,]
                {
                    { 5, null, 0, new DateTime(2024, 10, 14, 12, 22, 14, 888, DateTimeKind.Local).AddTicks(6912), "supplier", "SUPPLIER", "IAMI's part supplier", 0, null, null },
                    { 6, null, 0, new DateTime(2024, 10, 14, 12, 22, 14, 888, DateTimeKind.Local).AddTicks(6944), "logistic-partner", "LOGISTIC-PARTNER", "IAMI's logistic partner", 0, null, null }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 6);
        }
    }
}
