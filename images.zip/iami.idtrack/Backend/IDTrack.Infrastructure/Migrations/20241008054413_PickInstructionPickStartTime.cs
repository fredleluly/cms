﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickInstructionPickStartTime : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "PICK_START_TIME",
                table: "TR_POS_PICK",
                type: "datetime2",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PICK_START_TIME",
                table: "TR_POS_PICK");
        }
    }
}
