﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class NewPickPoFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "QTY",
                table: "TR_TRACK_PICK_PO_DTL",
                newName: "QTY_PO");

            migrationBuilder.AddColumn<string>(
                name: "SAP_PLANT_CODE",
                table: "TR_TRACK_PICK_PO_DTL",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SlocCode",
                table: "TR_TRACK_PICK_PO_DTL",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "CFC_CODE",
                table: "TR_TRACK_PICK_PO",
                type: "varchar(5)",
                unicode: false,
                maxLength: 5,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "DOC_TYPE",
                table: "TR_TRACK_PICK_PO",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "SAP_PLANT_CODE",
                table: "TR_TRACK_PICK_PO",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<long>(
                name: "VENDOR_ID",
                table: "TR_TRACK_PICK_PO",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SAP_PLANT_CODE",
                table: "TR_TRACK_PICK_PO_DTL");

            migrationBuilder.DropColumn(
                name: "SlocCode",
                table: "TR_TRACK_PICK_PO_DTL");

            migrationBuilder.DropColumn(
                name: "CFC_CODE",
                table: "TR_TRACK_PICK_PO");

            migrationBuilder.DropColumn(
                name: "DOC_TYPE",
                table: "TR_TRACK_PICK_PO");

            migrationBuilder.DropColumn(
                name: "SAP_PLANT_CODE",
                table: "TR_TRACK_PICK_PO");

            migrationBuilder.DropColumn(
                name: "VENDOR_ID",
                table: "TR_TRACK_PICK_PO");

            migrationBuilder.RenameColumn(
                name: "QTY_PO",
                table: "TR_TRACK_PICK_PO_DTL",
                newName: "QTY");
        }
    }
}
