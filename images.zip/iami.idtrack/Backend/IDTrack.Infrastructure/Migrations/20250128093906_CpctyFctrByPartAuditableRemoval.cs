﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CpctyFctrByPartAuditableRemoval : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreateByStr",
                table: "MS_TRACK_CPCTY_FCTR_PART");

            migrationBuilder.DropColumn(
                name: "UpdateByStr",
                table: "MS_TRACK_CPCTY_FCTR_PART");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CreateByStr",
                table: "MS_TRACK_CPCTY_FCTR_PART",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UpdateByStr",
                table: "MS_TRACK_CPCTY_FCTR_PART",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
