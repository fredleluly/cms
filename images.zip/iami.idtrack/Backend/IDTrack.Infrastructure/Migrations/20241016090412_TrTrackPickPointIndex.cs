﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TrTrackPickPointIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IDX_TR_TRACK_PICK_POINT_PICK_ID",
                table: "TR_TRACK_PICK_POINT",
                column: "PICK_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IDX_TR_TRACK_PICK_POINT_PICK_ID",
                table: "TR_TRACK_PICK_POINT");
        }
    }
}
