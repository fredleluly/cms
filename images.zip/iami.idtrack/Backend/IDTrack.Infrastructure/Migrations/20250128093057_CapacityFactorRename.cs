﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CapacityFactorRename : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "MS_ROUTE_PART_CAPACITY",
                newName: "MS_TRACK_CPCTY_FCTR_PART");

            migrationBuilder.RenameTable(
                name: "MS_TRACK_CAPACITY_FACTOR",
                newName: "MS_TRACK_CPCTY_FCTR_VARIANT");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameTable(
                name: "MS_TRACK_CPCTY_FCTR_PART",
                newName: "MS_ROUTE_PART_CAPACITY");

            migrationBuilder.RenameTable(
                name: "MS_TRACK_CPCTY_FCTR_VARIANT",
                newName: "MS_TRACK_CAPACITY_FACTOR");
        }
    }
}
