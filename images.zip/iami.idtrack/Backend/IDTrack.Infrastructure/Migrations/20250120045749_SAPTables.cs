﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class SAPTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_GR",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    GR_DATE = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SAP_PO_NO = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    PODate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DN_NO = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    REF_NO = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SAP_MAT_DOC = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    SAP_MAT_DOC_YEAR = table.Column<string>(type: "varchar(4)", unicode: false, maxLength: 4, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_GR", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_PO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PO_NO = table.Column<string>(type: "varchar(15)", unicode: false, maxLength: 15, nullable: false),
                    PO_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PURCH_ORG = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PURCH_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VALID_START = table.Column<DateTime>(type: "datetime", nullable: false),
                    VALID_END = table.Column<DateTime>(type: "datetime", nullable: false),
                    CURRENCY = table.Column<string>(type: "varchar(6)", unicode: false, maxLength: 6, nullable: false),
                    PO_STATUS = table.Column<short>(type: "smallint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_PO", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_GR_DTL",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TRACK_PICK_GR_ID = table.Column<long>(type: "bigint", nullable: false),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    GR_DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: false),
                    UNIT = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_GR_DTL", x => new { x.TRACK_PICK_GR_ID, x.Id });
                    table.ForeignKey(
                        name: "FK_TR_TRACK_PICK_GR_DTL_TR_TRACK_PICK_GR_TRACK_PICK_GR_ID",
                        column: x => x.TRACK_PICK_GR_ID,
                        principalTable: "TR_TRACK_PICK_GR",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_PO_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PO_NO = table.Column<string>(type: "varchar(15)", unicode: false, maxLength: 15, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_ID = table.Column<long>(type: "bigint", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY = table.Column<int>(type: "int", nullable: false),
                    SC_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SUPP_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    DELETE_IND = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PO_DTL_STATUS = table.Column<int>(type: "int", nullable: false),
                    TRACK_PICK_PO_ID = table.Column<long>(type: "bigint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_PO_DTL", x => x.ID);
                    table.ForeignKey(
                        name: "FK_TR_TRACK_PICK_PO_DTL_TR_TRACK_PICK_PO_TRACK_PICK_PO_ID",
                        column: x => x.TRACK_PICK_PO_ID,
                        principalTable: "TR_TRACK_PICK_PO",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "UQ_TR_TRACK_PICK_PO",
                table: "TR_TRACK_PICK_PO",
                column: "PO_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TR_TRACK_PICK_PO_DTL_TRACK_PICK_PO_ID",
                table: "TR_TRACK_PICK_PO_DTL",
                column: "TRACK_PICK_PO_ID");

            migrationBuilder.CreateIndex(
                name: "UQ_TR_TRACK_SAP_PICK_PO_DTL",
                table: "TR_TRACK_PICK_PO_DTL",
                column: "PO_NO",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_GR_DTL");

            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_PO_DTL");

            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_GR");

            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_PO");
        }
    }
}
