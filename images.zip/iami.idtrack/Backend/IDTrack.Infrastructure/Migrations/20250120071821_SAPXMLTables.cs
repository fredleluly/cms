﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class SAPXMLTables : Migration
    {
        public const string GetPoHeaderResp = "intf_mt_wis_poheader_rfc";
        public const string GetPoHeaderRespOutputItem = "intf_mt_wis_poheader_rfc_output_item";

        public const string GetPoDetailResp = "intf_mt_wis_inbound_po_detail_rfc";
        public const string GetPoDetailRespHeader = "intf_mt_wis_inbound_po_detail_rfc_header";
        public const string GetPoDetailRespOutputItem = "intf_mt_wis_inbound_po_detail_rfc_output_item";

        public const string PickingGRResp = "intf_mt_wis_creategr_rfc_output_item";

        public const string ChangePOResp = "intf_mt_wis_changepo_rfc";

        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
                SET ANSI_NULLS ON
                GO
                SET QUOTED_IDENTIFIER ON
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{GetPoHeaderResp}] (
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_id_no] [varchar](20) NULL,
                    [if_fe_confirm] [varchar](10) NULL,
                    [if_message] [varchar](255) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{GetPoHeaderResp}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{GetPoHeaderResp}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{GetPoHeaderRespOutputItem}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_po_number] [varchar](30) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{GetPoHeaderRespOutputItem}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{GetPoHeaderRespOutputItem}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{GetPoDetailResp}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_id_no] [varchar](20) NULL,
                    [if_fe_confirm] [varchar](10) NULL,
                    [if_message] [varchar](255) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{GetPoDetailResp}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{GetPoDetailResp}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{GetPoDetailRespHeader}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_sa_number] [varchar](30) NULL,
                    [if_doc_type] [varchar](10) NULL,
                    [if_create_date] [varchar](10) NULL,
                    [if_vendor] [varchar](10) NULL,
                    [if_paymentterm] [varchar](10) NULL,
                    [if_purch_org] [varchar](10) NULL,
                    [if_pur_group] [varchar](10) NULL,
                    [if_currency] [varchar](5) NULL,
                    [if_exch_rate] [varchar](10) NULL,
                    [if_valid_start] [varchar](10) NULL,
                    [if_valid_end] [varchar](10) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,
                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{GetPoDetailRespHeader}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{GetPoDetailRespHeader}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{GetPoDetailRespOutputItem}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_item_no] [varchar](10) NULL,
                    [if_materialno] [varchar](30) NULL,
                    [if_plant] [varchar](10) NULL,
                    [if_storagelocation] [varchar](10) NULL,
                    [if_targetqty] [varchar](10) NULL,
                    [if_net_price] [varchar](30) NULL,
                    [if_sc_vendor] [varchar](10) NULL,
                    [if_supp_vendor] [varchar](10) NULL,
                    [if_name1] [varchar](60) NULL,
                    [if_delete_ind] [varchar](10) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{GetPoDetailRespOutputItem}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{GetPoDetailRespOutputItem}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{PickingGRResp}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_id_no] [varchar](20) NULL,
                    [if_fe_confirm] [varchar](10) NULL,
                    [if_matdoc] [varchar](30) NULL,
                    [if_year] [varchar](10) NULL,
                    [if_nookb] [varchar](30) NULL,
                    [if_message] [varchar](255) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{PickingGRResp}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{PickingGRResp}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");

            migrationBuilder.Sql(@$"
                CREATE TABLE [dbo].[{ChangePOResp}](
                    [id] [bigint] IDENTITY(1,1) NOT NULL,
                    [intf_id] [bigint] NOT NULL,
                    [intf_level] [int] NOT NULL,
                    [intf_seq] [int] NOT NULL,
                    [if_id_no] [varchar](20) NULL,
                    [if_fe_confirm] [varchar](10) NULL,
                    [if_message] [varchar](255) NULL,
                    [if_return] [varchar](255) NULL,
                    [status] [smallint] NULL,
                    [created_date] [datetime] NULL,

                    PRIMARY KEY CLUSTERED 
                    (
                        [id] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],

                    UNIQUE NONCLUSTERED 
                    (
                        [intf_id] ASC,
                        [intf_level] ASC,
                        [intf_seq] ASC
                    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
                ) ON [PRIMARY]
                GO
                ALTER TABLE [dbo].[{ChangePOResp}] ADD  DEFAULT ((0)) FOR [status]
                GO
                ALTER TABLE [dbo].[{ChangePOResp}] ADD  DEFAULT (getdate()) FOR [created_date]
                GO
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql($"DROP TABLE [dbo].[{GetPoHeaderResp}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{GetPoHeaderRespOutputItem}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{GetPoDetailResp}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{GetPoDetailRespHeader}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{GetPoDetailRespOutputItem}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{PickingGRResp}]");
            migrationBuilder.Sql($"DROP TABLE [dbo].[{ChangePOResp}]");
        }
    }
}
