﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class SAPTablesAdjustment : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@$"
                EXEC sp_rename 'dbo.{SAPXMLTables.GetPoDetailRespHeader}.if_sa_number', 'if_po_number', 'COLUMN';
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@$"
                EXEC sp_rename 'dbo.{SAPXMLTables.GetPoDetailRespHeader}.if_po_number', 'if_sa_number', 'COLUMN';
            ");
        }
    }
}
