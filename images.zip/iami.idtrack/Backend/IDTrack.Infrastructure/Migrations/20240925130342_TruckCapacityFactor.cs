﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TruckCapacityFactor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_SITE",
                table: "TR_POS_DN",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(10)",
                oldUnicode: false,
                oldMaxLength: 10,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_CODE",
                table: "TR_POS_DN",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(10)",
                oldUnicode: false,
                oldMaxLength: 10,
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "MS_TRACK_CAPACITY_FACTOR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SUFFIX = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: false),
                    KATASHIKI = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    ROUTE_CODE = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    CAPACITY_FACTOR = table.Column<decimal>(type: "decimal(38,17)", nullable: false),
                    PickingRouteId = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MS_TRACK_CAPACITY_FACTOR", x => x.ID);
                    table.ForeignKey(
                        name: "FK_MS_TRACK_CAPACITY_FACTOR_MS_POS_ROUTE_PickingRouteId",
                        column: x => x.PickingRouteId,
                        principalTable: "MS_POS_ROUTE",
                        principalColumn: "ID");
                });

            migrationBuilder.CreateIndex(
                name: "IX_MS_TRACK_CAPACITY_FACTOR_PickingRouteId",
                table: "MS_TRACK_CAPACITY_FACTOR",
                column: "PickingRouteId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MS_TRACK_CAPACITY_FACTOR");

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_SITE",
                table: "TR_POS_DN",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(10)",
                oldUnicode: false,
                oldMaxLength: 10);

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_CODE",
                table: "TR_POS_DN",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(10)",
                oldUnicode: false,
                oldMaxLength: 10);
        }
    }
}
