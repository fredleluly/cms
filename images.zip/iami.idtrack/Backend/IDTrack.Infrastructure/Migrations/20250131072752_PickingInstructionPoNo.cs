﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickingInstructionPoNo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SAP_PO_NO",
                table: "TR_POS_PICK",
                type: "varchar(15)",
                unicode: false,
                maxLength: 15,
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "SAP_PO_NO",
                table: "TR_POS_PICK");
        }
    }
}
