﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class DirectDelivery : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "STATUS",
                table: "TR_POS_DN",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true,
                oldDefaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CREATE_TIME",
                table: "TR_POS_DN",
                type: "datetime",
                nullable: false,
                defaultValueSql: "(getdate())",
                oldClrType: typeof(DateTime),
                oldType: "datetime",
                oldNullable: true,
                oldDefaultValueSql: "(getdate())");

            migrationBuilder.AlterColumn<long>(
                name: "CREATE_BY",
                table: "TR_POS_DN",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "fullname",
                table: "sec_user",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.CreateTable(
                name: "MS_TRACK_GATE_IN",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TOKEN = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    NAME = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    LAT = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    LNG = table.Column<string>(type: "nvarchar(120)", maxLength: 120, nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MS_TRACK_GATE_IN", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_DIRECT_DLV",
                columns: table => new
                {
                    ID = table.Column<long>(type: "BIGINT", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VENDOR_CODE = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    DLV_DATE = table.Column<DateTime>(type: "DATETIME", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_DIRECT_DLV", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_DIRECT_DLV_OKB",
                columns: table => new
                {
                    ID = table.Column<long>(type: "BIGINT", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OkbNo = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    DIRECT_DLV_ID = table.Column<long>(type: "BIGINT", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_DIRECT_DLV_OKB", x => x.ID);
                    table.ForeignKey(
                        name: "FK_TR_TRACK_DIRECT_DLV_OKB_TR_TRACK_DIRECT_DLV_DIRECT_DLV_ID",
                        column: x => x.DIRECT_DLV_ID,
                        principalTable: "TR_TRACK_DIRECT_DLV",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "UQ_MS_TRACK_GATE_IN",
                table: "MS_TRACK_GATE_IN",
                column: "TOKEN",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TR_TRACK_DIRECT_DLV_OKB_DIRECT_DLV_ID",
                table: "TR_TRACK_DIRECT_DLV_OKB",
                column: "DIRECT_DLV_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MS_TRACK_GATE_IN");

            migrationBuilder.DropTable(
                name: "TR_TRACK_DIRECT_DLV_OKB");

            migrationBuilder.DropTable(
                name: "TR_TRACK_DIRECT_DLV");

            migrationBuilder.AlterColumn<int>(
                name: "STATUS",
                table: "TR_POS_DN",
                type: "int",
                nullable: true,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CREATE_TIME",
                table: "TR_POS_DN",
                type: "datetime",
                nullable: true,
                defaultValueSql: "(getdate())",
                oldClrType: typeof(DateTime),
                oldType: "datetime",
                oldDefaultValueSql: "(getdate())");

            migrationBuilder.AlterColumn<long>(
                name: "CREATE_BY",
                table: "TR_POS_DN",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AlterColumn<string>(
                name: "fullname",
                table: "sec_user",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100,
                oldNullable: true);
        }
    }
}
