﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickingInstructionsCreateByRepair : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("UPDATE TR_POS_PICK SET CREATE_BY = 0 WHERE CREATE_BY IS NULL");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
