﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TrPosDnThirdIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "NDX3_TR_POS_DN",
                table: "TR_POS_DN",
                columns: new[] { "ROUTE_CODE", "TRANSPORTER_CODE", "DLV_DATE", "DLV_TIME", "VENDOR_SITE" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "NDX3_TR_POS_DN",
                table: "TR_POS_DN");
        }
    }
}
