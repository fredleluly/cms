﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickingTransporterNewColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UQ__MS_TRANS__8D94EF094301EA8F",
                table: "MS_TRANSPORTER",
                newName: "ID");

            migrationBuilder.CreateIndex(
                name: "UQ__MS_TRANS__8D94EF09CB42F278",
                table: "MS_TRANSPORTER",
                column: "TRANSPORTER_CODE",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "UQ__MS_TRANS__8D94EF09CB42F278",
                table: "MS_TRANSPORTER");

            migrationBuilder.RenameColumn(
                name: "ID",
                table: "MS_TRANSPORTER",
                newName: "UQ__MS_TRANS__8D94EF094301EA8F");
        }
    }
}
