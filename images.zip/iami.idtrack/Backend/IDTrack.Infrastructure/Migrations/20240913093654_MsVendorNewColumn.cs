﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MsVendorNewColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK__MS_VENDO__3214EC27BBB5E4F9",
                table: "MS_VENDOR");

            migrationBuilder.DropColumn(
                name: "NormalizedName",
                table: "sec_role");

            migrationBuilder.RenameIndex(
                name: "UQ__MS_VENDO__E99CB384CEC8FB5F",
                table: "MS_VENDOR",
                newName: "UQ__MS_VENDO__E99CB384035179CE");

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_TYPE",
                table: "MS_VENDOR",
                type: "varchar(5)",
                unicode: false,
                maxLength: 5,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(5)",
                oldUnicode: false,
                oldMaxLength: 5,
                oldNullable: true,
                oldDefaultValue: "MAIN");

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_NAME",
                table: "MS_VENDOR",
                type: "varchar(60)",
                unicode: false,
                maxLength: 60,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(60)",
                oldUnicode: false,
                oldMaxLength: 60,
                oldNullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "STATUS",
                table: "MS_VENDOR",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true,
                oldDefaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CREATE_TIME",
                table: "MS_VENDOR",
                type: "datetime",
                nullable: false,
                defaultValueSql: "(getdate())",
                oldClrType: typeof(DateTime),
                oldType: "datetime",
                oldNullable: true,
                oldDefaultValueSql: "(getdate())");

            migrationBuilder.AlterColumn<long>(
                name: "CREATE_BY",
                table: "MS_VENDOR",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LAT",
                table: "MS_VENDOR",
                type: "varchar(120)",
                unicode: false,
                maxLength: 120,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LNG",
                table: "MS_VENDOR",
                type: "varchar(120)",
                unicode: false,
                maxLength: 120,
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK__MS_VENDO__3214EC2700750D23",
                table: "MS_VENDOR",
                column: "ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK__MS_VENDO__3214EC2700750D23",
                table: "MS_VENDOR");

            migrationBuilder.DropColumn(
                name: "LAT",
                table: "MS_VENDOR");

            migrationBuilder.DropColumn(
                name: "LNG",
                table: "MS_VENDOR");

            migrationBuilder.RenameIndex(
                name: "UQ__MS_VENDO__E99CB384035179CE",
                table: "MS_VENDOR",
                newName: "UQ__MS_VENDO__E99CB384CEC8FB5F");

            migrationBuilder.AddColumn<string>(
                name: "NormalizedName",
                table: "sec_role",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_TYPE",
                table: "MS_VENDOR",
                type: "varchar(5)",
                unicode: false,
                maxLength: 5,
                nullable: true,
                defaultValue: "MAIN",
                oldClrType: typeof(string),
                oldType: "varchar(5)",
                oldUnicode: false,
                oldMaxLength: 5,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_NAME",
                table: "MS_VENDOR",
                type: "varchar(60)",
                unicode: false,
                maxLength: 60,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(60)",
                oldUnicode: false,
                oldMaxLength: 60);

            migrationBuilder.AlterColumn<int>(
                name: "STATUS",
                table: "MS_VENDOR",
                type: "int",
                nullable: true,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldDefaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "CREATE_TIME",
                table: "MS_VENDOR",
                type: "datetime",
                nullable: true,
                defaultValueSql: "(getdate())",
                oldClrType: typeof(DateTime),
                oldType: "datetime",
                oldDefaultValueSql: "(getdate())");

            migrationBuilder.AlterColumn<long>(
                name: "CREATE_BY",
                table: "MS_VENDOR",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddPrimaryKey(
                name: "PK__MS_VENDO__3214EC27BBB5E4F9",
                table: "MS_VENDOR",
                column: "ID");
        }
    }
}
