﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TransporterRoute : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_NAME",
                table: "MS_VENDOR",
                type: "varchar(60)",
                unicode: false,
                maxLength: 60,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(60)",
                oldUnicode: false,
                oldMaxLength: 60);

            migrationBuilder.CreateTable(
                name: "MS_TRACK_TRANSPORTER_ROUTE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_ROUTE_ID = table.Column<long>(type: "bigint", nullable: false),
                    TRANSPORTER_ID = table.Column<long>(type: "bigint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MS_TRACK_TRANSPORTER_ROUTE", x => x.ID);
                    table.ForeignKey(
                        name: "FK_MS_TRACK_TRANSPORTER_ROUTE_MS_POS_ROUTE_POS_ROUTE_ID",
                        column: x => x.POS_ROUTE_ID,
                        principalTable: "MS_POS_ROUTE",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_MS_TRACK_TRANSPORTER_ROUTE_MS_TRANSPORTER_TRANSPORTER_ID",
                        column: x => x.TRANSPORTER_ID,
                        principalTable: "MS_TRANSPORTER",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MS_TRACK_TRANSPORTER_ROUTE_CYCLE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CYCLE_NO = table.Column<int>(type: "int", nullable: false),
                    DEPT_PLAN = table.Column<TimeOnly>(type: "time", nullable: false),
                    ARRIVE_PLAN = table.Column<TimeOnly>(type: "time", nullable: false),
                    TRANSPORTER_ROUTE_ID = table.Column<long>(type: "bigint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MS_TRACK_TRANSPORTER_ROUTE_CYCLE", x => x.ID);
                    table.ForeignKey(
                        name: "FK_MS_TRACK_TRANSPORTER_ROUTE_CYCLE_MS_TRACK_TRANSPORTER_ROUTE_TRANSPORTER_ROUTE_ID",
                        column: x => x.TRANSPORTER_ROUTE_ID,
                        principalTable: "MS_TRACK_TRANSPORTER_ROUTE",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MS_TRACK_TRANSPORTER_ROUTE_TRANSPORTER_ID",
                table: "MS_TRACK_TRANSPORTER_ROUTE",
                column: "TRANSPORTER_ID");

            migrationBuilder.CreateIndex(
                name: "UQ_MS_TRACK_TRANSPORTER_ROUTE_CYCLE",
                table: "MS_TRACK_TRANSPORTER_ROUTE",
                columns: new[] { "POS_ROUTE_ID", "TRANSPORTER_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_MS_TRACK_TRANSPORTER_ROUTE_CYCLE_TRANSPORTER_ROUTE_ID",
                table: "MS_TRACK_TRANSPORTER_ROUTE_CYCLE",
                column: "TRANSPORTER_ROUTE_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MS_TRACK_TRANSPORTER_ROUTE_CYCLE");

            migrationBuilder.DropTable(
                name: "MS_TRACK_TRANSPORTER_ROUTE");

            migrationBuilder.AlterColumn<string>(
                name: "VENDOR_NAME",
                table: "MS_VENDOR",
                type: "varchar(60)",
                unicode: false,
                maxLength: 60,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(60)",
                oldUnicode: false,
                oldMaxLength: 60,
                oldNullable: true);
        }
    }
}
