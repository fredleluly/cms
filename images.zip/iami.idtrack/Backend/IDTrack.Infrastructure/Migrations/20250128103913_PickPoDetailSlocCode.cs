﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickPoDetailSlocCode : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SlocCode",
                table: "TR_TRACK_PICK_PO_DTL",
                newName: "SLOC_CODE");

            migrationBuilder.AlterColumn<string>(
                name: "SLOC_CODE",
                table: "TR_TRACK_PICK_PO_DTL",
                type: "varchar(10)",
                unicode: false,
                maxLength: 10,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SLOC_CODE",
                table: "TR_TRACK_PICK_PO_DTL",
                newName: "SlocCode");

            migrationBuilder.AlterColumn<string>(
                name: "SlocCode",
                table: "TR_TRACK_PICK_PO_DTL",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "varchar(10)",
                oldUnicode: false,
                oldMaxLength: 10);
        }
    }
}
