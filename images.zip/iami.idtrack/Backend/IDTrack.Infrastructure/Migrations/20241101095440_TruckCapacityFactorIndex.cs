﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TruckCapacityFactorIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_MS_TRACK_CAPACITY_FACTOR_KATASHIKI_SUFFIX_ROUTE_CODE",
                table: "MS_TRACK_CAPACITY_FACTOR",
                columns: new[] { "KATASHIKI", "SUFFIX", "ROUTE_CODE" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_MS_TRACK_CAPACITY_FACTOR_KATASHIKI_SUFFIX_ROUTE_CODE",
                table: "MS_TRACK_CAPACITY_FACTOR");
        }
    }
}
