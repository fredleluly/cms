﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickupPoints : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_POINT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PICK_ID = table.Column<long>(type: "bigint", nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_POINT", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_TRACK_PICK_OKB",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DELAY_REASON = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    IS_ADVANCED = table.Column<bool>(type: "bit", nullable: false),
                    TRACK_PICK_POINT_ID = table.Column<long>(type: "bigint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TR_TRACK_PICK_OKB", x => x.ID);
                    table.ForeignKey(
                        name: "FK_TR_TRACK_PICK_OKB_TR_TRACK_PICK_POINT_TRACK_PICK_POINT_ID",
                        column: x => x.TRACK_PICK_POINT_ID,
                        principalTable: "TR_TRACK_PICK_POINT",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IDX_TR_TRACK_PICK_OKB_DN_NO",
                table: "TR_TRACK_PICK_OKB",
                column: "DN_NO");

            migrationBuilder.CreateIndex(
                name: "IX_TR_TRACK_PICK_OKB_TRACK_PICK_POINT_ID",
                table: "TR_TRACK_PICK_OKB",
                column: "TRACK_PICK_POINT_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_OKB");

            migrationBuilder.DropTable(
                name: "TR_TRACK_PICK_POINT");
        }
    }
}
