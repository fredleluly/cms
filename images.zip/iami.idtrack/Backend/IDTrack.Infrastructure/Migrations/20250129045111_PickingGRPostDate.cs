﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PickingGRPostDate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PODate",
                table: "TR_TRACK_PICK_GR");

            migrationBuilder.AddColumn<DateTime>(
                name: "POST_DATE",
                table: "TR_TRACK_PICK_GR",
                type: "datetime2",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "POST_DATE",
                table: "TR_TRACK_PICK_GR");

            migrationBuilder.RenameColumn(
                name: "MATERIAL_NO",
                table: "MS_TRACK_CPCTY_FCTR_PART",
                newName: "MATERIAL_No");
        }
    }
}
