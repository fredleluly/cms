﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class OKBCutoffSetParamSeed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "SET_PARAM",
                columns: new[] { "PARAM_GROUP", "PARAM_NAME", "CREATED_BY", "CREATED_DATE", "PARAM_DESC", "PARAM_FORMAT", "PARAM_NAME1", "PARAM_TYPE", "PARAM_VALUE", "STATUS" },
                values: new object[] { "ITRACK", "OKB_CUTOFF", "Data Seeder", new DateTime(2024, 12, 12, 12, 6, 57, 399, DateTimeKind.Local).AddTicks(1696), "Cutoff old POS OKB Data for new System", null, null, "D", "2017-01-01", 0 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "SET_PARAM",
                keyColumns: new[] { "PARAM_GROUP", "PARAM_NAME" },
                keyValues: new object[] { "ITRACK", "OKB_CUTOFF" });
        }
    }
}
