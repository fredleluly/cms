﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class DeviceIdColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "COMPLETE_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_POINT",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "START_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_POINT",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "DELAY_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_OKB",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SCAN_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_OKB",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CANCEL_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GATE_IN_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "START_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "GATE_IN_BY_DEVICE_ID",
                table: "TR_POS_PICK",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "START_BY_DEVICE_ID",
                table: "TR_POS_PICK",
                type: "varchar(36)",
                unicode: false,
                maxLength: 36,
                nullable: true);

            migrationBuilder.UpdateData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 5,
                column: "create_time",
                value: new DateTime(2024, 11, 22, 16, 20, 11, 450, DateTimeKind.Local).AddTicks(9130));

            migrationBuilder.UpdateData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 6,
                column: "create_time",
                value: new DateTime(2024, 11, 22, 16, 20, 11, 450, DateTimeKind.Local).AddTicks(9151));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PickingGRs");

            migrationBuilder.DropColumn(
                name: "COMPLETE_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_POINT");

            migrationBuilder.DropColumn(
                name: "START_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_POINT");

            migrationBuilder.DropColumn(
                name: "DELAY_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_OKB");

            migrationBuilder.DropColumn(
                name: "SCAN_BY_DEVICE_ID",
                table: "TR_TRACK_PICK_OKB");

            migrationBuilder.DropColumn(
                name: "CANCEL_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV");

            migrationBuilder.DropColumn(
                name: "GATE_IN_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV");

            migrationBuilder.DropColumn(
                name: "START_BY_DEVICE_ID",
                table: "TR_TRACK_DIRECT_DLV");

            migrationBuilder.DropColumn(
                name: "GATE_IN_BY_DEVICE_ID",
                table: "TR_POS_PICK");

            migrationBuilder.DropColumn(
                name: "START_BY_DEVICE_ID",
                table: "TR_POS_PICK");

            migrationBuilder.UpdateData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 5,
                column: "create_time",
                value: new DateTime(2024, 11, 1, 16, 54, 38, 83, DateTimeKind.Local).AddTicks(826));

            migrationBuilder.UpdateData(
                table: "sec_role",
                keyColumn: "id",
                keyValue: 6,
                column: "create_time",
                value: new DateTime(2024, 11, 1, 16, 54, 38, 83, DateTimeKind.Local).AddTicks(853));
        }
    }
}
