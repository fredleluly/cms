﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ESignSetParam : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "SET_PARAM",
                columns: new[] { "PARAM_GROUP", "PARAM_NAME", "CREATED_BY", "CREATED_DATE", "PARAM_DESC", "PARAM_FORMAT", "PARAM_NAME1", "PARAM_TYPE", "PARAM_VALUE", "STATUS" },
                values: new object[] { "ITRACK", "GR_E_SIGN_FOLDER", "Data Seeder", new DateTime(2025, 2, 3, 12, 16, 19, 984, DateTimeKind.Local).AddTicks(870), "User's E-Sign image folder", null, null, "S", "C:/e-sign/", 0 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "SET_PARAM",
                keyColumns: new[] { "PARAM_GROUP", "PARAM_NAME" },
                keyValues: new object[] { "ITRACK", "GR_E_SIGN_FOLDER" });
        }
    }
}
