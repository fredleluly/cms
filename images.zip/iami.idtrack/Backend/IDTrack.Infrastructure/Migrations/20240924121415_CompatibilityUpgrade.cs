﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CompatibilityUpgrade : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DECLARE @dbname nvarchar(128) = DB_NAME(); EXEC('ALTER DATABASE [' + @dbname + '] SET COMPATIBILITY_LEVEL = 150;');");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DECLARE @dbname nvarchar(128) = DB_NAME(); EXEC('ALTER DATABASE [' + @dbname + '] SET COMPATIBILITY_LEVEL = 100;');");
        }
    }
}
