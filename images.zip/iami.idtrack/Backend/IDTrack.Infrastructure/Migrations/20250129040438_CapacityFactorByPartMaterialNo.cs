﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class CapacityFactorByPartMaterialNo : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PART_NO",
                table: "MS_TRACK_CPCTY_FCTR_PART",
                newName: "MATERIAL_NO");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "MATERIAL_NO",
                table: "MS_TRACK_CPCTY_FCTR_PART",
                newName: "PART_NO");
        }
    }
}
