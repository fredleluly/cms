﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace IDTrack.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "edn_supplier_dn",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    rec_id = table.Column<long>(type: "bigint", nullable: false),
                    line_no = table.Column<int>(type: "int", nullable: false),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    dn_date = table.Column<string>(type: "varchar(8)", unicode: false, maxLength: 8, nullable: true),
                    vendor_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    del_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    del_date = table.Column<string>(type: "varchar(8)", unicode: false, maxLength: 8, nullable: true),
                    intf_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    intf_msg = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_edn_supplier_dn", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "IMP_CKD_STOCK_LOT",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: true),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    LOT_NO = table.Column<int>(type: "int", nullable: true),
                    AVL_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MODEL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_CKD___AD219886D37AB3B6", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_HIST",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TABLE_NAME = table.Column<string>(type: "varchar(32)", unicode: false, maxLength: 32, nullable: true),
                    IMP_FILENAME = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    IMP_MD5 = table.Column<string>(type: "varchar(64)", unicode: false, maxLength: 64, nullable: true),
                    IMP_PATH = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    IMP_COMPNAME = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    IMP_START = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    IMP_END = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_HIST__11F0A57731AF1696", x => x.IMP_NO);
                });

            migrationBuilder.CreateTable(
                name: "IMP_MATERIAL",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    MATERIAL_TYPE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    MATERIAL_CAT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY_PER_BOX = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_MATE__AD2198864488310C", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_MATERIAL_SET",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SET_MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    CHILD_MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    SET_QTY = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_MATE__AD21988610258113", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_MATERIAL_VARIANT",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true, defaultValue: "*"),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    VALID_FROM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_TO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_MATE__AD2198866C6086EF", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_MATERIAL_VENDOR",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_FROM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_TO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_MATE__AD219886A4D8C0B8", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_MATERIAL_VLDT_MSG",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    MSG_NO = table.Column<int>(type: "int", nullable: false),
                    MSG_DESC = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_MATE__E9D571BCFE23B58C", x => new { x.IMP_NO, x.MSG_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_PART_BOM",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    LEVEL_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ITEM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    BOM_USG = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    COMPONENT_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    OBJECT_DESC = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    UNIT_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_PART__AD2198865461DD32", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "IMP_PROD_PLAN",
                columns: table => new
                {
                    IMP_NO = table.Column<long>(type: "bigint", nullable: false),
                    LINE_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: true),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    BEGIN_STOCK = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PROD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_SLS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    IMP_TYPE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__IMP_PROD__AD21988679A70DDF", x => new { x.IMP_NO, x.LINE_NO });
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_changesa_resp",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_id_no = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    if_fe_confirm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_message = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    if_return = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83F9F08B95C", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_getsadetail_resp",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_id_no = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    if_fe_confirm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_message = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83F1C3F19E5", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_getsadetail_resp_header",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_sa_number = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    if_doc_type = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_create_date = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_vendor = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_paymentterm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_purch_org = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_pur_group = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_currency = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    if_exch_rate = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_valid_start = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_valid_end = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83F9263BAF7", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_getsadetail_resp_output_item",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_item_no = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_materialno = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    if_plant = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_storagelocation = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_targetqty = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_net_price = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    if_sc_vendor = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_supp_vendor = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_name1 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    if_delete_ind = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83F7CB75385", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_getsaheader_resp",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_id_no = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    if_fe_confirm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_message = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83F451BC858", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_getsaheader_resp_output_item",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_sa_number = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83FAD620225", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_grsa_resp",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_id_no = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    if_fe_confirm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_matdoc = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    if_year = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_nookb = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    if_message = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83FA3551A5E", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intf_mt_grsa_resp_output_item",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_id = table.Column<long>(type: "bigint", nullable: false),
                    intf_level = table.Column<int>(type: "int", nullable: false),
                    intf_seq = table.Column<int>(type: "int", nullable: false),
                    if_status = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    if_remarks = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__intf_mt___3213E83FFE04AD9A", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "intfxml_resp",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    filename = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    func_name = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    req_id = table.Column<int>(type: "int", nullable: true),
                    id_no = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    fe_confirm = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    fe_message = table.Column<string>(type: "varchar(1024)", unicode: false, maxLength: 1024, nullable: true),
                    response_xml = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    response_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    response_message = table.Column<string>(type: "varchar(1024)", unicode: false, maxLength: 1024, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    created_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_intfxml_resp", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "MS_CAL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CAL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CAL_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    CAL_DESC = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    CAL_LOCALE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_CAL__3214EC2782A136F1", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_CAL_HOLIDAY",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HDAY_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    HDAY_DESC = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    HDAY_LOCALE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    HDAY_DAY = table.Column<short>(type: "smallint", nullable: true),
                    HDAY_MONTH = table.Column<short>(type: "smallint", nullable: true),
                    HDAY_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    OCCURENCE_RULE = table.Column<short>(type: "smallint", nullable: true),
                    OCCURENCE_DOW = table.Column<short>(type: "smallint", nullable: true),
                    OBSERVANCE_RULE = table.Column<short>(type: "smallint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_CAL_H__3214EC27FDD94F30", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_CAL_STANDARD",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CAL_ID = table.Column<long>(type: "bigint", nullable: false),
                    CAL_DOW = table.Column<short>(type: "smallint", nullable: false),
                    CAL_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    STATUS_WORK = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS_OT = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CAPACITY_STD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CAPACITY_OT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    TIME_START = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    TIME_END = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_CAL_S__3214EC27B3A55AFC", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_CAL_WORK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CAL_ID = table.Column<long>(type: "bigint", nullable: false),
                    CAL_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    CAL_SOURCE = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS_WORK = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CAPACITY_DAY = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_CAL_W__3214EC272188B509", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_CAL_WORK_SHIFT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CAL_WORK_ID = table.Column<long>(type: "bigint", nullable: false),
                    CAL_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    STATUS_WORK = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS_OT = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CAPACITY_STD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CAPACITY_OT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    TIME_START = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    TIME_END = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_CAL_W__3214EC2786CC3EB6", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_COUNTRY",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    COUNTRY_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_COUNT__3214EC27BF86B103", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    MATERIAL_TYPE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    MATERIAL_CAT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY_PER_BOX = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    PACK_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MAX_STACK = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC27AE71AF89", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_CATEGORY",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MATERIAL_CAT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_CAT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    MATERIAL_CAT_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC27B89345CD", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_SET",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SET_MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    CHILD_MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    SET_QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC274899D100", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_VARIANT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BOM_ID = table.Column<long>(type: "bigint", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false, defaultValue: "*"),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true, defaultValue: new DateTime(9999, 12, 31, 0, 0, 0, 0, DateTimeKind.Unspecified)),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC275C39822F", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_VARIANT_DELETED",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BOM_ID = table.Column<long>(type: "bigint", nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: true),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    DELETED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    DELETED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_MS_MATERIAL_VARIANT_DELETED", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_VENDOR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true, defaultValue: new DateTime(9999, 12, 31, 0, 0, 0, 0, DateTimeKind.Unspecified)),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC27AA8BE658", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_MATERIAL_VENDOR_QUOTA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    QUOTA_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QUOTA_ORD = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QUOTA_DLV = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_MATER__3214EC2751AE794B", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_DELIVERY_TYPE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DELIVERY_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DELIVERY_TYPE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DELIVERY_TYPE_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    REQ_TRANSPORTER = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_D__3214EC270EEBABF8", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_ORDER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false, defaultValue: "*"),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MATERIAL_CAT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOCK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PARK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DELIVERY_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    TRANSPORTER_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ROUTE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ORDER_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ORDER_SCHEDULE = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    LAST_ORDER_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    LEAD_TIME = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 1m),
                    SAFETY_STOCK_UOM = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SAFETY_STOCK = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true, defaultValue: new DateTime(9999, 12, 31, 0, 0, 0, 0, DateTimeKind.Unspecified)),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_O__3214EC27F6F70426", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_ORDER_CYCLE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DLV_TIME = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    INC_DATE = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CYCLE_OT = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_O__3214EC27B266EFCF", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_ORDER_FIXSC",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    DOW = table.Column<short>(type: "smallint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_O__3214EC27136EF393", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_ORDER_TYPE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ORDER_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    ORDER_TYPE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ORDER_TYPE_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_O__3214EC277D798A4F", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_POS_ROUTE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ROUTE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    ROUTE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    ROUTE_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: false),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_POS_R__3214EC27F88276DC", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PRD_SHIFT",
                columns: table => new
                {
                    SHIFT_CODE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    SHIFT_DESC = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ORDER_NO = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    RESET_CYCLE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PRD_S__F5A3A0A0043DDB36", x => x.SHIFT_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MS_PRINTER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PRINTER_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    PRINTER_DESC = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PRINT__3214EC27BE9A0352", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_PROCESS_FLOW",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PFLOW_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PFLOW_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    PFLOW_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_PR__3214EC27838C39D2", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_PROCESS_FLOW_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WCTR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CAPACITY = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    CYCLE_TIME = table.Column<decimal>(type: "decimal(18,5)", nullable: true, defaultValue: 0m),
                    DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_PR__3214EC27D3D65A80", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_PROCESS_FLOW_DTL_LINK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WCTR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WCTR_NEXT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    FLOW_PCTG = table.Column<decimal>(type: "decimal(18,5)", nullable: true, defaultValue: 100m),
                    LINK_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_PR__3214EC272769868A", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_PROCESS_FLOW_DTL_VARIANT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WCTR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_PR__3214EC2747C9B271", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_VARIANT_PROCESS_FLOW",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VPFLOW_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_VA__3214EC275E3262C7", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_PS_WORKCENTER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WCTR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    WCTR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    WCTR_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CAPACITY_DEF = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    CYCLE_TIME_DEF = table.Column<decimal>(type: "decimal(18,5)", nullable: true, defaultValue: 0m),
                    WCTR_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_PS_WO__3214EC2741E12F92", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_REGION",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    REGION_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    REGION_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_REGIO__3214EC27F37AF9FE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_PLANT",
                columns: table => new
                {
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ADDRESS1 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ADDRESS2 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ADDRESS3 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    CITY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATE = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    COUNTRY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    POST_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PHONE_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PHONE_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    EMAIL = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    CAL_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_P__66BE3140DE5DBDA0", x => x.PLANT_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_PLANT_CONV",
                columns: table => new
                {
                    SAP_PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_P__AC7E6C69BC736505", x => x.SAP_PLANT_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_SECTION",
                columns: table => new
                {
                    SECT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SECT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SECT_DESC = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    LEAD_DAY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_S__BB59D335E52D5E16", x => x.SECT_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_SHOP",
                columns: table => new
                {
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SHOP_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SHOP_DESC = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    CYCLEISSUE_X = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CYCLEISSUE_Y = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CYCLEISSUE_Z = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    SAFETY_CYCLE = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    SAFETY_STOCK = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ORDER_NO = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    IS_DEFAULT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_S__8FB823C0E18ACC29", x => x.SHOP_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_WAREHOUSE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    SAP_SLOC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ADDRESS = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    CITY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    POSTAL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    REGION_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    PHONE_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PHONE_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    EMAIL = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    WAREHOUSE_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_W__3214EC27A21A6DBA", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_WAREHOUSE_DOCK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOCK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOCK_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DOCK_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_W__3214EC2793DE4914", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_STP_WAREHOUSE_PARK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PARK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PARK_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PARK_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_STP_W__3214EC27FE6BCA6E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_TRANSPORTER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TRANSPORTER_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    TRANSPORTER_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    TRANSPORTER_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_TRANS__3214EC27370B48BF", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_UOM",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    UOM_SHORT_NAME = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    UOM_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_UOM__3214EC27D90AF169", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_USER_PRINTER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    USER_ID = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    PRINTER_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_USER___3214EC27C521CE78", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MS_VENDOR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    ALIAS_NAME = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    ADDRESS = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    CITY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    POSTAL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    REGION_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    CONTACT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PHONE_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PHONE_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    FAX_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    EMAIL = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    TAX_CODE = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    VENDOR_TYPE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true, defaultValue: "MAIN"),
                    PARENT_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MS_VENDO__3214EC27BBB5E4F9", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MT_CFC",
                columns: table => new
                {
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    CFC_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    DEF_LOT_QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CAL_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    FIRST_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    FIRST_MONTH = table.Column<short>(type: "smallint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ITO = table.Column<decimal>(type: "decimal(15,2)", nullable: true, defaultValue: 0m)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MT_CFC__D694A78FA80DA98C", x => x.CFC_CODE);
                });

            migrationBuilder.CreateTable(
                name: "MT_EMAIL_SETTING",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MAIL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROFILE_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    MAIL_FROM = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    MAIL_SUBJECT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    MAIL_BODY = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    MAIL_TO = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    MAIL_CC = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    PATH_ATTACHMENT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MT_EMAIL__3214EC27A2F3BD55", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "mt_prod_line",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    line_name = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_mt_prod_line", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "MT_VARIANT",
                columns: table => new
                {
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    VARIANT_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    KATASHIKI_CKD = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX_CKD = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    CLR_XLS = table.Column<int>(type: "int", nullable: true),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true, defaultValue: new DateTime(9999, 12, 31, 0, 0, 0, 0, DateTimeKind.Unspecified)),
                    CABIN = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    LOT_QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    BODY_OFFLINE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MT_VARIA__7BA6AC1FE08D6F88", x => new { x.KATASHIKI, x.SUFFIX });
                });

            migrationBuilder.CreateTable(
                name: "MT_VARIANT_DELETED",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    VARIANT_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    KATASHIKI_CKD = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX_CKD = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    CLR_XLS = table.Column<int>(type: "int", nullable: true),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true),
                    CABIN = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DELETED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    DELETED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_MT_VARIANT_DELETED", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "MT_VARIANT_FINISH_UNIT",
                columns: table => new
                {
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__MT_VARIA__0EC048CDF59F95CA", x => new { x.KATASHIKI, x.SUFFIX, x.MATERIAL_NO });
                });

            migrationBuilder.CreateTable(
                name: "MT_VARIANT_FINISH_UNIT_DELETED",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DELETED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    DELETED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_MT_VARIANT_FINISH_UNIT_DELETED", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "RB$DICT_FIELD",
                columns: table => new
                {
                    TABLE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    FIELD_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    FIELD_ALIAS = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    SELECTABLE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "T"),
                    SEARCHABLE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "T"),
                    SORTABLE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "T"),
                    DATA_TYPE = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    AUTO_SEARCH = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    MANDATORY = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    PRIMARY_KEY = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    REQUIRED_VALUE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    FIELD_TYPE = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    FIELD_SIZE = table.Column<int>(type: "int", nullable: true),
                    FIELD_PRECISION = table.Column<int>(type: "int", nullable: true),
                    FIELD_DISP_FMT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__RB$DICT___86D771FC11B8C750", x => new { x.TABLE_NAME, x.FIELD_NAME });
                });

            migrationBuilder.CreateTable(
                name: "RB$DICT_JOIN",
                columns: table => new
                {
                    TABLE_NAME1 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    TABLE_NAME2 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    JOIN_TYPE = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    FIELDNAMES1 = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    FIELDNAMES2 = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    JOIN_OPERATOR = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__RB$DICT___BFF6C3CFCC1654BA", x => new { x.TABLE_NAME1, x.TABLE_NAME2 });
                });

            migrationBuilder.CreateTable(
                name: "RB$DICT_TABLE",
                columns: table => new
                {
                    TABLE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    TABLE_ALIAS = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__RB$DICT___CF56543BF4B9566E", x => x.TABLE_NAME);
                });

            migrationBuilder.CreateTable(
                name: "RB$FOLDER",
                columns: table => new
                {
                    FOLDER_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FOLDER_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PARENT_ID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__RB$FOLDE__92AB9ADC6E0C0E0D", x => x.FOLDER_ID);
                });

            migrationBuilder.CreateTable(
                name: "RB$REPORT",
                columns: table => new
                {
                    REPORT_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FOLDER_ID = table.Column<int>(type: "int", nullable: true),
                    REPORT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    REPORT_SIZE = table.Column<int>(type: "int", nullable: true),
                    REPORT_TYPE = table.Column<int>(type: "int", nullable: true),
                    LAST_MODIFIED = table.Column<DateTime>(type: "datetime", nullable: true),
                    LAST_DELETED = table.Column<DateTime>(type: "datetime", nullable: true),
                    REPORT_TEMPLATE = table.Column<byte[]>(type: "image", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__RB$REPOR__B106F6BBAFEBBDEB", x => x.REPORT_ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_BOM_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    BOM_HEADER_ID = table.Column<long>(type: "bigint", nullable: false),
                    BOM_ID = table.Column<int>(type: "int", nullable: true),
                    BOM_MATERIAL = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    USAGE = table.Column<int>(type: "int", nullable: true),
                    ALTERNATIVE = table.Column<int>(type: "int", nullable: true),
                    VALID_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    BOM_LEVEL = table.Column<int>(type: "int", nullable: true),
                    BOM_PREDECESSOR = table.Column<int>(type: "int", nullable: true),
                    MULTI_LEVEL_BOM = table.Column<int>(type: "int", nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_BOM___3214EC270C101F29", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_BOM_HEADER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    BOM_ID = table.Column<int>(type: "int", nullable: true),
                    BOM_MATERIAL = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    USAGE = table.Column<int>(type: "int", nullable: true),
                    ALTERNATIVE = table.Column<int>(type: "int", nullable: true),
                    CHANGE_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    LOAD_DETAIL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    BOM_DETAIL_ID = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_BOM___3214EC27F1346EEE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_GR_SA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    MAT_DOC = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MAT_DOC_YEAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    NO_OKB = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    STATUS = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    REMARKS = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_GR_S__3214EC27D9849A16", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_INTF",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_GUID = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    INTF_FUNC = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    INTF_COMP_NAME = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    INTF_TIME_START = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    INTF_TIME_END = table.Column<DateTime>(type: "datetime", nullable: true),
                    INTF_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    INTF_CONFIRM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    INTF_MESSAGE = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    REF_ID = table.Column<long>(type: "bigint", nullable: true, defaultValue: 0L),
                    REF_INTF_ID = table.Column<long>(type: "bigint", nullable: true, defaultValue: 0L),
                    ID_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_INTF__3214EC27B7448C7E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_INTF_REQ",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    REQ_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    REQ_MESSAGE = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    REQ_FILENAME = table.Column<string>(type: "varchar(256)", unicode: false, maxLength: 256, nullable: true),
                    REQ_PATH = table.Column<string>(type: "varchar(256)", unicode: false, maxLength: 256, nullable: true),
                    ID_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_INTF__3214EC279F0B3C64", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_INTF_RESEND",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    INT_RESEND_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_INTF__3214EC279EDE172E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_INTF_RESP",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RESP_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    RESP_MESSAGE = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    RESP_FILENAME = table.Column<string>(type: "varchar(256)", unicode: false, maxLength: 256, nullable: true),
                    RESP_PATH = table.Column<string>(type: "varchar(256)", unicode: false, maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_INTF__3214EC279412C44F", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_REQ_GR_SA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    ID_NO = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_REQ___3214EC27A12A9E29", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_BOM_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    BOM_ID = table.Column<int>(type: "int", nullable: true),
                    BOM_MATERIAL = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    USAGE = table.Column<int>(type: "int", nullable: true),
                    ALTERNATIVE = table.Column<int>(type: "int", nullable: true),
                    VALID_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    BOM_LEVEL = table.Column<int>(type: "int", nullable: true),
                    BOM_PREDECESSOR = table.Column<int>(type: "int", nullable: true),
                    MULTI_LEVEL_BOM = table.Column<int>(type: "int", nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC2724E4236E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_BOM_HEADER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    BOM_ID = table.Column<int>(type: "int", nullable: true),
                    BOM_MATERIAL = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MATERIAL_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    USAGE = table.Column<int>(type: "int", nullable: true),
                    ALTERNATIVE = table.Column<int>(type: "int", nullable: true),
                    CHANGE_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    LOAD_DETAIL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    INTF_DETAIL = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC27B1B6E643", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_GR_SA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    MAT_DOC = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    MAT_DOC_YEAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    NO_OKB = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC27779EB59D", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_GR_SA_OUTPUT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    STATUS = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    REMARKS = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC2721394AC3", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_MAT_DOC_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    MAT_DOC_HEADER_ID = table.Column<long>(type: "bigint", nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SLOC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC2755F738F6", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_MAT_DOC_HEADER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    MATERIAL_DOC = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_HEADER_TEXT = table.Column<string>(type: "varchar(200)", unicode: false, maxLength: 200, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC275F32CA0E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_QUOTA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    UOM_CODE = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MIN_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    QUOTA_ITEM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PROC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PERCT_QUOTA = table.Column<decimal>(type: "decimal(18,5)", nullable: true),
                    ALLOC_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    QUOTA_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC27F8FD755B", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_SA_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    SA_HEADER_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SLOC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    TARGET_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    NET_PRICE = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    SC_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SUPP_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DELETE_IND = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC2746DBEAF9", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_SA_HEADER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CREATE_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PAYMENT_TERM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_ORG = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CURR_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    EXCH_RATE = table.Column<decimal>(type: "decimal(18,5)", nullable: true),
                    VALID_START_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_END_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC275B622541", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_SA_LIST",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DETAIL_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    CHANGE_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    LOAD_DETAIL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    MARK_SA = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    SA_HEADER_ID = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC2769A8ABC4", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_RESP_VENDOR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_ALIAS = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    VENDOR_ADDRESS = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    VENDOR_DISTRICT = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_POSTAL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CITY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_REGION_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    VENDOR_REGION_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    VENDOR_COUNTRY_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_TELP_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_TELP_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_FAX_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_TAX_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_RESP__3214EC272D9F282E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_SA_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_HEADER_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SLOC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    TARGET_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    NET_PRICE = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    SC_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SUPP_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DELETE_IND = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_SA_D__3214EC279E6BF519", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_SA_HEADER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CREATE_DATE_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PAYMENT_TERM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_ORG = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CURR_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    EXCH_RATE = table.Column<decimal>(type: "decimal(18,5)", nullable: true),
                    VALID_START_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_END_CHAR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_SA_H__3214EC27C07758B0", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_SA_LIST",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DETAIL_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    CHANGE_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    LOAD_DETAIL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    MARK_SA = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    SA_HEADER_ID = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_SA_L__3214EC27E7DB4C40", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_SA_LIST_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SA_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DETAIL_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    CHANGE_INTF_ID = table.Column<long>(type: "bigint", nullable: true),
                    LOAD_DETAIL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    MARK_SA = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    SA_HEADER_ID = table.Column<long>(type: "bigint", nullable: true),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_SA_L__3214EC2797DB95B7", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SAP_VENDOR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_ALIAS = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    VENDOR_ADDRESS = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    VENDOR_DISTRICT = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_POSTAL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CITY = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_REGION_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    VENDOR_REGION_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_COUNTRY_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    VENDOR_COUNTRY_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    VENDOR_TELP_NO1 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_TELP_NO2 = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_FAX_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_TAX_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SAP_VEND__3214EC27B68A0E7D", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "sec_refresh_token",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    token = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    jwt_id = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    sec_user_id = table.Column<int>(type: "int", nullable: false),
                    expired_date = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    revoked_date = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    revoked_from = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    invalidated = table.Column<bool>(type: "bit", nullable: false),
                    created_date = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    created_from = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_refresh_token", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sec_role",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    name_normalized = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    role_description = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    NormalizedName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    concurrency_stamp = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_role", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sec_user",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    email_confirm_token = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    email_confirmed_time = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    reset_token = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    reset_token_expire = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    reset_token_time = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    plant_code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    warehouse_code = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    username = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    username_normalized = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    email_normalized = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    email_confirmed = table.Column<bool>(type: "bit", nullable: false),
                    password_hash = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    security_stamp = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    concurrency_stamp = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    phone_number = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    phone_number_confirmed = table.Column<bool>(type: "bit", nullable: false),
                    two_factor_enabled = table.Column<bool>(type: "bit", nullable: false),
                    lockout_end = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    lockout_enabled = table.Column<bool>(type: "bit", nullable: false),
                    access_failed_count = table.Column<int>(type: "int", nullable: false),
                    fullname = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    disabled = table.Column<bool>(type: "bit", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_user", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "SET_PARAM",
                columns: table => new
                {
                    PARAM_GROUP = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    PARAM_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    PARAM_NAME1 = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PARAM_TYPE = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    PARAM_VALUE = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PARAM_FORMAT = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    PARAM_DESC = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SET_PARA__E5B0D13680DC81F1", x => new { x.PARAM_GROUP, x.PARAM_NAME });
                });

            migrationBuilder.CreateTable(
                name: "SET_PP_RANK_NO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    START_NO = table.Column<int>(type: "int", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATED_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SET_PP_R__3214EC2727F05CFF", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$AUTO_DOC_NO",
                columns: table => new
                {
                    DOC_ID = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    DOC_NO = table.Column<int>(type: "int", nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    LAST_UPDATED = table.Column<DateTime>(type: "datetime", nullable: true),
                    LAST_UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$AUTO__C41D45C2A15504DF", x => x.DOC_ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$DOC_GROUP",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_GROUP_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DOC_GROUP_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$DOC___3214EC274C0CBF0F", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$DOC_HEADER",
                columns: table => new
                {
                    DOC_ID = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PREFIX_HEADER = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    FORMAT_DATE = table.Column<string>(type: "varchar(6)", unicode: false, maxLength: 6, nullable: true),
                    DEF_NO_SIZE = table.Column<short>(type: "smallint", nullable: true),
                    DESCRIPTION = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    DOC_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$DOC___C41D45C2FD3DF896", x => x.DOC_ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$DOC_NO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_PREFIX = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    LAST_SERIAL = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$DOC___3214EC27FF02FBD1", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$DOC_NO_LIST",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DOC_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    SESSION_ID = table.Column<long>(type: "bigint", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$DOC___3214EC27DE1386DB", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$DOC_TYPE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_TYPE_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DOC_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DOC_PREFIX_FIX = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    DOC_PREFIX_RST = table.Column<string>(type: "varchar(6)", unicode: false, maxLength: 6, nullable: true),
                    DOC_SERIAL_SIZE = table.Column<int>(type: "int", nullable: false, defaultValue: 10),
                    DOC_TYPE_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$DOC___3214EC2755698919", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "SYS$IMP_TXT",
                columns: table => new
                {
                    IMP_NO = table.Column<int>(type: "int", nullable: false),
                    IMP_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    DELIMITED = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)9),
                    IMP_MODE = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    TABLE_NAME = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    IMP_MAP = table.Column<string>(type: "varchar(4000)", unicode: false, maxLength: 4000, nullable: true),
                    IMP_KEY = table.Column<string>(type: "varchar(512)", unicode: false, maxLength: 512, nullable: true),
                    FORMATDATE = table.Column<int>(type: "int", nullable: true),
                    FORMATTIME = table.Column<int>(type: "int", nullable: true),
                    IS_FIELD_NULL = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N"),
                    TRAILING_NEGATIVE = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N"),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true, defaultValueSql: "(user_name())"),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATED_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DISABLE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DISABLE_BY = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$IMP___11F0A57789BC8858", x => x.IMP_NO);
                });

            migrationBuilder.CreateTable(
                name: "SYS$SESSION_ID",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SESS_ID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    USER_ID = table.Column<long>(type: "bigint", nullable: false),
                    LOGIN_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    LOGIN_FROM = table.Column<long>(type: "bigint", nullable: false),
                    COMPUTER_NAME = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    COMPUTER_IP = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    APP_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    APP_VER = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    LAST_TICK = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CLOSED_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    CLOSED_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__SYS$SESS__3214EC276F1F6203", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TL_INTF",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SESSION_ID = table.Column<long>(type: "bigint", nullable: false),
                    FUNC_ID = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    FUNC_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    LOG_START = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    LOG_END = table.Column<DateTime>(type: "datetime", nullable: true),
                    LOG_PARAM = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    LOG_RESULT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TL_INTF__3214EC2715EA03DF", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TL_INTF_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    INTF_ID = table.Column<long>(type: "bigint", nullable: false),
                    LOG_TIME = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    ACT_ID = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    ACT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: false),
                    LOG_ID = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    LOG_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    LOG_MSG = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TL_INTF___3214EC271A5ECA9C", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tl_intf_rec",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    intf_time = table.Column<DateTime>(type: "datetime", nullable: false, defaultValueSql: "(getdate())"),
                    intf_filename = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    func_id = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    func_name = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    intf_msg = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tl_intf_rec", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tl_intf_rec_err",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    rec_id = table.Column<long>(type: "bigint", nullable: false),
                    line_no = table.Column<int>(type: "int", nullable: false),
                    err_no = table.Column<int>(type: "int", nullable: false),
                    err_msg = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tl_intf_rec_err", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TMP_OKB",
                columns: table => new
                {
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "tmp_ord_item",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    cfc_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    vendor_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    rank_lot_id = table.Column<long>(type: "bigint", nullable: true),
                    material_type = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    set_material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    qty_unit = table.Column<int>(type: "int", nullable: true),
                    qty_set = table.Column<int>(type: "int", nullable: true),
                    qty_ord = table.Column<int>(type: "int", nullable: true),
                    qty_per_box = table.Column<int>(type: "int", nullable: true),
                    qty_box = table.Column<int>(type: "int", nullable: true),
                    po_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    po_item_no = table.Column<int>(type: "int", nullable: true),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ord_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tmp_ord___3213E83FE22FAF4B", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_CKD_STOCK_LOT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    LOT_NO = table.Column<int>(type: "int", nullable: false),
                    AVL_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    QTY = table.Column<int>(type: "int", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true),
                    STOCK_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STOCK_DESC = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    MODEL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PROD_ORD = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_CKD_S__3214EC27C98DA1A2", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_LOG",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LOG_NAME = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    LOG_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    LOG_MESSAGE = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_LOG__3214EC277F9B9E73", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_LOG_PRINTER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    USER_ID = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    RCV_STATION = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    PRINTER_NAME = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    REPORT_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_LOG_P__3214EC27B78D3206", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_mat",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    shop_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    qty_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_req = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    qty_ord = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    qty_rcv = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_material", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_ord",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_pos_prod_sche_id = table.Column<long>(type: "bigint", nullable: true),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    prod_year = table.Column<short>(type: "smallint", nullable: true),
                    prod_month = table.Column<short>(type: "smallint", nullable: true),
                    rank_no = table.Column<int>(type: "int", nullable: true),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    dn_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_ord", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_ord_day",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_pos_prod_sche_id = table.Column<long>(type: "bigint", nullable: true),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    prod_year = table.Column<short>(type: "smallint", nullable: true),
                    rank_no = table.Column<int>(type: "int", nullable: true),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    dn_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_ord_day", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_ord_dn",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pos_ckd_ord_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_pos_dn_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_ord_dn", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_ord_mat",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pos_ckd_ord_id = table.Column<long>(type: "bigint", nullable: false),
                    ms_pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    qty_req = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    tr_pos_ord_data_mat_id = table.Column<long>(type: "bigint", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_ord_mat", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ckd_quota",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ms_material_vendor_quota_id = table.Column<long>(type: "bigint", nullable: false),
                    vendor_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    prod_year = table.Column<short>(type: "smallint", nullable: true),
                    prod_month = table.Column<short>(type: "smallint", nullable: true),
                    qty_ord = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ckd_quota", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_create_dn",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    order_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    process_count = table.Column<int>(type: "int", nullable: false),
                    process_status = table.Column<int>(type: "int", nullable: false),
                    unordered_item_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    result_code = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    result_msg = table.Column<string>(type: "varchar(500)", unicode: false, maxLength: 500, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_create_dn", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_create_dn_sche",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pos_create_dn_id = table.Column<long>(type: "bigint", nullable: false),
                    pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    cfc_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    last_order_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    max_order_date_next = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tr_pos_c__3213E83F1FE8F32A", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_DN",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DN_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    DN_TYPE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    SAP_PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MATERIAL_CAT = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DOCK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PARK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DELIVERY_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    TRANSPORTER_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ROUTE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    DLV_TIME = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    DLV_CYCLE_NO = table.Column<int>(type: "int", nullable: true),
                    DN_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    PRINT_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    PRINT_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PRINT_BY = table.Column<long>(type: "bigint", nullable: true),
                    RCV_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    PICK_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    SJ_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    SJ_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true, defaultValue: "*")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_D__3214EC27EBB1D7C3", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_DN_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    HDR_ID = table.Column<long>(type: "bigint", nullable: true),
                    SAP_ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_PER_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PART_ORD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PART_RCV = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DN_DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    QTY_ALLC = table.Column<int>(type: "int", nullable: true, defaultValue: 0)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_D__3214EC2718B4C483", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_DN_DTL_SAP",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    SAP_ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DTL_ID = table.Column<long>(type: "bigint", nullable: true),
                    QTY_ORD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_D__3214EC272F0B1A00", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_DN_RANK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    HDR_ID = table.Column<long>(type: "bigint", nullable: true),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    CKD_LOT_NO = table.Column<int>(type: "int", nullable: true),
                    KATASHIKI_CKD = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    SUFFIX_CKD = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_D__3214EC272BDC4BD6", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_DN_RANK_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    HDR_ID = table.Column<long>(type: "bigint", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_PART_ORD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_D__3214EC27EB536586", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ds_session",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ds_session_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    channel_info = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    scan_user = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    scan_user_id = table.Column<long>(type: "bigint", nullable: true),
                    device_id = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    warehouse_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    rcv_station = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    connect_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    connect_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    disconnect_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ds_session", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_GR",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    GR_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    SAP_PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    REF_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    GR_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    DL_STATUS = table.Column<int>(type: "int", nullable: true),
                    DL_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DL_BY = table.Column<long>(type: "bigint", nullable: true),
                    SAP_MAT_DOC = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    SAP_MAT_DOC_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    POST_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DL_FS_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DL_FS_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    HDR_TEXT = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: true),
                    RCV_STATION = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    AUTO_PRINT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true, defaultValue: "N"),
                    SCAN_USERNAME = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_G__3214EC27664B9D50", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_GR_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DN_ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_RCV = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    GR_DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_G__3214EC276708AE15", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_GR_DTL_SAP",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    SAP_ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_RCV = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_G__3214EC277C299EA5", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_LPD",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LPD_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    LPD_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    LPD_YEAR = table.Column<short>(type: "smallint", nullable: true),
                    LPD_MONTH = table.Column<short>(type: "smallint", nullable: true),
                    LPD_FREQ = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    RCV_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_TR_POS_LPD", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_LPD_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LPD_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DN_ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_PER_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PART_ORD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PART_RCV = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PART_REMAIN = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_TR_POS_LPD_DTL", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_LPD_MAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MAIL_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    LPD_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MAIL_TO = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    MAIL_CC = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    FILE_ATTACHMENT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    DELIVER_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DELIVER_STATUS_MSG = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    DELIVER_TRY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DELIVERED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_TR_POS_LPD_MAIL", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_lpd_rpt_dtl",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    lpd_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    item_no = table.Column<int>(type: "int", nullable: false),
                    lpd_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    vendor_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    rpt_year = table.Column<short>(type: "smallint", nullable: true),
                    rpt_month = table.Column<short>(type: "smallint", nullable: true),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    plant_desc = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    cfc_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    lpd_status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    dn_item_no = table.Column<int>(type: "int", nullable: true),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    rcv_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    qty_part_ord = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_part_rcv = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    lpd_desc = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    lpd_freq = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_lpd_rpt_dtl", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_lpd_rpt_sum",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    rpt_year = table.Column<short>(type: "smallint", nullable: false),
                    rpt_month = table.Column<short>(type: "smallint", nullable: false),
                    vendor_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    lpd_freq = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    lpd_item_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    lpd_qty_issue = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_lpd_sum_rpt", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MPS_DLV",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    SAFETY_STOCK_UOM = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SAFETY_STOCK = table.Column<decimal>(type: "decimal(18,4)", nullable: false),
                    REL_RANK_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC2752E70DFD", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MPS_DLV_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MPS_DLV_ID = table.Column<long>(type: "bigint", nullable: false),
                    PS_MPS_ID = table.Column<long>(type: "bigint", nullable: false),
                    FIRST_SEQ = table.Column<int>(type: "int", nullable: false),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true),
                    PLAN_DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PLAN_DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC2766053B2E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_mrp",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ps_mps_id = table.Column<long>(type: "bigint", nullable: false),
                    shop_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false, defaultValue: "*"),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    uom_code = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    qty_per_unit = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    qty_per_box = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    req_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    req_shift = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    req_qty = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    req_qty_lot = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    rel_rank_id = table.Column<long>(type: "bigint", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_mrp", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_ORDER",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ORDER_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    DOCK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PARK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DELIVERY_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    TRANSPORTER_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ORDER_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    LEAD_TIME = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    SAFETY_STOCK_UOM = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SAFETY_STOCK = table.Column<decimal>(type: "decimal(18,4)", nullable: true),
                    VALID_FROM = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_TO = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC270D1D2375", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_ORDER_DN",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROC_ID = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    POS_MRP_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    SAP_PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    DLV_TIME = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    DLV_CYCLE = table.Column<int>(type: "int", nullable: false, defaultValue: 1),
                    INC_DATE = table.Column<short>(type: "smallint", nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    SAP_ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_PER_BOX = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_BOX = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_ORD = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC277F74F074", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_ORDER_ITEM",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MRP_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    PLAN_DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    PLAN_DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_PER_BOX = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 1m),
                    QTY_ORD_PLAN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_ORD_ADD = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_ORD = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_BOX = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_ORD_CARRY = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    POS_MRP_ORDER_ITEM_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    MATERIAL_SET_ID = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC27F1B90ECC", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_mrp_order_item_add",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    mrp_order_item_id = table.Column<long>(type: "bigint", nullable: false),
                    order_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    cfc_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    qty_ord_carry = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    mrp_order_item_id_alloc = table.Column<long>(type: "bigint", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_mrp_order_item_add", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_ORDER_SAP_PO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MRP_ORDER_ITEM_ID = table.Column<long>(type: "bigint", nullable: false),
                    POS_SAP_PO_DTL_ID = table.Column<long>(type: "bigint", nullable: false),
                    QTY_ORD = table.Column<decimal>(type: "decimal(18,3)", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC27C04CBF5E", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_data",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    ms_pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    ms_cal_id = table.Column<long>(type: "bigint", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    shop_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    order_type = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    lead_time = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    safety_stock_uom = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    safety_stock = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    ord_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    dlv_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    ord_date_next = table.Column<DateTime>(type: "datetime", nullable: true),
                    dlv_date_next = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_date_from = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_date_to_day = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift_to_day = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    prod_date_to = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift_to = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    tr_pos_prod_sche_id_from = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_from = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_from = table.Column<int>(type: "int", nullable: true),
                    tr_pos_prod_sche_id_to_day = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_to_day = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_to_day = table.Column<int>(type: "int", nullable: true),
                    tr_pos_prod_sche_id_to = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_to = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_to = table.Column<int>(type: "int", nullable: true),
                    tr_pos_prod_sche_id_to_ord_day = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_to_ord_day = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_to_ord_day = table.Column<int>(type: "int", nullable: true),
                    tr_pos_prod_sche_id_to_ord = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_to_ord = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_to_ord = table.Column<int>(type: "int", nullable: true),
                    minus_rank = table.Column<int>(type: "int", nullable: true),
                    rank_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_data", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_data_mat",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    tr_pos_ord_data_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_pos_prod_sche_id = table.Column<long>(type: "bigint", nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    rank_no = table.Column<int>(type: "int", nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: true),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    material_type = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    material_set = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    uom_code = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    qty_req = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    qty_per_box = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 1m),
                    qty_box = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    ms_material_vendor_quota_id = table.Column<long>(type: "bigint", nullable: true),
                    order_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    po_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    po_item_no = table.Column<int>(type: "int", nullable: true),
                    dlv_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    dlv_cycle = table.Column<int>(type: "int", nullable: true),
                    dlv_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    dlv_time = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_data_mat", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_data_quota_mat",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    item_no = table.Column<int>(type: "int", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_data_quota_mat", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_data_quota_mat_ckd",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pos_ord_data_quota_mat_id = table.Column<long>(type: "bigint", nullable: false),
                    item_no = table.Column<int>(type: "int", nullable: false),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    rank_no = table.Column<int>(type: "int", nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true, defaultValue: "**"),
                    qty_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_data_quota_mat_ckd", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_data_rank",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    ms_pos_order_id = table.Column<long>(type: "bigint", nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    rank_no = table.Column<int>(type: "int", nullable: false),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    dlv_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    dlv_cycle = table.Column<int>(type: "int", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true),
                    rank_order_no = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_data_rank", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_ord_dlv",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    prod_date_from = table.Column<DateTime>(type: "datetime", nullable: false),
                    prod_date_to = table.Column<DateTime>(type: "datetime", nullable: false),
                    prod_shift_to = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: false),
                    tr_pos_prod_sche_id_from = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_from = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_from = table.Column<int>(type: "int", nullable: true),
                    tr_pos_prod_sche_id_to = table.Column<long>(type: "bigint", nullable: true),
                    prod_year_to = table.Column<short>(type: "smallint", nullable: true),
                    rank_no_to = table.Column<int>(type: "int", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_ord_dlv", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_ORDER_SCHE",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    ORDER_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    PLAN_DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    ORDER_DATE_NEXT = table.Column<DateTime>(type: "datetime", nullable: false),
                    PLAN_DLV_DATE_NEXT = table.Column<DateTime>(type: "datetime", nullable: false),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_O__3214EC27AB9BB4E8", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_PICK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PICK_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    PICK_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    TRANSPORTER_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    ROUTE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DOCK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PARK_NO = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    DLV_TIME = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    DLV_CYCLE_NO = table.Column<int>(type: "int", nullable: true),
                    PICK_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    PRINT_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    PRINT_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PRINT_BY = table.Column<long>(type: "bigint", nullable: true),
                    RCV_STATUS = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_P__3214EC2737FFEBDF", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_PICK_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PICK_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    HDR_ID = table.Column<long>(type: "bigint", nullable: true),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    PICK_DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_P__3214EC27CC752061", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_prod_sche",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    rank_no = table.Column<int>(type: "int", nullable: false),
                    unit_dlv_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    unit_dlv_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: true),
                    lot_no = table.Column<int>(type: "int", nullable: true),
                    qty_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status_ord = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_prod_sche", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_prod_sche_del",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pos_prod_sche_id = table.Column<long>(type: "bigint", nullable: true),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    prod_year = table.Column<short>(type: "smallint", nullable: true),
                    rank_no = table.Column<int>(type: "int", nullable: true),
                    unit_dlv_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    unit_dlv_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: true),
                    tr_ckd_id = table.Column<long>(type: "bigint", nullable: true),
                    lot_no = table.Column<int>(type: "int", nullable: true),
                    qty_unit = table.Column<int>(type: "int", nullable: true),
                    status_ord = table.Column<short>(type: "smallint", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tr_pos_prod_sche_del", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_RANK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    CKD_STOCK_ID = table.Column<long>(type: "bigint", nullable: false),
                    REL_RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    TCF_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    TCF_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DN_COUNT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_R__3214EC2763BA85A5", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_RCV",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RCV_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    RCV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    SAP_PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    REF_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    WAREHOUSE_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_SITE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    RCV_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    GR_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    HDR_TEXT = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: true),
                    RCV_STATION = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_R__3214EC271ECA4A80", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_RCV_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RCV_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    DN_ITEM_NO = table.Column<int>(type: "int", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_BOX = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_RCV = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    RCV_DTL_DESC100 = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_R__3214EC27337C00CC", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_SAP_PO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    PO_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DOC_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    VENDOR_ID = table.Column<long>(type: "bigint", nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_ORG = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PURCH_GROUP = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VALID_START = table.Column<DateTime>(type: "datetime", nullable: true),
                    VALID_END = table.Column<DateTime>(type: "datetime", nullable: true),
                    PO_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    TOT_ITEM = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    TOT_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    TOT_DN_ITEM = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    TOT_DN_QTY = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    LAST_DN_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    OS_QTY = table.Column<decimal>(type: "decimal(19,3)", nullable: true, computedColumnSql: "([TOT_QTY]-[TOT_DN_QTY])", stored: false),
                    SAP_PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_S__3214EC27CD35F231", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_SAP_PO_DTL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_SAP_PO_ID = table.Column<long>(type: "bigint", nullable: false),
                    PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    MATERIAL_ID = table.Column<long>(type: "bigint", nullable: true),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    SLOC_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    QTY_PO = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_DN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_GR = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_ALLOC = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    SC_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SUPP_VENDOR = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    VENDOR_NAME = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    DELETE_IND = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PO_DTL_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    QTY_ALLC = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    LAST_DN_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    OS_QTY = table.Column<decimal>(type: "decimal(19,3)", nullable: true, computedColumnSql: "([QTY_PO]-[QTY_DN])", stored: false),
                    SAP_PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_S__3214EC27E48C13DD", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_SAP_PO_HIST",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HIST_TYPE = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true),
                    PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    PO_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    DELETE_DATE = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_S__3214EC27B09BDAEC", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_scan_data",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ds_session_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    session_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    scan_type = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: false),
                    scan_data = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    scan_message = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_scan_data", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_scan_dn",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    session_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ref_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    warehouse_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    rcv_station = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    rcv_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    rcv_desc = table.Column<string>(type: "varchar(250)", unicode: false, maxLength: 250, nullable: true),
                    tags_count = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    scan_by = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    scan_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    rcv_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_scan_dn", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pos_scan_dn_part",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    session_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    seq_no = table.Column<int>(type: "int", nullable: false),
                    item_no = table.Column<int>(type: "int", nullable: true),
                    rcv_item_no = table.Column<int>(type: "int", nullable: true),
                    rcv_qty = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    rcv_box = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pos_scan_dn_part", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_SJ_MAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROC_ID = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    MAIL_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    VENDOR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    MAIL_TO = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    MAIL_CC = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    PROCESS_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    COUNT_DN = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    FILE_ATTACHMENT = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    DELIVER_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DELIVER_STATUS_MSG = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    DELIVER_TRY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DELIVERED_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_S__3214EC270E6A54C6", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_DAILY",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    SHOP_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: true),
                    RELEASE_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    REVISION_NO = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    REVISION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    DAILY_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    OBSELETE_BY_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATED_BY = table.Column<long>(type: "bigint", nullable: true),
                    WCTR_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true, defaultValue: "*"),
                    PFLOW_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    UNIT_ADV = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_DA__3214EC2787CF6D5C", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_DAILY_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DAILY_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    PROD_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    PROD_QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CKD_LOT_NO = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATED_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_DA__3214EC2768169320", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_DAILY_DTL_DATA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DAILY_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    PROD_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    REL_RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    CKD_LOT_NO = table.Column<int>(type: "int", nullable: false),
                    FIRST_SEQ = table.Column<int>(type: "int", nullable: true, defaultValue: 1),
                    QTY_UNIT = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_LOT = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_DA__3214EC279B313CFE", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_DATA",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    STOCK_OPEN = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PROD = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_SALES = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STOCK_END = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PROD_LOT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PROD_CALC = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_PER_LOT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    DATA_TYPE = table.Column<short>(type: "smallint", nullable: true),
                    IMP_NO = table.Column<long>(type: "bigint", nullable: true),
                    HJNK_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    QTY_PROD_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_DA__3214EC2794E6F4E4", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_DATA_DETAIL",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TR_PP_DATA_ID = table.Column<long>(type: "bigint", nullable: false),
                    MODEL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    QTY_PER_LOT = table.Column<int>(type: "int", nullable: false),
                    LOT_ALLOC = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_DA__3214EC278467366C", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_HJNK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    HJNK_TYPE = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    DATE_FROM = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_HJ__3214EC27A399E76D", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_HJNK_CALC",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HJNK_ID = table.Column<long>(type: "bigint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    QTY_PER_LOT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_HJNK = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_ACC = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_HJ__3214EC27C59624B7", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_HJNK_LIST",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HJNK_ID = table.Column<long>(type: "bigint", nullable: false),
                    ORDER_NO = table.Column<int>(type: "int", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    QTY_PER_LOT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_HJ__3214EC27CADA35CA", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_RANK_LOT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    HJNK_LIST_ID = table.Column<long>(type: "bigint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    CKD_STOCK_ID = table.Column<int>(type: "int", nullable: true),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    TCF_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    TCF_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    MODEL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    BODY_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    RIVET_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    OFFLINE_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_RA__3214EC273E472954", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_RANK_UNIT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    SEQ_NO = table.Column<int>(type: "int", nullable: false),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_RA__3214EC271A0DE0F0", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_REL_RANK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    RANK_TYPE = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    COMMENTS = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true),
                    RELEASE_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    REVISION_NO = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    REVISION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    RANK_STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    OBSELETE_BY_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATED_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATED_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATED_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATED_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_RE__3214EC27EBA1D776", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_REL_RANK_LOT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    REL_RANK_ID = table.Column<long>(type: "bigint", nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    HJNK_LIST_ID = table.Column<long>(type: "bigint", nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    CKD_STOCK_ID = table.Column<int>(type: "int", nullable: false),
                    QTY_UNIT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    TCF_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    REVISION_NO = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    REVISION_DATE = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    TCF_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    MODEL_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    BODY_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    RIVET_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    OFFLINE_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_RE__3214EC27A022D341", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TR_PP_REL_RANK_UNIT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    REL_RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    RANK_UNIT_ID = table.Column<long>(type: "bigint", nullable: false),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    SEQ_NO = table.Column<int>(type: "int", nullable: false),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PP_RE__3214EC2769D5DF5F", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_cal_work",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    cal_id = table.Column<long>(type: "bigint", nullable: false),
                    cal_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    cal_source = table.Column<short>(type: "smallint", nullable: true),
                    status_work = table.Column<short>(type: "smallint", nullable: true),
                    capacity_day = table.Column<short>(type: "smallint", nullable: true),
                    ms_cal_work_id = table.Column<long>(type: "bigint", nullable: true),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_cal_work", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_cal_work_shift",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_cal_work_id = table.Column<long>(type: "bigint", nullable: false),
                    cal_work_id = table.Column<long>(type: "bigint", nullable: false),
                    cal_shift = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    status_work = table.Column<short>(type: "smallint", nullable: true),
                    status_ot = table.Column<short>(type: "smallint", nullable: true),
                    capacity_std = table.Column<int>(type: "int", nullable: true),
                    capacity_ot = table.Column<int>(type: "int", nullable: true),
                    time_start = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    time_end = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    ms_cal_work_shift_id = table.Column<long>(type: "bigint", nullable: true),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_cal_work_shift", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_ckd_list",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    tr_ckd_stock_lot_id = table.Column<long>(type: "bigint", nullable: false),
                    katashiki_ckd = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix_ckd = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    prod_ord = table.Column<long>(type: "bigint", nullable: false),
                    model_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    qty_per_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    run_qty_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    run_qty_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    tr_pp_rp_rank_lot_id = table.Column<long>(type: "bigint", nullable: true),
                    is_paired = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_ckd_list", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_ckd_model_diff",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    is_left = table.Column<short>(type: "smallint", nullable: false),
                    katashiki_ckd = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix_ckd = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    model_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    qty_per_lot = table.Column<int>(type: "int", nullable: false),
                    lot_alloc = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_ckd_model_diff", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_ckd_variant",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    katashiki_ckd = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix_ckd = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    variant_count = table.Column<int>(type: "int", nullable: false),
                    sum_qty_prod = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    sum_qty_prod_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    sum_qty_prod_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    tr_ckd_stock_lot_id = table.Column<long>(type: "bigint", nullable: true),
                    ckd_prod_ord = table.Column<long>(type: "bigint", nullable: true),
                    total_ckd_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    total_ckd_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    is_exceed = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)1),
                    variant_lot_qty = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    remain_qty_prod = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    add_ckd_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    add_ckd_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_ckd_variant", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_data",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    katashiki_ckd = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix_ckd = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    variant_lot_qty = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_sales = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_prod = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_prod_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_prod_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    add_ckd_lot = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    add_ckd_unit = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    tr_pp_data_id = table.Column<long>(type: "bigint", nullable: false),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_data", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_data_detail",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_data_id = table.Column<long>(type: "bigint", nullable: false),
                    model_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    qty_per_lot = table.Column<int>(type: "int", nullable: false),
                    lot_alloc = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    lot_paired = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    tr_pp_data_detail_id = table.Column<long>(type: "bigint", nullable: false),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_data_detail", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_hjnk",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    qty = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_hjnk = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    qty_acc = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_hjnk", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_hjnk_list",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    order_no = table.Column<int>(type: "int", nullable: false),
                    tr_pp_rp_hjnk_id = table.Column<long>(type: "bigint", nullable: false),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_hjnk_list", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_proc",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    proc_id = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    prod_month = table.Column<short>(type: "smallint", nullable: false),
                    cfc_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    hjnk_type = table.Column<short>(type: "smallint", nullable: true),
                    from_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    version_no = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_proc", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_proc_detail",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    order_no = table.Column<int>(type: "int", nullable: false),
                    proc_name = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    proc_status = table.Column<int>(type: "int", nullable: false),
                    proc_message = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_proc_detail", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_rank_lot",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_proc_id = table.Column<long>(type: "bigint", nullable: false),
                    rank_no = table.Column<int>(type: "int", nullable: false),
                    hjnk_list_id = table.Column<long>(type: "bigint", nullable: false),
                    katashiki = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    suffix = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false),
                    ckd_stock_id = table.Column<long>(type: "bigint", nullable: true),
                    qty_unit = table.Column<int>(type: "int", nullable: true),
                    unit_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    part_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    tcf_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    prod_shift = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    tcf_shift = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    model_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    body_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    rivet_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    offline_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    tr_pp_rank_lot_id = table.Column<long>(type: "bigint", nullable: false),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_rank_lot", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pp_rp_rank_unit",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    tr_pp_rp_rank_lot_id = table.Column<long>(type: "bigint", nullable: false),
                    rank_lot_id = table.Column<long>(type: "bigint", nullable: false),
                    seq_no = table.Column<int>(type: "int", nullable: false),
                    prod_shift = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    unit_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    part_delivery_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    tr_pp_rank_unit_id = table.Column<long>(type: "bigint", nullable: false),
                    last_updated = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pp_rp_rank_unit", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_pps_act_prod",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    plant_code = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    line_code = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    prod_year = table.Column<short>(type: "smallint", nullable: false),
                    prod_date = table.Column<DateTime>(type: "datetime", nullable: false),
                    rank_no_last = table.Column<int>(type: "int", nullable: false),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_pps_act_prod", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_print_doc",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    resp_id = table.Column<long>(type: "bigint", nullable: false),
                    doc_type = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    doc_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    printer_name = table.Column<string>(type: "varchar(256)", unicode: false, maxLength: 256, nullable: true),
                    report_name = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    print_status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    print_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    result_code = table.Column<int>(type: "int", nullable: true),
                    result_message = table.Column<string>(type: "varchar(1024)", unicode: false, maxLength: 1024, nullable: true),
                    status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    created_date = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__tr_print__3213E83F9B57116A", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "TR_PS_MPS",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PLANT_CODE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: false),
                    CFC_CODE = table.Column<string>(type: "varchar(5)", unicode: false, maxLength: 5, nullable: false),
                    PROD_YEAR = table.Column<short>(type: "smallint", nullable: false),
                    PROD_MONTH = table.Column<short>(type: "smallint", nullable: false),
                    RANK_NO = table.Column<int>(type: "int", nullable: false),
                    PROD_DATE = table.Column<DateTime>(type: "datetime", nullable: false),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: false),
                    KATASHIKI = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    SUFFIX = table.Column<string>(type: "varchar(2)", unicode: false, maxLength: 2, nullable: false, defaultValue: "**"),
                    RANK_LOT_ID = table.Column<long>(type: "bigint", nullable: false),
                    FIRST_SEQ = table.Column<int>(type: "int", nullable: true),
                    QTY_UNIT_LOT = table.Column<decimal>(type: "decimal(18,3)", nullable: true),
                    QTY_UNIT_SHIFT = table.Column<int>(type: "int", nullable: true),
                    REQ_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    REQ_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    REL_RANK_ID = table.Column<long>(type: "bigint", nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_PS_MP__3214EC275BC219D6", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "tr_scan_part_tag",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    scan_session = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    scan_data = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    scan_status = table.Column<short>(type: "smallint", nullable: true, defaultValue: (short)0),
                    scan_message = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: true),
                    scan_terminal = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    ref_type = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: true, defaultValue: ""),
                    ref_id = table.Column<long>(type: "bigint", nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_scan_part_tag", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_scan_rcv_dtl",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    material_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    seq_no = table.Column<int>(type: "int", nullable: false),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_scan_rcv_dtl", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tr_scan_rcv_hdr",
                columns: table => new
                {
                    id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    dn_no = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    scan_session = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    status = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    create_time = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    create_by = table.Column<long>(type: "bigint", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime", nullable: true),
                    update_by = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_tr_scan_rcv_hdr", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "sec_role_claim",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    sec_role_id = table.Column<int>(type: "int", nullable: false),
                    claim_type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    claim_value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_role_claim", x => x.id);
                    table.ForeignKey(
                        name: "fk_sec_role_claim_sec_role",
                        column: x => x.sec_role_id,
                        principalTable: "sec_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sec_token",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    link_code = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    token_type = table.Column<short>(type: "smallint", nullable: false),
                    sec_user_id = table.Column<int>(type: "int", nullable: false),
                    token = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    expired_time = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_token", x => x.id);
                    table.ForeignKey(
                        name: "fk_sec_token_sec_user",
                        column: x => x.sec_user_id,
                        principalTable: "sec_user",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sec_user_claim",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    sec_user_id = table.Column<int>(type: "int", nullable: false),
                    claim_type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    claim_value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_user_claim", x => x.id);
                    table.ForeignKey(
                        name: "fk_sec_user_claim_sec_user",
                        column: x => x.sec_user_id,
                        principalTable: "sec_user",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sec_user_login",
                columns: table => new
                {
                    login_provider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    provider_key = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    sec_user_id = table.Column<int>(type: "int", nullable: false, comment: "[1: Role | 2: Task]"),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    provider_display_name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_user_login", x => new { x.sec_user_id, x.login_provider, x.provider_key });
                    table.ForeignKey(
                        name: "fk_sec_user_login_sec_user",
                        column: x => x.sec_user_id,
                        principalTable: "sec_user",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sec_user_role",
                columns: table => new
                {
                    sec_user_id = table.Column<int>(type: "int", nullable: false),
                    sec_role_id = table.Column<int>(type: "int", nullable: false),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_user_role", x => new { x.sec_user_id, x.sec_role_id });
                    table.ForeignKey(
                        name: "fk_sec_user_role_sec_role",
                        column: x => x.sec_role_id,
                        principalTable: "sec_role",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "fk_sec_user_role_sec_user",
                        column: x => x.sec_user_id,
                        principalTable: "sec_user",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sec_user_token",
                columns: table => new
                {
                    sec_user_id = table.Column<int>(type: "int", nullable: false),
                    login_provider = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    status = table.Column<int>(type: "int", nullable: false),
                    create_time = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "(sysdatetime())"),
                    create_by = table.Column<int>(type: "int", nullable: true),
                    update_time = table.Column<DateTime>(type: "datetime2", nullable: true),
                    update_by = table.Column<int>(type: "int", nullable: true),
                    value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("pk_sec_user_token", x => new { x.sec_user_id, x.login_provider, x.name });
                    table.ForeignKey(
                        name: "fk_sec_user_token_sec_user",
                        column: x => x.sec_user_id,
                        principalTable: "sec_user",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_RANK_ID = table.Column<long>(type: "bigint", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    IS_SET = table.Column<short>(type: "smallint", nullable: false),
                    REQ_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    REQ_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    QTY_PER_UNIT = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_REQ = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_PO = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_DN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    DN_COUNT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC2774A3A2B3", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_R__05E3CDB6",
                        column: x => x.POS_RANK_ID,
                        principalTable: "TR_POS_RANK",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_RANK_UNIT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_RANK_ID = table.Column<long>(type: "bigint", nullable: false),
                    SEQ_NO = table.Column<int>(type: "int", nullable: false),
                    UNIT_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PART_DELIVERY_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    TCF_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PROD_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    TCF_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_R__3214EC27DC1818C3", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_RA__POS_R__0B9CA70C",
                        column: x => x.POS_RANK_ID,
                        principalTable: "TR_POS_RANK",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK_SET",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MRP_RANK_ID = table.Column<long>(type: "bigint", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    QTY_SET = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    QTY_REQ = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_PO = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_DN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    DN_COUNT = table.Column<int>(type: "int", nullable: true, defaultValue: 0),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC2775415560", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_M__06D7F1EF",
                        column: x => x.POS_MRP_RANK_ID,
                        principalTable: "TR_POS_MRP_RANK",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK_VND",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PROC_ID = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    POS_MRP_RANK_ID = table.Column<long>(type: "bigint", nullable: false),
                    POS_ORDER_ID = table.Column<long>(type: "bigint", nullable: false),
                    IS_MULTI = table.Column<short>(type: "smallint", nullable: false),
                    SAFETY_STOCK = table.Column<decimal>(type: "decimal(18,4)", nullable: true, defaultValue: 0m),
                    SAFETY_STOCK_UOM = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: true),
                    ORDER_TYPE = table.Column<string>(type: "varchar(10)", unicode: false, maxLength: 10, nullable: true),
                    PDLV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    PDLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    ORD_STATUS = table.Column<int>(type: "int", nullable: false),
                    QTY_PO = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    QTY_DN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    ORD_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DLV_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    DLV_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC273C14E38E", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_M__08C03A61",
                        column: x => x.POS_MRP_RANK_ID,
                        principalTable: "TR_POS_MRP_RANK",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK_UNIT",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_RANK_UNIT_ID = table.Column<long>(type: "bigint", nullable: false),
                    MATERIAL_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    REQ_DATE = table.Column<DateTime>(type: "datetime", nullable: true),
                    REQ_SHIFT = table.Column<string>(type: "char(1)", unicode: false, fixedLength: true, maxLength: 1, nullable: true),
                    QTY_PER_UNIT = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC272486090C", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_R__07CC1628",
                        column: x => x.POS_RANK_UNIT_ID,
                        principalTable: "TR_POS_RANK_UNIT",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK_VND_DN",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MRP_RANK_VND_ID = table.Column<long>(type: "bigint", nullable: false),
                    DN_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    QTY_DN = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC271C00AE2D", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_M__09B45E9A",
                        column: x => x.POS_MRP_RANK_VND_ID,
                        principalTable: "TR_POS_MRP_RANK_VND",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TR_POS_MRP_RANK_VND_PO",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    POS_MRP_RANK_VND_ID = table.Column<long>(type: "bigint", nullable: false),
                    PO_NO = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    ITEM_NO = table.Column<int>(type: "int", nullable: false),
                    QTY_PO = table.Column<decimal>(type: "decimal(18,3)", nullable: true, defaultValue: 0m),
                    STATUS = table.Column<int>(type: "int", nullable: false),
                    CREATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true, defaultValueSql: "(getdate())"),
                    CREATE_BY = table.Column<long>(type: "bigint", nullable: true),
                    UPDATE_TIME = table.Column<DateTime>(type: "datetime", nullable: true),
                    UPDATE_BY = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__TR_POS_M__3214EC2780AFA081", x => x.ID);
                    table.ForeignKey(
                        name: "FK__TR_POS_MR__POS_M__0AA882D3",
                        column: x => x.POS_MRP_RANK_VND_ID,
                        principalTable: "TR_POS_MRP_RANK_VND",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "uq_edn_supplier_dn",
                table: "edn_supplier_dn",
                columns: new[] { "rec_id", "line_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F43D349C9BF",
                table: "intf_mt_changesa_resp",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F430A1C7676",
                table: "intf_mt_getsadetail_resp",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F43DA8E1C3B",
                table: "intf_mt_getsadetail_resp_header",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F430A3DD52D",
                table: "intf_mt_getsadetail_resp_output_item",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F43242AFF17",
                table: "intf_mt_getsaheader_resp",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F43129B0655",
                table: "intf_mt_getsaheader_resp_output_item",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F4347E5ED81",
                table: "intf_mt_grsa_resp",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__intf_mt___87F45F43BB8CEA66",
                table: "intf_mt_grsa_resp_output_item",
                columns: new[] { "intf_id", "intf_level", "intf_seq" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_MS_CAL",
                table: "MS_CAL",
                columns: new[] { "PLANT_CODE", "CFC_CODE" });

            migrationBuilder.CreateIndex(
                name: "UQ__MS_CAL__7A38C99FA67207B1",
                table: "MS_CAL",
                column: "CAL_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_CAL_S__7486522461C05058",
                table: "MS_CAL_STANDARD",
                columns: new[] { "CAL_ID", "CAL_DOW", "CAL_SHIFT" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_CAL_W__DEBFBA49A5E1A3BA",
                table: "MS_CAL_WORK",
                columns: new[] { "CAL_ID", "CAL_DATE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_CAL_W__30C8F0234674C5FF",
                table: "MS_CAL_WORK_SHIFT",
                columns: new[] { "CAL_WORK_ID", "CAL_SHIFT" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_COUNT__FC7F59060C7DF478",
                table: "MS_COUNTRY",
                column: "COUNTRY_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__30D07C663F6AD950",
                table: "MS_MATERIAL",
                columns: new[] { "PLANT_CODE", "MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__44EAC086CF326BBE",
                table: "MS_MATERIAL_CATEGORY",
                column: "MATERIAL_CAT",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__0CB5B2A1AD8CD331",
                table: "MS_MATERIAL_SET",
                columns: new[] { "PLANT_CODE", "SET_MATERIAL_NO", "CHILD_MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "MS_MATERIAL_VARIANT_NDX1",
                table: "MS_MATERIAL_VARIANT",
                columns: new[] { "PLANT_CODE", "SHOP_CODE", "MATERIAL_NO" });

            migrationBuilder.CreateIndex(
                name: "NDX_MS_MATERIAL_VARIANT02",
                table: "MS_MATERIAL_VARIANT",
                columns: new[] { "PLANT_CODE", "KATASHIKI", "SUFFIX" });

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__5F9CC9F8B4854D7A",
                table: "MS_MATERIAL_VARIANT",
                columns: new[] { "BOM_ID", "PLANT_CODE", "SHOP_CODE", "MATERIAL_NO", "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_MS_MATERIAL_VENDOR1",
                table: "MS_MATERIAL_VENDOR",
                columns: new[] { "PLANT_CODE", "VENDOR_CODE", "VENDOR_SITE" });

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__B439E0D5A639EA1E",
                table: "MS_MATERIAL_VENDOR",
                columns: new[] { "PLANT_CODE", "MATERIAL_NO", "VENDOR_CODE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_MATER__8BC800485F9B678E",
                table: "MS_MATERIAL_VENDOR_QUOTA",
                columns: new[] { "PLANT_CODE", "MATERIAL_NO", "VENDOR_CODE", "PROD_YEAR", "PROD_MONTH" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_D__0CC2D1035FFB489F",
                table: "MS_POS_DELIVERY_TYPE",
                column: "DELIVERY_TYPE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_MS_POS_ORDER1",
                table: "MS_POS_ORDER",
                columns: new[] { "PLANT_CODE", "LEAD_TIME", "ORDER_TYPE", "VALID_FROM", "VALID_TO" });

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_O__F3DA05E797D0EE4C",
                table: "MS_POS_ORDER",
                columns: new[] { "PLANT_CODE", "SHOP_CODE", "VENDOR_CODE", "VENDOR_SITE", "WAREHOUSE_CODE", "MATERIAL_CAT" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_O__4295A153F1D82F45",
                table: "MS_POS_ORDER_CYCLE",
                columns: new[] { "POS_ORDER_ID", "ORDER_SHIFT", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_O__4ADA8A7B415FC3FA",
                table: "MS_POS_ORDER_FIXSC",
                columns: new[] { "POS_ORDER_ID", "DOW" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_O__EAECB4F84DB3FCD9",
                table: "MS_POS_ORDER_TYPE",
                column: "ORDER_TYPE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_POS_R__2730D5C2852E462B",
                table: "MS_POS_ROUTE",
                column: "ROUTE_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PRINT__ECF82B142020A440",
                table: "MS_PRINTER",
                column: "PRINTER_NAME",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_PR__AEF61ABBFB4D899E",
                table: "MS_PS_PROCESS_FLOW",
                column: "PFLOW_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_PR__64451327C7DEA867",
                table: "MS_PS_PROCESS_FLOW_DTL",
                columns: new[] { "PFLOW_CODE", "WCTR_CODE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_PR__66808A747EDA0079",
                table: "MS_PS_PROCESS_FLOW_DTL_LINK",
                columns: new[] { "PFLOW_CODE", "WCTR_CODE", "WCTR_NEXT" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_PR__7A3EB58B3E0999C6",
                table: "MS_PS_PROCESS_FLOW_DTL_VARIANT",
                columns: new[] { "PFLOW_CODE", "WCTR_CODE", "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_VA__7BA6AC1E80C2DDA1",
                table: "MS_PS_VARIANT_PROCESS_FLOW",
                columns: new[] { "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_PS_WO__AB3099CC5A739727",
                table: "MS_PS_WORKCENTER",
                column: "WCTR_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_REGIO__090E1F02673EDBFC",
                table: "MS_REGION",
                columns: new[] { "COUNTRY_CODE", "REGION_CODE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_STP_W__EF67B1B9D99828EB",
                table: "MS_STP_WAREHOUSE",
                column: "WAREHOUSE_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_STP_W__424A18BAF5729801",
                table: "MS_STP_WAREHOUSE_DOCK",
                columns: new[] { "WAREHOUSE_CODE", "PLANT_CODE", "DOCK_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_STP_W__7B9A61E4BCA4841A",
                table: "MS_STP_WAREHOUSE_PARK",
                columns: new[] { "WAREHOUSE_CODE", "PLANT_CODE", "PARK_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_TRANS__8D94EF09CB42F278",
                table: "MS_TRANSPORTER",
                column: "TRANSPORTER_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_UOM__A6A6D861ECB0C444",
                table: "MS_UOM",
                column: "UOM_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_USER___641C5EC771EE8C3E",
                table: "MS_USER_PRINTER",
                columns: new[] { "DOC_TYPE", "USER_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MS_VENDO__E99CB384CEC8FB5F",
                table: "MS_VENDOR",
                column: "VENDOR_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__MT_EMAIL__A22AB334349A0769",
                table: "MT_EMAIL_SETTING",
                column: "MAIL_CODE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_mt_prod_line",
                table: "mt_prod_line",
                columns: new[] { "plant_code", "line_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_MT_VARIANT",
                table: "MT_VARIANT",
                columns: new[] { "KATASHIKI_CKD", "SUFFIX_CKD", "KATASHIKI", "SUFFIX" });

            migrationBuilder.CreateIndex(
                name: "SAP_GR_SA_NDX1",
                table: "SAP_GR_SA",
                column: "INTF_ID");

            migrationBuilder.CreateIndex(
                name: "NDX_SAP_INTF",
                table: "SAP_INTF",
                column: "ID_NO");

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_INTF__F7D3602F970A0C5A",
                table: "SAP_INTF",
                column: "INTF_GUID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_SAP_INTF_REQ",
                table: "SAP_INTF_REQ",
                column: "INTF_ID");

            migrationBuilder.CreateIndex(
                name: "NDX1_SAP_REQ_GR_SA",
                table: "SAP_REQ_GR_SA",
                column: "ID_NO");

            migrationBuilder.CreateIndex(
                name: "NDX2_SAP_REQ_GR_SA",
                table: "SAP_REQ_GR_SA",
                column: "INTF_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F5DF6ABCAC",
                table: "SAP_RESP_BOM_DETAIL",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F5DC3C13B1",
                table: "SAP_RESP_BOM_HEADER",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__3F7DD730A408CB99",
                table: "SAP_RESP_GR_SA",
                column: "INTF_ID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F564C6F005",
                table: "SAP_RESP_GR_SA_OUTPUT",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F547400656",
                table: "SAP_RESP_MAT_DOC_DETAIL",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__F85E357D311E8399",
                table: "SAP_RESP_MAT_DOC_DETAIL",
                columns: new[] { "MAT_DOC_HEADER_ID", "ITEM_NO" },
                unique: true,
                filter: "[ITEM_NO] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__3F7DD730F14086F6",
                table: "SAP_RESP_MAT_DOC_HEADER",
                column: "INTF_ID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F547F7A7DB",
                table: "SAP_RESP_QUOTA",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__DF568AB98BF816F8",
                table: "SAP_RESP_SA_DETAIL",
                columns: new[] { "SA_HEADER_ID", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__09EE4ED4B8E50695",
                table: "SAP_RESP_SA_HEADER",
                columns: new[] { "INTF_ID", "SA_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F57D7D5088",
                table: "SAP_RESP_SA_LIST",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SAP_RESP__5B1D79F55493D7C8",
                table: "SAP_RESP_VENDOR",
                columns: new[] { "INTF_ID", "ORDER_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "SAP_SA_LIST_DETAIL_NDX1",
                table: "SAP_SA_LIST_DETAIL",
                columns: new[] { "DETAIL_INTF_ID", "ID" });

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_refresh_token_sec_user",
                table: "sec_refresh_token",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "uq_sec_refresh_token",
                table: "sec_refresh_token",
                column: "token",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_sec_role",
                table: "sec_role",
                column: "name_normalized",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_role_claim_sec_role",
                table: "sec_role_claim",
                column: "sec_role_id");

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_token_sec_user",
                table: "sec_token",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "uq_sec_token",
                table: "sec_token",
                column: "link_code",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_sec_user_email",
                table: "sec_user",
                column: "email_normalized");

            migrationBuilder.CreateIndex(
                name: "uq_sec_user_name",
                table: "sec_user",
                column: "username_normalized",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_user_claim_sec_user",
                table: "sec_user_claim",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_user_login_sec_user",
                table: "sec_user_login",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_user_role_sec_role",
                table: "sec_user_role",
                column: "sec_role_id");

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_user_role_sec_user",
                table: "sec_user_role",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "ixfk_sec_user_token_sec_user",
                table: "sec_user_token",
                column: "sec_user_id");

            migrationBuilder.CreateIndex(
                name: "UQ__SET_PP_R__E3347937CBCFCBDF",
                table: "SET_PP_RANK_NO",
                columns: new[] { "PLANT_CODE", "CFC_CODE", "PROD_YEAR" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SYS$DOC___96EA45A2EAE7DE7A",
                table: "SYS$DOC_GROUP",
                column: "DOC_GROUP",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SYS$DOC___328D9DCB7C8B7E0F",
                table: "SYS$DOC_NO",
                columns: new[] { "DOC_TYPE", "DOC_PREFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SYS$DOC___97666BB168BB922E",
                table: "SYS$DOC_NO_LIST",
                columns: new[] { "DOC_TYPE", "DOC_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__SYS$DOC___8B27B078E2D1500E",
                table: "SYS$DOC_TYPE",
                column: "DOC_TYPE",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IDX1_TL_INTF_DTL",
                table: "TL_INTF_DTL",
                column: "INTF_ID");

            migrationBuilder.CreateIndex(
                name: "uq_tl_intf_rec_err",
                table: "tl_intf_rec_err",
                columns: new[] { "rec_id", "line_no", "err_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tmp_ord_item",
                table: "tmp_ord_item",
                column: "proc_id");

            migrationBuilder.CreateIndex(
                name: "NDX_TR_CKD_STOCK_LOT",
                table: "TR_CKD_STOCK_LOT",
                columns: new[] { "PLANT_CODE", "KATASHIKI", "SUFFIX", "QTY", "MODEL_CODE", "STATUS", "PROD_ORD" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_CKD_S__2200E9A95655AF09",
                table: "TR_CKD_STOCK_LOT",
                columns: new[] { "PLANT_CODE", "PROD_YEAR", "PROD_MONTH", "KATASHIKI", "SUFFIX", "LOT_NO", "MODEL_CODE" },
                unique: true,
                filter: "[MODEL_CODE] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_material",
                table: "tr_pos_ckd_mat",
                columns: new[] { "tr_ckd_id", "shop_code", "material_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_ord",
                table: "tr_pos_ckd_ord",
                column: "tr_ckd_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_ord_day",
                table: "tr_pos_ckd_ord_day",
                column: "tr_ckd_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_ord_dn",
                table: "tr_pos_ckd_ord_dn",
                columns: new[] { "tr_pos_ckd_ord_id", "tr_pos_dn_id" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_ord_mat",
                table: "tr_pos_ckd_ord_mat",
                columns: new[] { "tr_pos_ckd_ord_id", "ms_pos_order_id", "line_code", "material_no" },
                unique: true,
                filter: "[material_no] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_ckd_quota",
                table: "tr_pos_ckd_quota",
                columns: new[] { "tr_ckd_id", "plant_code", "material_no", "ms_material_vendor_quota_id" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ckd_quota",
                table: "tr_pos_ckd_quota",
                columns: new[] { "tr_ckd_id", "plant_code", "material_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_create_dn",
                table: "tr_pos_create_dn",
                column: "proc_id");

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_create_dn",
                table: "tr_pos_create_dn",
                columns: new[] { "plant_code", "order_date", "process_count" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__tr_pos_c__6FA9432ED660BB1B",
                table: "tr_pos_create_dn_sche",
                columns: new[] { "tr_pos_create_dn_id", "pos_order_id", "cfc_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_DN",
                table: "TR_POS_DN",
                columns: new[] { "PLANT_CODE", "DLV_DATE", "DN_DATE", "RCV_STATUS" });

            migrationBuilder.CreateIndex(
                name: "NDX2_TR_POS_DN",
                table: "TR_POS_DN",
                column: "VENDOR_CODE");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_D__49FB2E6CFE00B36C",
                table: "TR_POS_DN",
                column: "DN_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_DN_DTL",
                table: "TR_POS_DN_DTL",
                columns: new[] { "QTY_PART_ORD", "QTY_PART_RCV" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_D__9324F2692BC1D0CB",
                table: "TR_POS_DN_DTL",
                columns: new[] { "DN_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_D__0A6AD3E223E55ACC",
                table: "TR_POS_DN_DTL_SAP",
                columns: new[] { "DN_NO", "ITEM_NO", "SAP_ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_D__89AC328C2B1A3F7E",
                table: "TR_POS_DN_RANK",
                columns: new[] { "DN_NO", "RANK_LOT_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_D__FCCAD65E76F28E0F",
                table: "TR_POS_DN_RANK_DTL",
                columns: new[] { "DN_NO", "RANK_LOT_ID", "MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_ds_session",
                table: "tr_pos_ds_session",
                columns: new[] { "scan_user", "connect_status", "connect_time" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_ds_session2",
                table: "tr_pos_ds_session",
                columns: new[] { "connect_status", "connect_time", "scan_user" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ds_session",
                table: "tr_pos_ds_session",
                column: "ds_session_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_TR_POS_GR",
                table: "TR_POS_GR",
                column: "DN_NO");

            migrationBuilder.CreateIndex(
                name: "ndx_TR_POS_GR2",
                table: "TR_POS_GR",
                column: "SAP_PO_NO");

            migrationBuilder.CreateIndex(
                name: "ndx_TR_POS_GR3",
                table: "TR_POS_GR",
                columns: new[] { "VENDOR_CODE", "REF_NO" });

            migrationBuilder.CreateIndex(
                name: "ndx_TR_POS_GR4",
                table: "TR_POS_GR",
                columns: new[] { "GR_NO", "SAP_PO_NO", "DL_FS_STATUS" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_G__80CBD898A92C7A92",
                table: "TR_POS_GR",
                column: "GR_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_G__5A14049DA8DE7133",
                table: "TR_POS_GR_DTL",
                columns: new[] { "GR_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_G__C35A2516E9A7C3DA",
                table: "TR_POS_GR_DTL_SAP",
                columns: new[] { "GR_NO", "ITEM_NO", "SAP_ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_LPD",
                table: "TR_POS_LPD",
                columns: new[] { "LPD_YEAR", "LPD_MONTH", "VENDOR_CODE" });

            migrationBuilder.CreateIndex(
                name: "uq_TR_POS_LPD",
                table: "TR_POS_LPD",
                column: "LPD_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_LPD_DTL",
                table: "TR_POS_LPD_DTL",
                columns: new[] { "STATUS", "LPD_NO", "ITEM_NO" });

            migrationBuilder.CreateIndex(
                name: "NDX2_TR_POS_LPD_DTL",
                table: "TR_POS_LPD_DTL",
                column: "STATUS");

            migrationBuilder.CreateIndex(
                name: "uq_TR_POS_LPD_DTL",
                table: "TR_POS_LPD_DTL",
                columns: new[] { "LPD_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_lpd_rpt_dtl",
                table: "tr_pos_lpd_rpt_dtl",
                columns: new[] { "rpt_year", "rpt_month", "vendor_code", "material_no" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_lpd_rpt_dtl",
                table: "tr_pos_lpd_rpt_dtl",
                columns: new[] { "lpd_no", "item_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_lpd_sum_rpt",
                table: "tr_pos_lpd_rpt_sum",
                columns: new[] { "rpt_year", "rpt_month", "vendor_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_MPS_DLV1",
                table: "TR_POS_MPS_DLV",
                columns: new[] { "PLANT_CODE", "CFC_CODE", "SAFETY_STOCK_UOM", "SAFETY_STOCK" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__D8D5AFBF4F940621",
                table: "TR_POS_MPS_DLV",
                columns: new[] { "PROD_YEAR", "PROD_MONTH", "PLANT_CODE", "CFC_CODE", "SAFETY_STOCK_UOM", "SAFETY_STOCK" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_MPS_DLV_DTL1",
                table: "TR_POS_MPS_DLV_DTL",
                column: "PLAN_DLV_DATE");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__DE3A7207D132173D",
                table: "TR_POS_MPS_DLV_DTL",
                columns: new[] { "POS_MPS_DLV_ID", "PS_MPS_ID", "FIRST_SEQ" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_mrp",
                table: "tr_pos_mrp",
                columns: new[] { "ps_mps_id", "material_no", "shop_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_MRP_ORDER1",
                table: "TR_POS_MRP_ORDER",
                column: "ORDER_DATE");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__A3CDEF9F0D422490",
                table: "TR_POS_MRP_ORDER",
                columns: new[] { "ORDER_DATE", "POS_ORDER_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "TR_POS_MRP_ORDER_DN_NDX1",
                table: "TR_POS_MRP_ORDER_DN",
                columns: new[] { "PROC_ID", "POS_MRP_ORDER_ID", "CFC_CODE", "DLV_DATE", "DLV_SHIFT", "DLV_TIME", "DLV_CYCLE" });

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_MRP_ORDER_ITEM4",
                table: "TR_POS_MRP_ORDER_ITEM",
                column: "POS_MRP_ORDER_ITEM_ID");

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_MRP_ORDER_ITEM5",
                table: "TR_POS_MRP_ORDER_ITEM",
                columns: new[] { "MATERIAL_SET_ID", "MATERIAL_NO" });

            migrationBuilder.CreateIndex(
                name: "TR_POS_MRP_ORDER_ITEM_NDX1",
                table: "TR_POS_MRP_ORDER_ITEM",
                columns: new[] { "POS_MRP_ORDER_ID", "CFC_CODE", "MATERIAL_NO" });

            migrationBuilder.CreateIndex(
                name: "TR_POS_MRP_ORDER_ITEM_NDX2",
                table: "TR_POS_MRP_ORDER_ITEM",
                columns: new[] { "POS_MRP_ORDER_ID", "CFC_CODE", "PROD_YEAR", "PROD_MONTH", "RANK_NO", "MATERIAL_NO" });

            migrationBuilder.CreateIndex(
                name: "TR_POS_MRP_ORDER_ITEM_NDX3",
                table: "TR_POS_MRP_ORDER_ITEM",
                columns: new[] { "PROD_YEAR", "PROD_MONTH", "MATERIAL_NO" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_mrp_order_item_add",
                table: "tr_pos_mrp_order_item_add",
                columns: new[] { "pos_order_id", "cfc_code", "material_no", "mrp_order_item_id_alloc", "qty_ord_carry" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_mrp_order_item_add",
                table: "tr_pos_mrp_order_item_add",
                column: "mrp_order_item_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__1E24DFA12787ADFB",
                table: "TR_POS_MRP_ORDER_SAP_PO",
                columns: new[] { "POS_MRP_ORDER_ITEM_ID", "POS_SAP_PO_DTL_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_POS_RANK_ID",
                table: "TR_POS_MRP_RANK",
                column: "POS_RANK_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__5CDFABD8E36F3FFE",
                table: "TR_POS_MRP_RANK",
                columns: new[] { "POS_RANK_ID", "MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_SET_POS_RANK_ID",
                table: "TR_POS_MRP_RANK_SET",
                column: "POS_MRP_RANK_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__1C99BB2EDB640DF9",
                table: "TR_POS_MRP_RANK_SET",
                columns: new[] { "POS_MRP_RANK_ID", "MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_UNIT_POS_MRP_RANK_ID",
                table: "TR_POS_MRP_RANK_UNIT",
                column: "POS_RANK_UNIT_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__6F73ABF6B066CC2D",
                table: "TR_POS_MRP_RANK_UNIT",
                columns: new[] { "POS_RANK_UNIT_ID", "MATERIAL_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_VND_POS_MRP_RANK_ID",
                table: "TR_POS_MRP_RANK_VND",
                column: "POS_MRP_RANK_ID");

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_VND_PROC_ID",
                table: "TR_POS_MRP_RANK_VND",
                columns: new[] { "PROC_ID", "ORDER_TYPE", "POS_ORDER_ID", "PDLV_DATE" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__149A6B2E859B23C3",
                table: "TR_POS_MRP_RANK_VND",
                columns: new[] { "POS_MRP_RANK_ID", "POS_ORDER_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_VND_DN_POS_MRP_RANK_VND_ID",
                table: "TR_POS_MRP_RANK_VND_DN",
                column: "POS_MRP_RANK_VND_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__E61835E09897D491",
                table: "TR_POS_MRP_RANK_VND_DN",
                columns: new[] { "POS_MRP_RANK_VND_ID", "DN_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_MRP_RANK_VND_PO_POS_MRP_RANK_VND_ID",
                table: "TR_POS_MRP_RANK_VND_PO",
                column: "POS_MRP_RANK_VND_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_M__176B52D8EF434C7A",
                table: "TR_POS_MRP_RANK_VND_PO",
                columns: new[] { "POS_MRP_RANK_VND_ID", "PO_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_data",
                table: "tr_pos_ord_data",
                columns: new[] { "proc_id", "ms_pos_order_id", "line_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_data_mat",
                table: "tr_pos_ord_data_mat",
                columns: new[] { "proc_id", "tr_pos_ord_data_id", "prod_year", "rank_no", "material_no" },
                unique: true,
                filter: "[material_no] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_data_quota_mat",
                table: "tr_pos_ord_data_quota_mat",
                columns: new[] { "proc_id", "item_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_data_quota_mat_ckd",
                table: "tr_pos_ord_data_quota_mat_ckd",
                columns: new[] { "tr_pos_ord_data_quota_mat_id", "item_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_data_rank",
                table: "tr_pos_ord_data_rank",
                columns: new[] { "proc_id", "ms_pos_order_id", "plant_code", "line_code", "prod_year", "rank_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_ord_dlv",
                table: "tr_pos_ord_dlv",
                columns: new[] { "proc_id", "plant_code", "line_code", "prod_date_from", "prod_date_to", "prod_shift_to" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_O__B34D387FEFB9327C",
                table: "TR_POS_ORDER_SCHE",
                columns: new[] { "POS_ORDER_ID", "CFC_CODE", "ORDER_DATE" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_P__AAD1C4B21C11E9A6",
                table: "TR_POS_PICK",
                column: "PICK_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_P__700E18B7DD438C85",
                table: "TR_POS_PICK_DTL",
                columns: new[] { "PICK_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_prod_sche",
                table: "tr_pos_prod_sche",
                column: "tr_ckd_id");

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_prod_sche02",
                table: "tr_pos_prod_sche",
                columns: new[] { "plant_code", "line_code", "prod_date", "prod_shift" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_prod_sche",
                table: "tr_pos_prod_sche",
                columns: new[] { "plant_code", "line_code", "prod_year", "rank_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_R__98B45BE95D6962EC",
                table: "TR_POS_RANK",
                columns: new[] { "PLANT_CODE", "CFC_CODE", "PROD_YEAR", "RANK_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_R__D2DF1EAB0D8B5F9B",
                table: "TR_POS_RANK",
                column: "CKD_STOCK_ID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "INDX_TR_POS_RANK_UNIT_POS_RANK_ID",
                table: "TR_POS_RANK_UNIT",
                column: "POS_RANK_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_R__7AFA778942C604F5",
                table: "TR_POS_RANK_UNIT",
                columns: new[] { "POS_RANK_ID", "SEQ_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_R__90ED0DF3DA9BCF95",
                table: "TR_POS_RCV",
                column: "RCV_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_R__4A32D1F692198048",
                table: "TR_POS_RCV_DTL",
                columns: new[] { "RCV_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "NDX_TR_POS_SAP_PO1",
                table: "TR_POS_SAP_PO",
                columns: new[] { "CFC_CODE", "VENDOR_CODE", "PO_STATUS" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_S__5ECD5DE31AED2788",
                table: "TR_POS_SAP_PO",
                column: "PO_NO",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_S__3A7335CA58CB7D18",
                table: "TR_POS_SAP_PO_DTL",
                columns: new[] { "POS_SAP_PO_ID", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_POS_S__841281E638B57BDC",
                table: "TR_POS_SAP_PO_DTL",
                columns: new[] { "PO_NO", "ITEM_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_data",
                table: "tr_pos_scan_data",
                columns: new[] { "session_id", "scan_type" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_data2",
                table: "tr_pos_scan_data",
                columns: new[] { "ds_session_id", "session_id", "scan_type" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_dn",
                table: "tr_pos_scan_dn",
                columns: new[] { "dn_no", "scan_status" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_dn2",
                table: "tr_pos_scan_dn",
                column: "rcv_no");

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_dn3",
                table: "tr_pos_scan_dn",
                columns: new[] { "plant_code", "warehouse_code", "rcv_station", "dn_no" });

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_dn4",
                table: "tr_pos_scan_dn",
                columns: new[] { "scan_by", "scan_status" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_scan_dn",
                table: "tr_pos_scan_dn",
                column: "session_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pos_scan_dn_part",
                table: "tr_pos_scan_dn_part",
                columns: new[] { "dn_no", "material_no", "seq_no" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pos_scan_dn_part",
                table: "tr_pos_scan_dn_part",
                columns: new[] { "session_id", "dn_no", "material_no", "seq_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "TR_PP_DAILY_NDX1",
                table: "TR_PP_DAILY",
                columns: new[] { "PROD_YEAR", "PROD_MONTH", "PLANT_CODE", "SHOP_CODE", "CFC_CODE", "WCTR_CODE", "DAILY_STATUS" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_DA__66CEFB3F2F92CA6E",
                table: "TR_PP_DAILY_DETAIL",
                columns: new[] { "DAILY_ID", "PROD_SHIFT", "PROD_DATE", "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "TR_PP_DAILY_DTL_DATA_NDX1",
                table: "TR_PP_DAILY_DTL_DATA",
                columns: new[] { "DAILY_ID", "PROD_SHIFT", "PROD_DATE", "KATASHIKI", "SUFFIX" });

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_DA__B9C6EACEB57FF421",
                table: "TR_PP_DAILY_DTL_DATA",
                columns: new[] { "DAILY_ID", "PROD_SHIFT", "PROD_DATE", "REL_RANK_LOT_ID" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_DA__56B9161407BDA25C",
                table: "TR_PP_DATA",
                columns: new[] { "PLANT_CODE", "PROD_YEAR", "PROD_MONTH", "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_DA__6C6602176BEFC361",
                table: "TR_PP_DATA_DETAIL",
                columns: new[] { "TR_PP_DATA_ID", "MODEL_CODE", "QTY_PER_LOT" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_RA__080BC71934406957",
                table: "TR_PP_RANK_LOT",
                columns: new[] { "PLANT_CODE", "PROD_YEAR", "PROD_MONTH", "CFC_CODE", "RANK_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PP_RA__753A5F7A6CDB3E23",
                table: "TR_PP_RANK_UNIT",
                columns: new[] { "RANK_LOT_ID", "SEQ_NO" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_cal_work",
                table: "tr_pp_rp_cal_work",
                columns: new[] { "tr_pp_rp_proc_id", "cal_id", "cal_date" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_cal_work_shift",
                table: "tr_pp_rp_cal_work_shift",
                columns: new[] { "tr_pp_rp_cal_work_id", "cal_shift" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_ckd_list1",
                table: "tr_pp_rp_ckd_list",
                columns: new[] { "tr_pp_rp_proc_id", "tr_ckd_stock_lot_id" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_ckd_list2",
                table: "tr_pp_rp_ckd_list",
                columns: new[] { "tr_pp_rp_proc_id", "katashiki_ckd", "suffix_ckd", "prod_ord" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_ckd_model_diff",
                table: "tr_pp_rp_ckd_model_diff",
                columns: new[] { "tr_pp_rp_proc_id", "is_left", "katashiki_ckd", "suffix_ckd", "model_code", "qty_per_lot" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_ckd_variant",
                table: "tr_pp_rp_ckd_variant",
                columns: new[] { "tr_pp_rp_proc_id", "katashiki_ckd", "suffix_ckd" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_pp_rp_data01",
                table: "tr_pp_rp_data",
                columns: new[] { "tr_pp_rp_proc_id", "katashiki_ckd", "suffix_ckd" });

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_data",
                table: "tr_pp_rp_data",
                columns: new[] { "tr_pp_rp_proc_id", "katashiki", "suffix" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_data_detail",
                table: "tr_pp_rp_data_detail",
                columns: new[] { "tr_pp_rp_data_id", "model_code", "qty_per_lot" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_hjnk",
                table: "tr_pp_rp_hjnk",
                columns: new[] { "tr_pp_rp_proc_id", "katashiki", "suffix" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_hjnk_list",
                table: "tr_pp_rp_hjnk_list",
                columns: new[] { "tr_pp_rp_proc_id", "order_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_proc1",
                table: "tr_pp_rp_proc",
                columns: new[] { "proc_id", "plant_code", "prod_year", "prod_month", "cfc_code" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_proc2",
                table: "tr_pp_rp_proc",
                columns: new[] { "plant_code", "prod_year", "prod_month", "cfc_code", "version_no" },
                unique: true,
                filter: "[version_no] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_proc_detail",
                table: "tr_pp_rp_proc_detail",
                columns: new[] { "tr_pp_rp_proc_id", "order_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_rank_lot",
                table: "tr_pp_rp_rank_lot",
                columns: new[] { "tr_pp_rp_proc_id", "rank_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pp_rp_rank_unit",
                table: "tr_pp_rp_rank_unit",
                columns: new[] { "tr_pp_rp_rank_lot_id", "seq_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_pps_act_prod",
                table: "tr_pps_act_prod",
                columns: new[] { "plant_code", "line_code", "prod_date" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__tr_print__F9F4FD9B63EB0F38",
                table: "tr_print_doc",
                column: "resp_id",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "UQ__TR_PS_MP__8DBE8B1F92E9808B",
                table: "TR_PS_MPS",
                columns: new[] { "PLANT_CODE", "CFC_CODE", "PROD_YEAR", "RANK_NO", "PROD_DATE", "PROD_SHIFT", "KATASHIKI", "SUFFIX" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "ndx_tr_scan_part_tag",
                table: "tr_scan_part_tag",
                column: "scan_data");

            migrationBuilder.CreateIndex(
                name: "uq_tr_scan_rcv_dtl",
                table: "tr_scan_rcv_dtl",
                columns: new[] { "dn_no", "material_no", "seq_no" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "uq_tr_scan_rcv_hdr",
                table: "tr_scan_rcv_hdr",
                column: "dn_no",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "edn_supplier_dn");

            migrationBuilder.DropTable(
                name: "IMP_CKD_STOCK_LOT");

            migrationBuilder.DropTable(
                name: "IMP_HIST");

            migrationBuilder.DropTable(
                name: "IMP_MATERIAL");

            migrationBuilder.DropTable(
                name: "IMP_MATERIAL_SET");

            migrationBuilder.DropTable(
                name: "IMP_MATERIAL_VARIANT");

            migrationBuilder.DropTable(
                name: "IMP_MATERIAL_VENDOR");

            migrationBuilder.DropTable(
                name: "IMP_MATERIAL_VLDT_MSG");

            migrationBuilder.DropTable(
                name: "IMP_PART_BOM");

            migrationBuilder.DropTable(
                name: "IMP_PROD_PLAN");

            migrationBuilder.DropTable(
                name: "intf_mt_changesa_resp");

            migrationBuilder.DropTable(
                name: "intf_mt_getsadetail_resp");

            migrationBuilder.DropTable(
                name: "intf_mt_getsadetail_resp_header");

            migrationBuilder.DropTable(
                name: "intf_mt_getsadetail_resp_output_item");

            migrationBuilder.DropTable(
                name: "intf_mt_getsaheader_resp");

            migrationBuilder.DropTable(
                name: "intf_mt_getsaheader_resp_output_item");

            migrationBuilder.DropTable(
                name: "intf_mt_grsa_resp");

            migrationBuilder.DropTable(
                name: "intf_mt_grsa_resp_output_item");

            migrationBuilder.DropTable(
                name: "intfxml_resp");

            migrationBuilder.DropTable(
                name: "MS_CAL");

            migrationBuilder.DropTable(
                name: "MS_CAL_HOLIDAY");

            migrationBuilder.DropTable(
                name: "MS_CAL_STANDARD");

            migrationBuilder.DropTable(
                name: "MS_CAL_WORK");

            migrationBuilder.DropTable(
                name: "MS_CAL_WORK_SHIFT");

            migrationBuilder.DropTable(
                name: "MS_COUNTRY");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_CATEGORY");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_SET");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_VARIANT");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_VARIANT_DELETED");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_VENDOR");

            migrationBuilder.DropTable(
                name: "MS_MATERIAL_VENDOR_QUOTA");

            migrationBuilder.DropTable(
                name: "MS_POS_DELIVERY_TYPE");

            migrationBuilder.DropTable(
                name: "MS_POS_ORDER");

            migrationBuilder.DropTable(
                name: "MS_POS_ORDER_CYCLE");

            migrationBuilder.DropTable(
                name: "MS_POS_ORDER_FIXSC");

            migrationBuilder.DropTable(
                name: "MS_POS_ORDER_TYPE");

            migrationBuilder.DropTable(
                name: "MS_POS_ROUTE");

            migrationBuilder.DropTable(
                name: "MS_PRD_SHIFT");

            migrationBuilder.DropTable(
                name: "MS_PRINTER");

            migrationBuilder.DropTable(
                name: "MS_PS_PROCESS_FLOW");

            migrationBuilder.DropTable(
                name: "MS_PS_PROCESS_FLOW_DTL");

            migrationBuilder.DropTable(
                name: "MS_PS_PROCESS_FLOW_DTL_LINK");

            migrationBuilder.DropTable(
                name: "MS_PS_PROCESS_FLOW_DTL_VARIANT");

            migrationBuilder.DropTable(
                name: "MS_PS_VARIANT_PROCESS_FLOW");

            migrationBuilder.DropTable(
                name: "MS_PS_WORKCENTER");

            migrationBuilder.DropTable(
                name: "MS_REGION");

            migrationBuilder.DropTable(
                name: "MS_STP_PLANT");

            migrationBuilder.DropTable(
                name: "MS_STP_PLANT_CONV");

            migrationBuilder.DropTable(
                name: "MS_STP_SECTION");

            migrationBuilder.DropTable(
                name: "MS_STP_SHOP");

            migrationBuilder.DropTable(
                name: "MS_STP_WAREHOUSE");

            migrationBuilder.DropTable(
                name: "MS_STP_WAREHOUSE_DOCK");

            migrationBuilder.DropTable(
                name: "MS_STP_WAREHOUSE_PARK");

            migrationBuilder.DropTable(
                name: "MS_TRANSPORTER");

            migrationBuilder.DropTable(
                name: "MS_UOM");

            migrationBuilder.DropTable(
                name: "MS_USER_PRINTER");

            migrationBuilder.DropTable(
                name: "MS_VENDOR");

            migrationBuilder.DropTable(
                name: "MT_CFC");

            migrationBuilder.DropTable(
                name: "MT_EMAIL_SETTING");

            migrationBuilder.DropTable(
                name: "mt_prod_line");

            migrationBuilder.DropTable(
                name: "MT_VARIANT");

            migrationBuilder.DropTable(
                name: "MT_VARIANT_DELETED");

            migrationBuilder.DropTable(
                name: "MT_VARIANT_FINISH_UNIT");

            migrationBuilder.DropTable(
                name: "MT_VARIANT_FINISH_UNIT_DELETED");

            migrationBuilder.DropTable(
                name: "RB$DICT_FIELD");

            migrationBuilder.DropTable(
                name: "RB$DICT_JOIN");

            migrationBuilder.DropTable(
                name: "RB$DICT_TABLE");

            migrationBuilder.DropTable(
                name: "RB$FOLDER");

            migrationBuilder.DropTable(
                name: "RB$REPORT");

            migrationBuilder.DropTable(
                name: "SAP_BOM_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_BOM_HEADER");

            migrationBuilder.DropTable(
                name: "SAP_GR_SA");

            migrationBuilder.DropTable(
                name: "SAP_INTF");

            migrationBuilder.DropTable(
                name: "SAP_INTF_REQ");

            migrationBuilder.DropTable(
                name: "SAP_INTF_RESEND");

            migrationBuilder.DropTable(
                name: "SAP_INTF_RESP");

            migrationBuilder.DropTable(
                name: "SAP_REQ_GR_SA");

            migrationBuilder.DropTable(
                name: "SAP_RESP_BOM_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_RESP_BOM_HEADER");

            migrationBuilder.DropTable(
                name: "SAP_RESP_GR_SA");

            migrationBuilder.DropTable(
                name: "SAP_RESP_GR_SA_OUTPUT");

            migrationBuilder.DropTable(
                name: "SAP_RESP_MAT_DOC_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_RESP_MAT_DOC_HEADER");

            migrationBuilder.DropTable(
                name: "SAP_RESP_QUOTA");

            migrationBuilder.DropTable(
                name: "SAP_RESP_SA_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_RESP_SA_HEADER");

            migrationBuilder.DropTable(
                name: "SAP_RESP_SA_LIST");

            migrationBuilder.DropTable(
                name: "SAP_RESP_VENDOR");

            migrationBuilder.DropTable(
                name: "SAP_SA_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_SA_HEADER");

            migrationBuilder.DropTable(
                name: "SAP_SA_LIST");

            migrationBuilder.DropTable(
                name: "SAP_SA_LIST_DETAIL");

            migrationBuilder.DropTable(
                name: "SAP_VENDOR");

            migrationBuilder.DropTable(
                name: "sec_refresh_token");

            migrationBuilder.DropTable(
                name: "sec_role_claim");

            migrationBuilder.DropTable(
                name: "sec_token");

            migrationBuilder.DropTable(
                name: "sec_user_claim");

            migrationBuilder.DropTable(
                name: "sec_user_login");

            migrationBuilder.DropTable(
                name: "sec_user_role");

            migrationBuilder.DropTable(
                name: "sec_user_token");

            migrationBuilder.DropTable(
                name: "SET_PARAM");

            migrationBuilder.DropTable(
                name: "SET_PP_RANK_NO");

            migrationBuilder.DropTable(
                name: "SYS$AUTO_DOC_NO");

            migrationBuilder.DropTable(
                name: "SYS$DOC_GROUP");

            migrationBuilder.DropTable(
                name: "SYS$DOC_HEADER");

            migrationBuilder.DropTable(
                name: "SYS$DOC_NO");

            migrationBuilder.DropTable(
                name: "SYS$DOC_NO_LIST");

            migrationBuilder.DropTable(
                name: "SYS$DOC_TYPE");

            migrationBuilder.DropTable(
                name: "SYS$IMP_TXT");

            migrationBuilder.DropTable(
                name: "SYS$SESSION_ID");

            migrationBuilder.DropTable(
                name: "TL_INTF");

            migrationBuilder.DropTable(
                name: "TL_INTF_DTL");

            migrationBuilder.DropTable(
                name: "tl_intf_rec");

            migrationBuilder.DropTable(
                name: "tl_intf_rec_err");

            migrationBuilder.DropTable(
                name: "TMP_OKB");

            migrationBuilder.DropTable(
                name: "tmp_ord_item");

            migrationBuilder.DropTable(
                name: "TR_CKD_STOCK_LOT");

            migrationBuilder.DropTable(
                name: "TR_LOG");

            migrationBuilder.DropTable(
                name: "TR_LOG_PRINTER");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_mat");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_ord");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_ord_day");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_ord_dn");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_ord_mat");

            migrationBuilder.DropTable(
                name: "tr_pos_ckd_quota");

            migrationBuilder.DropTable(
                name: "tr_pos_create_dn");

            migrationBuilder.DropTable(
                name: "tr_pos_create_dn_sche");

            migrationBuilder.DropTable(
                name: "TR_POS_DN");

            migrationBuilder.DropTable(
                name: "TR_POS_DN_DTL");

            migrationBuilder.DropTable(
                name: "TR_POS_DN_DTL_SAP");

            migrationBuilder.DropTable(
                name: "TR_POS_DN_RANK");

            migrationBuilder.DropTable(
                name: "TR_POS_DN_RANK_DTL");

            migrationBuilder.DropTable(
                name: "tr_pos_ds_session");

            migrationBuilder.DropTable(
                name: "TR_POS_GR");

            migrationBuilder.DropTable(
                name: "TR_POS_GR_DTL");

            migrationBuilder.DropTable(
                name: "TR_POS_GR_DTL_SAP");

            migrationBuilder.DropTable(
                name: "TR_POS_LPD");

            migrationBuilder.DropTable(
                name: "TR_POS_LPD_DTL");

            migrationBuilder.DropTable(
                name: "TR_POS_LPD_MAIL");

            migrationBuilder.DropTable(
                name: "tr_pos_lpd_rpt_dtl");

            migrationBuilder.DropTable(
                name: "tr_pos_lpd_rpt_sum");

            migrationBuilder.DropTable(
                name: "TR_POS_MPS_DLV");

            migrationBuilder.DropTable(
                name: "TR_POS_MPS_DLV_DTL");

            migrationBuilder.DropTable(
                name: "tr_pos_mrp");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_ORDER");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_ORDER_DN");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_ORDER_ITEM");

            migrationBuilder.DropTable(
                name: "tr_pos_mrp_order_item_add");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_ORDER_SAP_PO");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK_SET");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK_UNIT");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK_VND_DN");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK_VND_PO");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_data");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_data_mat");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_data_quota_mat");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_data_quota_mat_ckd");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_data_rank");

            migrationBuilder.DropTable(
                name: "tr_pos_ord_dlv");

            migrationBuilder.DropTable(
                name: "TR_POS_ORDER_SCHE");

            migrationBuilder.DropTable(
                name: "TR_POS_PICK");

            migrationBuilder.DropTable(
                name: "TR_POS_PICK_DTL");

            migrationBuilder.DropTable(
                name: "tr_pos_prod_sche");

            migrationBuilder.DropTable(
                name: "tr_pos_prod_sche_del");

            migrationBuilder.DropTable(
                name: "TR_POS_RCV");

            migrationBuilder.DropTable(
                name: "TR_POS_RCV_DTL");

            migrationBuilder.DropTable(
                name: "TR_POS_SAP_PO");

            migrationBuilder.DropTable(
                name: "TR_POS_SAP_PO_DTL");

            migrationBuilder.DropTable(
                name: "TR_POS_SAP_PO_HIST");

            migrationBuilder.DropTable(
                name: "tr_pos_scan_data");

            migrationBuilder.DropTable(
                name: "tr_pos_scan_dn");

            migrationBuilder.DropTable(
                name: "tr_pos_scan_dn_part");

            migrationBuilder.DropTable(
                name: "TR_POS_SJ_MAIL");

            migrationBuilder.DropTable(
                name: "TR_PP_DAILY");

            migrationBuilder.DropTable(
                name: "TR_PP_DAILY_DETAIL");

            migrationBuilder.DropTable(
                name: "TR_PP_DAILY_DTL_DATA");

            migrationBuilder.DropTable(
                name: "TR_PP_DATA");

            migrationBuilder.DropTable(
                name: "TR_PP_DATA_DETAIL");

            migrationBuilder.DropTable(
                name: "TR_PP_HJNK");

            migrationBuilder.DropTable(
                name: "TR_PP_HJNK_CALC");

            migrationBuilder.DropTable(
                name: "TR_PP_HJNK_LIST");

            migrationBuilder.DropTable(
                name: "TR_PP_RANK_LOT");

            migrationBuilder.DropTable(
                name: "TR_PP_RANK_UNIT");

            migrationBuilder.DropTable(
                name: "TR_PP_REL_RANK");

            migrationBuilder.DropTable(
                name: "TR_PP_REL_RANK_LOT");

            migrationBuilder.DropTable(
                name: "TR_PP_REL_RANK_UNIT");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_cal_work");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_cal_work_shift");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_ckd_list");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_ckd_model_diff");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_ckd_variant");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_data");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_data_detail");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_hjnk");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_hjnk_list");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_proc");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_proc_detail");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_rank_lot");

            migrationBuilder.DropTable(
                name: "tr_pp_rp_rank_unit");

            migrationBuilder.DropTable(
                name: "tr_pps_act_prod");

            migrationBuilder.DropTable(
                name: "tr_print_doc");

            migrationBuilder.DropTable(
                name: "TR_PS_MPS");

            migrationBuilder.DropTable(
                name: "tr_scan_part_tag");

            migrationBuilder.DropTable(
                name: "tr_scan_rcv_dtl");

            migrationBuilder.DropTable(
                name: "tr_scan_rcv_hdr");

            migrationBuilder.DropTable(
                name: "sec_role");

            migrationBuilder.DropTable(
                name: "sec_user");

            migrationBuilder.DropTable(
                name: "TR_POS_RANK_UNIT");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK_VND");

            migrationBuilder.DropTable(
                name: "TR_POS_MRP_RANK");

            migrationBuilder.DropTable(
                name: "TR_POS_RANK");
        }
    }
}
