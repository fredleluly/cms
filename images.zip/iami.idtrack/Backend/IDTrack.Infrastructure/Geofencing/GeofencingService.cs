using IDTrack.Application.Geofencing;
using IDTrack.Domain.Models;
using System.Globalization;

namespace IDTrack.Infrastructure.Geofencing;

public class GeofencingService : IGeofencingService
{
    public Task<Result<double>> CalculateDistanceBetweenTwoPointsAsync(string latStr1, string lonStr1, string latStr2, string lonStr2)
    {
        if (!(double.TryParse(latStr1, NumberStyles.Float, CultureInfo.InvariantCulture, out double lat1) &&
             double.TryParse(lonStr1, NumberStyles.Float, CultureInfo.InvariantCulture, out double lon1) &&
             double.TryParse(latStr2, NumberStyles.Float, CultureInfo.InvariantCulture, out double lat2) &&
             double.TryParse(lonStr2, NumberStyles.Float, CultureInfo.InvariantCulture, out double lon2)))
            return Task.FromResult(Result.Failure<double>(GeofenceDomainError.InvalidCoordinates));

        var R = 6371e3; // Radius of the earth in meters
        var lat1Rad = ToRadians(lat1);
        var lat2Rad = ToRadians(lat2);
        var deltaLat = ToRadians(lat2 - lat1);
        var deltaLon = ToRadians(lon2 - lon1);

        var a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                Math.Cos(lat1Rad) * Math.Cos(lat2Rad) *
                Math.Sin(deltaLon / 2) * Math.Sin(deltaLon / 2);
        var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

        return Task.FromResult(Result.Success(R * c)); // Distance in meters
    }

    private double ToRadians(double angle)
    {
        return Math.PI * angle / 180.0;
    }
}
