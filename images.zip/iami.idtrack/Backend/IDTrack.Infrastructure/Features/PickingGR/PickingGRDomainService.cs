using IDTrack.Application.Features.PickingGR;
using IDTrack.Infrastructure.Document;
using MigraDoc.DocumentObjectModel;
using System.Globalization;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.PixelFormats;
using ZXing;
using ZXing.Common;
using IDTrack.Domain.Features.PickingGR;
using IDTrack.Infrastructure.Migrations;

namespace IDTrack.Infrastructure.Features.PickingGR;

public class PickingGRDomainService : IPickingGRDomainService
{

    private List<string> _filesToClean = new List<string>();
    public async Task<byte[]> DownloadLPBAsync(GoodReceive goodReceive)
    {
        return await Task.Run(() =>
        {
            var document = new MigraDoc.DocumentObjectModel.Document();

            // Set default font to Courier
            var style = document.Styles["Normal"] ?? document.Styles.AddStyle("Normal", "Normal");
            style.Font.Name = "Courier";
            style.Font.Size = 8;

            var section = document.AddSection();

            string binDirectory = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)!;
            var imagePath = Path.Combine(binDirectory, DocumentConstants.TemplateFolder, DocumentConstants.IsuzuLogo);

            var header = section.AddTable();
            header.AddColumn(Unit.FromCentimeter(12));
            header.AddColumn(Unit.FromCentimeter(5));

            var headRow = header.AddRow();

            var barcodeContent = goodReceive.GRNo;
            headRow.Cells[0].AddImage(imagePath);
            AddBarcode(headRow.Cells[1], barcodeContent, BarcodeFormat.CODE_128, 1.5, 4.5);
            var text = headRow.Cells[1].AddParagraph(barcodeContent);
            text.Format.Alignment = ParagraphAlignment.Center;

            section.AddParagraph("");

            // Add Title
            var title = section.AddParagraph("LAPORAN PENERIMAAN BARANG");
            title.Format.Font.Size = 12;
            title.Format.Font.Name = "Courier";
            title.Format.Alignment = ParagraphAlignment.Center;
            title.Format.Font.Bold = true;

            section.AddParagraph("");

            // Master Detail Table
            var masterDetail = section.AddTable();
            masterDetail.AddColumn(Unit.FromCentimeter(4));
            masterDetail.AddColumn(Unit.FromCentimeter(4));
            masterDetail.AddColumn(Unit.FromCentimeter(6));
            masterDetail.AddColumn(Unit.FromCentimeter(5));

            var row = masterDetail.AddRow();
            row.Cells[0].AddParagraph("Nomor LPB").Format.Font.Name = "Courier";
            row.Cells[0].AddParagraph("Tanggal LPB").Format.Font.Name = "Courier";
            row.Cells[0].AddParagraph("Plant Penerima").Format.Font.Name = "Courier";
            row.Cells[0].AddParagraph("Nomor SP/Invoice").Format.Font.Name = "Courier";

            row.Cells[1].AddParagraph(" : " + goodReceive.GRNo).Format.Font.Name = "Courier";

            var grDateFormatted = goodReceive.GRDate?.ToString("dd-MM-yyyy") ?? string.Empty;
            row.Cells[1].AddParagraph(" : " + grDateFormatted).Format.Font.Name = "Courier";
            row.Cells[1].AddParagraph(" : " + goodReceive.PlantCode).Format.Font.Name = "Courier";
            row.Cells[1].AddParagraph(" : Operator").Format.Font.Name = "Courier";

            row.Cells[2].AddParagraph("Nomor Vendor / Plant Pengiriman").Format.Font.Name = "Courier";
            row.Cells[2].AddParagraph("Nama Vendor / Nama Plant").Format.Font.Name = "Courier";
            row.Cells[2].AddParagraph("Nomor PO / STO").Format.Font.Name = "Courier";
            row.Cells[2].AddParagraph("Tanggal PO / STO").Format.Font.Name = "Courier";

            row.Cells[3].AddParagraph(" : " + goodReceive.VendorCode).Format.Font.Name = "Courier";
            row.Cells[3].AddParagraph(" : " + goodReceive.VendorSite).Format.Font.Name = "Courier";
            row.Cells[3].AddParagraph(" : " + goodReceive.PONo).Format.Font.Name = "Courier";

            var postDateFormatted = goodReceive.PostDate?.ToString("dd-MM-yyyy") ?? string.Empty;
            row.Cells[3].AddParagraph(" : " + postDateFormatted).Format.Font.Name = "Courier";

            section.AddParagraph("");

            // Item Table
            var table = section.AddTable();
            table.AddColumn(Unit.FromCentimeter(1)); // No
            table.AddColumn(Unit.FromCentimeter(3)); // Material
            table.AddColumn(Unit.FromCentimeter(6)); // Description
            table.AddColumn(Unit.FromCentimeter(1)); // Qty
            table.AddColumn(Unit.FromCentimeter(1)); // Unit
            table.AddColumn(Unit.FromCentimeter(2)); // Contents
            table.AddColumn(Unit.FromCentimeter(1)); // Text
            table.AddColumn(Unit.FromCentimeter(2)); // Confi

            var headerRow = table.AddRow();
            headerRow.Borders.Bottom.Width = 0.1;
            headerRow.Borders.Top.Width = 0.1;

            // Define headers
            headerRow.Cells[0].AddParagraph("No").Format.Font.Name = "Courier";
            headerRow.Cells[0].Format.SpaceBefore = 3;
            headerRow.Cells[0].Format.SpaceAfter = 3;

            headerRow.Cells[1].AddParagraph("Material").Format.Font.Name = "Courier";
            headerRow.Cells[1].Format.SpaceBefore = 3;
            headerRow.Cells[1].Format.SpaceAfter = 3;

            headerRow.Cells[2].AddParagraph("Description").Format.Font.Name = "Courier";
            headerRow.Cells[2].Format.SpaceBefore = 3;
            headerRow.Cells[2].Format.SpaceAfter = 3;

            headerRow.Cells[3].AddParagraph("Qty").Format.Font.Name = "Courier";
            headerRow.Cells[3].Format.SpaceBefore = 3;
            headerRow.Cells[3].Format.SpaceAfter = 3;

            headerRow.Cells[4].AddParagraph("Unit").Format.Font.Name = "Courier";
            headerRow.Cells[4].Format.SpaceBefore = 3;
            headerRow.Cells[4].Format.SpaceAfter = 3;

            headerRow.Cells[5].AddParagraph("Contents").Format.Font.Name = "Courier";
            headerRow.Cells[5].Format.SpaceBefore = 3;
            headerRow.Cells[5].Format.SpaceAfter = 3;

            headerRow.Cells[6].AddParagraph("Text").Format.Font.Name = "Courier";
            headerRow.Cells[6].Format.SpaceBefore = 3;
            headerRow.Cells[6].Format.SpaceAfter = 3;

            headerRow.Cells[7].AddParagraph("Confi").Format.Font.Name = "Courier";
            headerRow.Cells[7].Format.SpaceBefore = 3;
            headerRow.Cells[7].Format.SpaceAfter = 3;

            int itemNoCounter = 1; 
            int totalDetails = goodReceive.Details.Count;
            int currentIndex = 0;

            foreach (var detail in goodReceive.Details)
            {
                string no = itemNoCounter.ToString();
                string material = string.IsNullOrEmpty(detail.MaterialNo) ? "" : detail.MaterialNo;
                string description = string.IsNullOrEmpty(detail.Description) ? "" : detail.Description;
                string qty = detail.Qty.ToString();
                string unit = string.IsNullOrEmpty(detail.Unit) ? "" : detail.Unit;
                string contents = "";
                string Text = "";
                string confi = "";

                var lastRow = AddTableRow(table, no, material, description, qty, unit, contents, Text, confi);

                currentIndex++;
                if (currentIndex == totalDetails)
                {
                    lastRow.Borders.Bottom.Width = 0.1;
                    lastRow.Format.SpaceAfter = 30;
                }

                itemNoCounter++;
            }

            if ( totalDetails == 0){
                var lastRow = AddTableRow(table, "", "", "", "", "", "", "", "");
                lastRow.Borders.Bottom.Width = 0.1;
                lastRow.Format.SpaceAfter = 30;
            }

            section.AddParagraph("");

            // Footer
            var footerTable = section.AddTable();
            footerTable.AddColumn(Unit.FromCentimeter(8));
            footerTable.AddColumn(Unit.FromCentimeter(8));

            var footerRow = footerTable.AddRow();
            var leftCell = footerRow.Cells[0];
            leftCell.AddParagraph("");
            leftCell.AddParagraph("1. Supplier").Format.Font.Name = "Courier";
            leftCell.AddParagraph("2. Supplier").Format.Font.Name = "Courier";
            leftCell.AddParagraph("3. PPC/GA/promosi/finance/logistik").Format.Font.Name = "Courier";
            leftCell.AddParagraph("4. Accounting").Format.Font.Name = "Courier";
            leftCell.AddParagraph("5. Gudang").Format.Font.Name = "Courier";

            var rightCell = footerRow.Cells[1];
            rightCell.Format.Alignment = ParagraphAlignment.Right;
            rightCell.AddParagraph("");
            rightCell.AddParagraph("Penerima").Format.Font.Name = "Courier";
            rightCell.AddParagraph("");
            rightCell.AddParagraph("");
            rightCell.AddParagraph("");
            rightCell.AddParagraph("(.............)").Format.Font.Name = "Courier";
            rightCell.AddParagraph("Lembar :      1").Format.Font.Name = "Courier";

            // Render PDF
            var pdfRenderer = new PdfDocumentRenderer { Document = document };
            pdfRenderer.RenderDocument();

            using var stream = new MemoryStream();
            pdfRenderer.PdfDocument.Save(stream);

            CleanFiles();
            return stream.ToArray();
        });
    }
    private Row AddTableRow(Table table, string no, string material, string description, string qty, string unit, string contents, string text, string confi)
    {
        var row = table.AddRow();
        row.Cells[0].AddParagraph(no).Format.Font.Name = "Courier";
        row.Cells[1].AddParagraph(material).Format.Font.Name = "Courier";
        row.Cells[2].AddParagraph(description).Format.Font.Name = "Courier";
        row.Cells[3].AddParagraph(qty).Format.Font.Name = "Courier";
        row.Cells[4].AddParagraph(unit).Format.Font.Name = "Courier";
        row.Cells[5].AddParagraph(contents).Format.Font.Name = "Courier";
        row.Cells[6].AddParagraph(text).Format.Font.Name = "Courier";
        row.Cells[7].AddParagraph(confi).Format.Font.Name = "Courier";

        return row;
    }

    private void AddBarcode(Cell section, string qrCodeText, BarcodeFormat format, double height = 2, double width = 6)
    {
        var barcodeWriter = new ZXing.ImageSharp.BarcodeWriter<Rgba32>
        {
            Format = format,
            Options = new EncodingOptions
            {
                Height = (int)(height * 100),
                Width = (int)(width * 100),
                Margin = 0
            }
        };

        var tempBarcodeFileName = Path.Combine(Path.GetTempPath(), "barcode" + new Guid().ToString() + ".png");
        using (Image<Rgba32> barcodeBitmap = barcodeWriter.Write(qrCodeText))
        {
            barcodeBitmap.Save(tempBarcodeFileName, new PngEncoder());

            var image = section.AddImage(tempBarcodeFileName);
            image.Width = Unit.FromCentimeter(width);
            image.Height = Unit.FromCentimeter(height);
            image.LockAspectRatio = true;
        }

        _filesToClean.Add(tempBarcodeFileName);
    }

    private void CleanFiles()
    {
        foreach (var file in _filesToClean)
        {
            try
            {
                File.Delete(file);
            }
            catch
            { }
        }
    }
}
