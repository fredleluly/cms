using IDTrack.Domain.Features.PickingGR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.PickingPO
{
    public partial class PickingGREntityConfiguration : IEntityTypeConfiguration<GoodReceive>
    {
        public void Configure(EntityTypeBuilder<GoodReceive> entity)
        {
            entity.HasKey(e => e.Id).HasName("PK_TR_TRACK_PICK_GR");

            entity.ToTable("TR_TRACK_PICK_GR");

            entity.Property(e => e.GRNo)
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("GR_NO")
                .IsRequired();

            entity.Property(e => e.GRDate)
                .HasColumnName("GR_DATE")
                .IsRequired(false);

            entity.Property(e => e.PONo)
                .HasColumnName("SAP_PO_NO")
                .HasMaxLength(30)
                .IsRequired(false);
            
            entity.Property(e => e.PostDate)
                .HasColumnName("POST_DATE")
                .IsRequired(false);

            entity.Property(e => e.DNNo)
                .HasColumnName("DN_NO")
                .HasMaxLength(30)
                .IsRequired(false);

            entity.Property(e => e.RefNo)
                .HasColumnName("REF_NO")
                .HasMaxLength(30)
                .IsRequired(false);

            entity.Property(e => e.PlantCode)
                .HasColumnName("PLANT_CODE")
                .HasMaxLength(10)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.WarehouseCode)
                .HasColumnName("WAREHOUSE_CODE")
                .HasMaxLength(10)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.VendorCode)
                .HasColumnName("VENDOR_CODE")
                .HasMaxLength(10)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.VendorSite)
                .HasColumnName("VENDOR_SITE")
                .HasMaxLength(10)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.SapMatDoc)
                .HasColumnName("SAP_MAT_DOC")
                .HasMaxLength(30)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.SapMatDocYear)
                .HasColumnName("SAP_MAT_DOC_YEAR")
                .HasMaxLength(4)
                .IsRequired(false)
                .IsUnicode(false);

            entity.Property(e => e.Status)
                .HasColumnName("STATUS");

            entity.Property(e => e.CreateTime)
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("CREATE_TIME");

            entity.Property(e => e.CreateBy)
                .HasColumnName("CREATE_BY");

            entity.Property(e => e.UpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_TIME");

            entity.Property(e => e.UpdateBy)
                .HasColumnName("UPDATE_BY");

            entity.Ignore(e => e.CreateByStr);
            entity.Ignore(e => e.UpdateByStr);

            entity.OwnsMany(e => e.Details, db => {
                db.ToTable("TR_TRACK_PICK_GR_DTL");

                db
                    .WithOwner()
                    .HasForeignKey("TRACK_PICK_GR_ID");

                db.Ignore(e => e.CreateByStr);
                db.Ignore(e => e.UpdateByStr);

                db.Property(e => e.GRNo)
                    .HasColumnName("GR_NO")
                    .HasMaxLength(30)
                    .IsRequired()
                    .IsUnicode(false);

                db.Property(e => e.ItemNo)
                    .HasColumnName("ITEM_NO")
                    .IsRequired();

                db.Property(e => e.MaterialNo)
                    .HasColumnName("MATERIAL_NO")
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .IsRequired();

                db.Property(e => e.Description)
                    .HasColumnName("GR_DTL_DESC100")
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .IsRequired(false);

                db.Property(e => e.Qty)
                    .HasColumnName("QTY")
                    .IsRequired(true);

                db.Property(e => e.Unit)
                    .HasColumnName("UNIT")
                    .HasMaxLength(10)
                    .IsRequired(false);

                db.Property(e => e.Status)
                    .HasColumnName("STATUS");

                db.Property(e => e.CreateTime)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())")
                    .HasColumnName("CREATE_TIME");

                db.Property(e => e.CreateBy)
                    .HasColumnName("CREATE_BY");

                db.Property(e => e.UpdateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("UPDATE_TIME");

                db.Property(e => e.UpdateBy)
                    .HasColumnName("UPDATE_BY");
            });
        }
    }
}
