using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.PickingGR;
using IDTrack.Application.Features.PickingGR.UseCase;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Features.PickingGR;
using IDTrack.Domain.Features.PickingGR.Entities;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.PickingGR;

public class PickingGRRepository : IPickingGRRepository
{
    private readonly AppDbContext _dbContext;
    private readonly IUnitOfWork _uow;

    public PickingGRRepository(AppDbContext context, IUnitOfWork uow)
    {
        _dbContext = context;
        _uow = uow;
    }

    public async Task<Result<GoodReceive>> AddAsync(GoodReceive goodReceive, CancellationToken ct)
    {
        await _dbContext.GoodReceives.AddAsync(goodReceive, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<GoodReceive>(result.Error);

        return Result.Success(goodReceive);
    }

    public async Task<Result<GoodReceive>> DeleteAsync(long id, CancellationToken ct)
    {
        var goodReceive = await _dbContext.GoodReceives.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (goodReceive is null)
            return Result.Failure<GoodReceive>(GoodReceiveDomainError.PickingGRNotFound(id.ToString()));

        _dbContext.GoodReceives.Remove(goodReceive);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<GoodReceive>(result.Error);

        return Result.Success(goodReceive);
    }

    public Task<Result<GetPickingGRDetailUseCaseResult>> GetByIdAsync(long id, CancellationToken ct)
    {
        throw new NotImplementedException();
    }

    public async Task<Result<GoodReceive>> GetGoodReceiveByGRNoAsync(string grNo, CancellationToken ct)
    {
        var goodReceive = await _dbContext.GoodReceives
        .Where(gr => gr.GRNo == grNo)
        .Include(gr => gr.Details)
        .FirstOrDefaultAsync(ct);

        if (goodReceive is null)
            return Result.Failure<GoodReceive>(GoodReceiveDomainError.PickingGRNotFound(grNo));

        return Result.Success(goodReceive);
    }

    public Task<PagingResult<GoodReceive>> LoadPageAsync(IQueryable<GoodReceive> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _dbContext, ct);
    }

    public IQueryable<GoodReceive> Query()
    {
        return _dbContext.GoodReceives;
    }

    public async Task<Result<GoodReceive>> UpdateAsync(GoodReceive goodReceive, CancellationToken ct)
    {
        _dbContext.Update(goodReceive);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<GoodReceive>(result.Error);

        return Result.Success(goodReceive);
    }
}