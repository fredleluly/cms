using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.ComponentTracking.Direct;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Direct;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.ComponentTracking.Direct;

public class DirectDeliveryRepository : IDirectDeliveryRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public DirectDeliveryRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result> CreateDirectDeliveryAsync(DirectDelivery directDelivery, CancellationToken ct)
    {
        await _context.DirectDeliveries.AddAsync(directDelivery, ct);

        return await _uow.SaveChangesAsync(ct);
    }

    public async Task<Result> DeleteDirectDeliveryAsync(long id, CancellationToken ct)
    {
        var found = await _context.DirectDeliveries.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (found is null)
            return DirectDeliveryDomainError.DeliveryNotFound;

        _context.DirectDeliveries.Remove(found);

        return await _uow.SaveChangesAsync(ct);
    }

    public async Task<Result<DirectDelivery>> GetActiveDirectDeliveryByCreatorAsync(long userId, CancellationToken ct)
    {
        var result = await _context.DirectDeliveries
            .FirstOrDefaultAsync(e => e.CreateBy == userId &&
                e.Status == DirectDelivery.DirectDeliveryStatus.OnTheWay,
                ct);

        if (result is null)
            return Result.Failure<DirectDelivery>(DirectDeliveryDomainError.UserDoesNotHaveDeliverySession);

        return Result.Success(result);
    }

    public async Task<Result<DirectDelivery>> GetDirectDeliveryByIdAsync(long id, CancellationToken ct)
    {
        var directDelivery = await _context.DirectDeliveries.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (directDelivery is null)
            return Result.Failure<DirectDelivery>(DirectDeliveryDomainError.DeliveryNotFound);

        return Result.Success(directDelivery);
    }

    public Task<PagingResult<DirectDelivery>> LoadPageAsync(IQueryable<DirectDelivery> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<DirectDelivery> Query()
    {
        return _context.DirectDeliveries;
    }

    public async Task<Result> UpdateDirectDeliveryAsync(DirectDelivery directDelivery, CancellationToken ct)
    {
        _context.Update(directDelivery);

        return await _uow.SaveChangesAsync(ct);
    }
}

