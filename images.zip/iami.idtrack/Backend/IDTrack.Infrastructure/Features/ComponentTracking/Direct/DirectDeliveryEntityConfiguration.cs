using IDTrack.Domain.Features.Direct;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Application.Features.ComponentTracking.Direct;

public class DirectDeliveryEntityConfiguration : IEntityTypeConfiguration<DirectDelivery>
{
    public void Configure(EntityTypeBuilder<DirectDelivery> builder)
    {
        builder.ToTable("TR_TRACK_DIRECT_DLV");

        builder.HasKey(e => e.Id);

        builder.Ignore(e => e.CreateByStr);
        builder.Ignore(e => e.UpdateByStr);

        builder.Property(e => e.Id)
            .HasColumnName("ID")
            .ValueGeneratedOnAdd()
            .HasColumnType("BIGINT");

        builder.Property(e => e.DeliveryDate)
            .HasColumnName("DLV_DATE")
            .HasColumnType("DATETIME");

        builder.Property(e => e.SupplierCode)
            .HasMaxLength(10)
            .HasColumnName("VENDOR_CODE")
            .IsRequired();

        builder.Property(e => e.StartByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("START_BY_DEVICE_ID");

        builder.Property(e => e.CancelByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("CANCEL_BY_DEVICE_ID");

        builder.Property(e => e.GateInByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("GATE_IN_BY_DEVICE_ID");

        builder.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");
        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
        builder.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");
        builder.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
        builder.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_TIME");

        builder.OwnsMany(e => e.DirectOKBs, eb =>
        {
            eb.ToTable("TR_TRACK_DIRECT_DLV_OKB");

            eb.HasKey(e => e.Id);

            eb.Ignore(e => e.CreateByStr);
            eb.Ignore(e => e.UpdateByStr);

            eb.WithOwner().HasForeignKey("DIRECT_DLV_ID");

            eb.Property(e => e.Id)
                .HasColumnName("ID")
                .ValueGeneratedOnAdd()
                .HasColumnType("BIGINT");

            eb.Property(e => e.OkbNo)
                .IsRequired()
                .HasMaxLength(30);

            eb.Property(e => e.Status)
                .HasDefaultValue(0)
                .HasColumnName("STATUS");
            eb.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
            eb.Property(e => e.CreateTime)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_TIME");
            eb.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
            eb.Property(e => e.UpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_TIME");
        });
    }
}

