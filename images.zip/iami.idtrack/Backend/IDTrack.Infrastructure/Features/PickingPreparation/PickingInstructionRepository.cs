using System.Text.RegularExpressions;
using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.ComponentTracking.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Features.PickingGR;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class PickingInstructionRepository : IPickingInstructionRepository
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly AppDbContext _dbContext;
    private readonly IAppConfigurationService _appConfigurationService;

    public PickingInstructionRepository(IUnitOfWork unitOfWork, AppDbContext dbContext, IAppConfigurationService appConfigurationService)
    {
        _unitOfWork = unitOfWork;
        _dbContext = dbContext;
        _appConfigurationService = appConfigurationService;
    }

    public async Task<Result<PickingInstruction>> CreatePickingInstructionAsync(PickingInstruction pickingInstruction, CancellationToken cancellationToken)
    {
        await _dbContext.PickingInstructions.AddAsync(pickingInstruction);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickingInstruction>(result.Error);
        }

        return Result.Success(pickingInstruction);
    }

    public async Task<Result<PickingInstruction>> DeletePickingInstructionAsync(long id, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        var entity = await _dbContext.CutoffedPickingInstructions(okbCutoff).FirstOrDefaultAsync(e => e.Id == id, cancellationToken);

        if (entity is null)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.PickingInstructionNotFound);
        }

        _dbContext.PickingInstructions.Remove(entity);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.FailedToDeletePickingInstruction);
        }

        return Result.Success(entity);
    }

    public async Task<string> GeneratePickNoAsync(CancellationToken cancellationToken)
    {
        string year = DateTime.Now.Year.ToString().Substring(2);
        string? lastPickNo = (await _dbContext
            .PickingInstructions
            .Where(e => e.PickNo.StartsWith("PI" + year))
            .OrderByDescending(x => x.Id)
            .FirstOrDefaultAsync(cancellationToken))?.PickNo;

        string prefix = "";

        if (lastPickNo is not null)
        {
            int lastSeq = int.Parse(lastPickNo.Substring(4));
            prefix += (lastSeq + 1).ToString();
        }
        else
        {
            prefix += "1";
        }

        return $"PI{year}{prefix.PadLeft(6, '0')}";
    }

    public async Task<Result<PickingInstruction>> GetDomainByPickNoAsync(string pickNo, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        var result = await _dbContext.CutoffedPickingInstructions(okbCutoff).FirstOrDefaultAsync(pi => pi.PickNo == pickNo, cancellationToken);

        if (result is null)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.PickingInstructionNotFound);
        }

        return Result.Success(result);
    }

    public async Task<Result<PickingInstruction>> GetPickingInstructionByIdAsync(long id, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        var result = await _dbContext.CutoffedPickingInstructions(okbCutoff).FirstOrDefaultAsync(e => e.Id == id, cancellationToken);

        if (result is null)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.PickingInstructionNotFound);
        }

        return Result.Success(result);
    }

    public async Task<Result<GetPickingInstructionDetailUseCaseResult>> GetPickingInstructionByPickNoAsync(string pickNo, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        var result = await _dbContext
            .CutoffedPickingInstructions(okbCutoff)
            .Join(_dbContext.PickingRoutes, pi => pi.RouteCode, pr => pr.RouteCode, (pi, pr) => new
            {
                PickingInstruction = pi,
                PickingRoute = pr
            })
            .Join(_dbContext.GoodReceives, pir => pir.PickingInstruction.SapPoNo, gr => gr.PONo, (pir, gr) => new
            {
                pir.PickingInstruction,
                pir.PickingRoute,
                GoodReceive = gr
            })
            .Join(_dbContext.PickingTransporters, pi => pi.PickingInstruction.TransporterCode, pt => pt.TransporterCode, (pi, pt) => new
            {
                PickingTransporter = pt,
                pi.PickingInstruction,
                pi.PickingRoute,
                pi.GoodReceive
            })
            .Where(e => e.PickingInstruction.PickNo == pickNo)
            .Select(e => new GetPickingInstructionDetailUseCaseResult(
                e.PickingInstruction.Id,
                e.PickingInstruction.PickNo,
                e.PickingRoute.RouteName,
                e.PickingTransporter.TransporterName,
                e.PickingInstruction.TransporterCode,
                e.PickingInstruction.CycleNo,
                e.PickingInstruction.PickDate,
                e.PickingInstruction.ArrivalDate,
                e.PickingInstruction.ArrivalTime,
                e.PickingInstruction.PickStatus ?? 0,
                e.GoodReceive.GRNo,
                new List<PickupPointDto>()
            ))
            .FirstOrDefaultAsync();

        if (result == null)
            return Result.Failure<GetPickingInstructionDetailUseCaseResult>(PickingDomainError.PickingInstructionNotFound);

        return Result.Success(result);
    }

    public Task<PagingResult<PickingInstruction>> LoadPageAsync(IQueryable<PickingInstruction> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _dbContext, ct);
    }

    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> qry, PagingQuery page, CancellationToken ct) where T : class
    {
        return PagingService.LoadQueryAsync<T>(qry, page, _dbContext, ct);
    }

    public async Task<bool> PickingExistsAsync(string? transporterCode, string? routeCode, CancellationToken ct)
    {
        var predicate = PredicateBuilder.True<PickingInstruction>();

        if (!string.IsNullOrEmpty(transporterCode))
        {
            predicate = predicate.And(e => e.TransporterCode == transporterCode);
        }

        if (!string.IsNullOrEmpty(routeCode))
        {
            predicate = predicate.And(e => e.RouteCode == routeCode);
        }

        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        return await _dbContext.CutoffedPickingInstructions(okbCutoff).AnyAsync(predicate, ct);
    }

    public async Task<bool> PickingExistsAsync(long transporterId, long routeId, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        return await _dbContext
            .CutoffedPickingInstructions(okbCutoff)
            .Join(_dbContext.PickingRoutes, pi => pi.RouteCode, pr => pr.RouteCode, (pi, pr) => new
            {
                TransporterCode = pi.TransporterCode,
                RouteId = pr.Id
            })
            .Join(_dbContext.PickingTransporters, pi => pi.TransporterCode, pt => pt.TransporterCode, (pi, pt) => new
            {
                TransporterId = pt.Id,
                pi.RouteId
            })
            .Where(e => e.TransporterId == transporterId && e.RouteId == routeId)
            .AnyAsync();
    }

    public IQueryable<PickingInstruction> Query()
    {
        var okbCutoff = _appConfigurationService.GetOkbCutoffDateAsync(CancellationToken.None).GetAwaiter().GetResult();
        return _dbContext.CutoffedPickingInstructions(okbCutoff);
    }


    private class GroupedQuery
    {
        public required PickingInstruction PickingInstruction { get; set; }
        public required PickingRoute PickingRoute { get; set; }
        public required IEnumerable<PickupPoint> PickupPoints { get; set; }
        public GoodReceive? GoodReceive { get; set; }
    }

    public async Task<PagingResult<QueryLPPickingInstructionUseCaseResult>> QueryLPPickingInstructionAsync(QueryLPPickingInstructionUseCase request, string transporterCode, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);

        var predicate = PredicateBuilder.True<GroupedQuery>();

        if (!string.IsNullOrEmpty(request.PickNo))
        {
            predicate = predicate.And(e => e.PickingInstruction.PickNo.Contains(request.PickNo));
        }

        if (request.Status.HasValue)
        {
            predicate = predicate.And(e => e.PickingInstruction.PickStatus == request.Status);
        }

        predicate = predicate.And(e => e.PickingInstruction.TransporterCode == transporterCode);
        predicate = predicate.And(e => e.PickupPoints.Any());

        var qry = _dbContext
            .CutoffedPickingInstructions(okbCutoff)
            .Join(_dbContext.PickingRoutes, pi => pi.RouteCode, pr => pr.RouteCode, (pi, pr) => new
            {
                PickingInstruction = pi,
                PickingRoute = pr
            })
            .GroupJoin(_dbContext.GoodReceives, pir => pir.PickingInstruction.SapPoNo, gr => gr.PONo, (pir, gr) => new
            {
                pir.PickingInstruction,
                pir.PickingRoute,
                GoodReceive = gr
            })
            .SelectMany(x => x.GoodReceive.DefaultIfEmpty(),
                (x, gr) => new 
                {
                    x.PickingInstruction,
                    x.PickingRoute,
                    GoodReceive = gr
                }
            )
            .GroupJoin(_dbContext.PickupPoints, pir => pir.PickingInstruction.Id, pp => pp.PickingInstructionId, (pir, pp) => new
                GroupedQuery
            {
                PickingInstruction = pir.PickingInstruction,
                PickingRoute = pir.PickingRoute,
                GoodReceive = pir.GoodReceive,
                PickupPoints = pp
            })
            .OrderByDescending(e => e.PickingInstruction.PickDate)
            .Where(predicate)
            .Select(e => new QueryLPPickingInstructionUseCaseResult
            {
                TotalPickupPoint = e.PickupPoints.Count(),
                TotalOkb = e.PickupPoints
                    .Where(pp => pp.PickingInstructionId == e.PickingInstruction.Id)
                    .SelectMany(pp => pp.OKBs)
                    .Count(),
                RouteName = e.PickingRoute.RouteName,
                TransporterCode = e.PickingInstruction.TransporterCode,
                CycleNo = e.PickingInstruction.CycleNo,
                RouteCode = e.PickingInstruction.RouteCode,
                PickNo = e.PickingInstruction.PickNo,
                PickDate = e.PickingInstruction.PickDate,
                Status = e.PickingInstruction.PickStatus,
                GRNo = e.GoodReceive.GRNo
            });

        return await PagingService.PaginateQueryAsync(qry, request, ct);
    }

    public async Task<Result<PickingInstruction>> UpdatePickingInstructionAsync(PickingInstruction pickingInstruction, CancellationToken cancellationToken)
    {
        _dbContext.PickingInstructions.Update(pickingInstruction);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickingInstruction>(PickingDomainError.FailedToUpdatePickingInstruction(result.Error.Description));
        }

        return Result.Success(pickingInstruction);
    }
}

