using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class OKBRepository : IOKBRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IAppConfigurationService _appConfigurationService;

    public OKBRepository(AppDbContext context, IUnitOfWork unitOfWork, IAppConfigurationService appConfigurationService)
    {
        _context = context;
        _unitOfWork = unitOfWork;
        _appConfigurationService = appConfigurationService;
    }

    public async Task<Result<OKB>> GetOkbByOkbNoAsync(string okbNo, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        var result = await _context.CutoffedOKBs(okbCutoff).FirstOrDefaultAsync(okb => okb.DnNo == okbNo, ct);

        if (result is null)
        {
            return Result.Failure<OKB>(PartDeliveryDomainError.OKBNotFound(okbNo));
        }

        return Result.Success(result);
    }

    public async Task<ICollection<OKB>> GetOKBsByListAsync(ICollection<string> okbNumbers, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        var result = await _context.CutoffedOKBs(okbCutoff).Where(okb => okbNumbers.Contains(EF.Functions.Collate(okb.DnNo, "Latin1_General_BIN2"))).ToListAsync(ct);

        return result;
    }

    public Task<PagingResult<OKB>> LoadPageAsync(IQueryable<OKB> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<OKB> Query()
    {
        var okbCutoff = _appConfigurationService.GetOkbCutoffDateAsync(CancellationToken.None).GetAwaiter().GetResult();
        return _context.CutoffedOKBs(okbCutoff);
    }

    public async Task<PagingResult<OKB>> QueryOKBsAsync(QueryOKBUseCase query, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
#pragma warning disable CS8602 // Dereference of a possibly null reference.
        var qry = _context.CutoffedOKBs(okbCutoff)
            .GroupJoin(_context.PickupPoints.SelectMany(e => e.OKBs),
                okb => okb.DnNo,
                po => po.OkbNo,
                (okb, po) => new { okb, po = po.OrderByDescending(e => e.CreateTime).FirstOrDefault() }
            )
            .Select(e => new OKB
            {
                Id = e.okb.Id,
                DnNo = e.okb.DnNo,
                DnDate = e.okb.DnDate,
                DnType = e.okb.DnType,
                SapPoNo = e.okb.SapPoNo,
                PosOrderId = e.okb.PosOrderId,
                PlantCode = e.okb.PlantCode,
                VendorCode = e.okb.VendorCode,
                VendorSite = e.okb.VendorSite,
                WarehouseCode = e.okb.WarehouseCode,
                MaterialCat = e.okb.MaterialCat,
                DockNo = e.okb.DockNo,
                ParkNo = e.okb.ParkNo,
                DeliveryType = e.okb.DeliveryType,
                TransporterCode = e.okb.TransporterCode,
                RouteCode = e.okb.RouteCode,
                CfcCode = e.okb.CfcCode,
                DlvDate = e.okb.DlvDate,
                DlvShift = e.okb.DlvShift,
                DlvTime = e.okb.DlvTime,
                DlvCycleNo = e.okb.DlvCycleNo,
                DnDesc100 = e.okb.DnDesc100,
                PrintStatus = e.okb.PrintStatus,
                PrintDate = e.okb.PrintDate,
                PrintBy = e.okb.PrintBy,
                RcvStatus = e.okb.RcvStatus,
                PickNo = e.okb.PickNo,
                SjNo = e.okb.SjNo,
                SjDate = e.okb.SjDate,
                ShopCode = e.okb.ShopCode,
                DelayReason = e.okb.DelayReason,
                CreateTime = e.okb.CreateTime,
                UpdateTime = e.okb.UpdateTime,
                UpdateBy = e.okb.UpdateBy,
                CreateBy = e.okb.CreateBy,
                Status = e.po == null ? 0 : e.po.Status
            });

        var predicate = PredicateBuilder.True<OKB>();

        if (!string.IsNullOrWhiteSpace(query.OkbNo))
        {
            predicate = predicate.And(x => x.DnNo.Contains(query.OkbNo));
        }

        if (!string.IsNullOrWhiteSpace(query.RouteCode))
        {
            predicate = predicate.And(x => x.RouteCode.Contains(query.RouteCode));
        }

        if (!string.IsNullOrWhiteSpace(query.TransporterCode))
        {
            predicate = predicate.And(x => x.TransporterCode.Contains(query.TransporterCode));
        }

        if (query.ArrivalDate is not null)
        {
            if (query.ArrivalDate.From != null)
            {
                var date = query.ArrivalDate.From.Value.ToDateTime(TimeOnly.MinValue);
                predicate = predicate.And(x => x.DlvDate >= date);
            }

            if (query.ArrivalDate.To != null)
            {
                var date = query.ArrivalDate.To.Value.ToDateTime(TimeOnly.MinValue);
                predicate = predicate.And(x => x.DlvDate <= date);
            }
        }

        if (query.ArrivalTime is not null)
        {
            if (query.ArrivalTime.From is not null)
            {
                var time = query.ArrivalTime.From;
                predicate = predicate.And(x => string.Compare(x.DlvTime, time) >= 0);
            }

            if (query.ArrivalTime.To is not null)
            {
                var time = query.ArrivalTime.To;
                predicate = predicate.And(x => string.Compare(x.DlvTime, time) <= 0);
            }
        }

        if (!string.IsNullOrWhiteSpace(query.VendorSite))
        {
            predicate = predicate.And(x => x.VendorSite.Contains(query.VendorSite));
        }

        if(query.Status is not null){
            predicate = predicate.And(x => x.Status == query.Status);
        }

        predicate = predicate.And(okb => okb.DeliveryType == OKB.DeliveryTypeEnum.MilkRun);
#pragma warning restore CS8602 // Dereference of a possibly null reference.

        qry = qry.Where(predicate);


        return await PagingService.PaginateQueryAsync(qry, query, _context, ct);
    }

    public async Task<Result> RemovePickNoAsync(ICollection<string> okbNumbers, CancellationToken ct)
    {
        var cutoffOkb = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        try
        {
            var result = await _context
                .CutoffedOKBs(cutoffOkb)
                .Where(okb => okbNumbers.Contains(okb.DnNo))
                .ExecuteUpdateAsync(okb => okb.SetProperty(e => e.PickNo, (e) => null));
            return Result.Success();
        }
        catch (Exception ex)
        {
            return Result.Failure(new Error("FailedToRemovePickNo", ex.Message));
        }
    }

    public async Task<Result> UpdateOKBPickNoAsync(ICollection<string> okbNumbers, string pickNo, CancellationToken ct)
    {
        var cutoffOkb = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        await _context.CutoffedOKBs(cutoffOkb)
            .Where(okb => okbNumbers.Contains(okb.DnNo))
            .ExecuteUpdateAsync(okb => okb.SetProperty(e => e.PickNo, pickNo));

        return await _unitOfWork.SaveChangesAsync(ct);
    }
}

