using IDTrack.Domain.Features.Picking;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class PickupPointEntityConfiguration : IEntityTypeConfiguration<PickupPoint>
{
    public void Configure(EntityTypeBuilder<PickupPoint> builder)
    {
        builder.ToTable("TR_TRACK_PICK_POINT");

        builder.HasKey(e => e.Id).HasName("PK_TR_TRACK_PICK_POINT");

        builder.Ignore(e => e.CreateByStr);
        builder.Ignore(e => e.UpdateByStr);

        builder.HasIndex(e => e.PickingInstructionId).HasDatabaseName("IDX_TR_TRACK_PICK_POINT_PICK_ID");

        builder.Property(e => e.Id).HasColumnName("ID");

        builder.Ignore(e => e.Supplier);

        builder.Property(e => e.PickingInstructionId)
            .IsRequired()
            .HasColumnName("PICK_ID");

        builder.Property(e => e.VendorCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("VENDOR_CODE");

        builder.Property(e => e.VendorSite)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("VENDOR_SITE");

        builder.Property(e => e.StartByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("START_BY_DEVICE_ID");

        builder.Property(e => e.CompleteByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("COMPLETE_BY_DEVICE_ID");


        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        builder.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");

        builder.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        builder.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        builder.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_TIME");

        builder.OwnsMany(e => e.OKBs, ob =>
        {
            ob.ToTable("TR_TRACK_PICK_OKB");

            ob.HasKey(e => e.Id).HasName("PK_TR_TRACK_PICK_OKB");
            ob.Ignore(e => e.CreateByStr);
            ob.Ignore(e => e.UpdateByStr);

            ob.WithOwner().HasForeignKey("TRACK_PICK_POINT_ID");

            ob.Property(e => e.Id).HasColumnName("ID");

            ob.Property(e => e.OkbNo)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false)
                .HasColumnName("DN_NO");

            ob.HasIndex(e => e.OkbNo).HasDatabaseName("IDX_TR_TRACK_PICK_OKB_DN_NO");

            ob.Property(e => e.DelayReason)
                .HasMaxLength(100)
                .IsRequired(false)
                .IsUnicode(false)
                .HasColumnName("DELAY_REASON");

            ob.Property(e => e.IsAdvanced)
                .HasColumnName("IS_ADVANCED");

            ob.Property(e => e.ScannedByDeviceId)
                .HasMaxLength(36)
                .IsUnicode(false)
                .HasColumnName("SCAN_BY_DEVICE_ID");

            ob.Property(e => e.DelayedByDeviceId)
                .HasMaxLength(36)
                .IsUnicode(false)
                .HasColumnName("DELAY_BY_DEVICE_ID");

            ob.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

            ob.Property(e => e.CreateTime)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("CREATE_TIME");

            ob.Property(e => e.Status)
                .HasDefaultValue(0)
                .HasColumnName("STATUS");

            ob.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

            ob.Property(e => e.UpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_TIME");
        });
    }
}

