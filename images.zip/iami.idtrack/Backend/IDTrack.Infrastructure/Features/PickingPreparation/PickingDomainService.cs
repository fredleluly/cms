using System.Globalization;
using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.ComponentTracking.Picking.UseCases;
using IDTrack.Application.Features.Monitoring.UseCases;
using IDTrack.Application.Features.PickingPreparation.PartDelivery;
using IDTrack.Application.Features.PickingPreparation.PartDelivery.UseCases;
using IDTrack.Application.Features.PickingPreparation.Picking;
using IDTrack.Application.Features.PickingPreparation.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PartDelivery;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Features.Picking.Entities;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Document;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using MigraDoc.DocumentObjectModel;
using MigraDoc.DocumentObjectModel.Tables;
using MigraDoc.Rendering;
using PdfSharp.Snippets.Drawing;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.PixelFormats;
using ZXing;
using ZXing.Common;
using Result = IDTrack.Domain.Models.Result;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class PickingDomainService : IPickingDomainService
{
    private readonly IPickupPointRepository _pickupPointRepository;
    private readonly IOKBRepository _okbRepository;
    private readonly AppDbContext _dbContext;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IAppConfigurationService _appConfigurationService;

    public PickingDomainService(
        IOKBRepository okbRepository,
        IPickupPointRepository pickupPointRepository,
        AppDbContext dbContext,
        IUnitOfWork unitOfWork,
        IAppConfigurationService appConfigurationService)
    {
        _okbRepository = okbRepository;
        _pickupPointRepository = pickupPointRepository;
        _dbContext = dbContext;
        _unitOfWork = unitOfWork;
        _appConfigurationService = appConfigurationService;
    }

    public async Task<Result<GetPickingSessionUseCaseResult>> GetActivePickingSessionByDriverIdAsync(int driverId, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        var result = await _dbContext
            .CutoffedPickingInstructions(okbCutoff)
            .Join(_dbContext.PickingRoutes, pi => pi.RouteCode, pr => pr.RouteCode, (pi, pr) => new
            {
                PickingInstruction = pi,
                PickingRoute = pr
            })
            .Join(_dbContext.PickingTransporters, pi => pi.PickingInstruction.TransporterCode, pt => pt.TransporterCode, (pi, pt) => new
            {
                PickingTransporter = pt,
                pi.PickingInstruction,
                pi.PickingRoute
            })
            .GroupJoin(
                _dbContext
                    .PickupPoints
                    .Join(
                        _dbContext.PartSuppliers,
                        pp => pp.VendorSite,
                        ps => ps.VendorCode,
                        (pp, ps) => new { PickupPoint = pp, PartSupplier = ps }
                    ),
                pi => pi.PickingInstruction.Id,
                pp => pp.PickupPoint.PickingInstructionId, (pi, pp) => new
                {
                    pi.PickingInstruction,
                    pi.PickingRoute,
                    pi.PickingTransporter,
                    PickupPoints = pp
                })
            .Where(e =>
                e.PickingInstruction.DriverId == driverId &&
                e.PickingInstruction.PickStatus == PickingInstruction.PickingStatus.InProgress
            )
            .Select(e => new GetPickingSessionUseCaseResult(
                e.PickingInstruction.Id,
                e.PickingInstruction.PickNo,
                e.PickingRoute.RouteName,
                e.PickingTransporter.TransporterName,
                e.PickingTransporter.TransporterCode,
                e.PickingInstruction.CycleNo,
                e.PickingInstruction.PickDate,
                e.PickingInstruction.ArrivalDate,
                e.PickingInstruction.ArrivalTime,
                e.PickingInstruction.PickStartTime,
                e.PickupPoints
                    .Select(p => new PickupPointDto(
                        p.PickupPoint.Id,
                        p.PartSupplier.VendorName,
                        p.PartSupplier.Address,
                        p.PickupPoint.OKBs
                            .Select(e => new PickupOKBDto(
                                e.OkbNo,
                                e.Status,
                                e.IsAdvanced
                            ))
                            .ToList(),
                        p.PickupPoint.Status,
                        p.PartSupplier.Lat,
                        p.PartSupplier.Lng
                    )).ToList()
            ))
            .AsSplitQuery()
            .FirstOrDefaultAsync();

        if (result == null)
            return Result.Failure<GetPickingSessionUseCaseResult>(PickingDomainError.PickingInstructionNotFound);

        return Result.Success(result);
    }

    public async Task<Result<ICollection<GetMonitoringDataUseCaseResult>>> GetMonitoringDataAsync(GetMonitoringDataUseCase request, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        ICollection<GetMonitoringDataUseCaseResult> result = await _dbContext
            .CutoffedPickingInstructions(okbCutoff)
            .GroupJoin(_dbContext
                    .PickupPoints
                    .Join(_dbContext.PartSuppliers, (pp) => pp.VendorSite, ps => ps.VendorCode, (pp, ps) => new { PickupPoint = pp, PartSupplier = ps }),
                pi => pi.Id,
                pp => pp.PickupPoint.PickingInstructionId,
                (pi, pp) => new GetMonitoringDataUseCaseResult
                {
                    Id = pi.Id,
                    PickNo = pi.PickNo,
                    RouteCode = pi.RouteCode,
                    TransporterCode = pi.TransporterCode,
                    CycleNo = pi.CycleNo,
                    PickDate = pi.PickDate,
                    ArrivalDate = pi.ArrivalDate,
                    ArrivalTime = pi.ArrivalTime,
                    RcvStatus = pi.RcvStatus,
                    GeofencingEnabled = pi.GeofencingEnabled,
                    Untracked = pi.Untracked,
                    PickStatus = pi.PickStatus,
                    DriverId = pi.DriverId,
                    PickStartTime = pi.PickStartTime,
                    GateInTime = pi.GateInTime,
                    CreateBy = pi.CreateBy,
                    CreateTime = pi.CreateTime,
                    UpdateBy = pi.UpdateBy,
                    UpdateTime = pi.UpdateTime,
                    PickupPoints = pp.Select(e => new PickupPoint
                    {
                        Id = e.PickupPoint.Id,
                        PickingInstructionId = e.PickupPoint.PickingInstructionId,
                        VendorCode = e.PickupPoint.VendorCode,
                        VendorSite = e.PickupPoint.VendorSite,
                        OKBs = e.PickupPoint.OKBs,
                        Supplier = e.PartSupplier,
                        CreateBy = e.PickupPoint.CreateBy,
                        CreateTime = e.PickupPoint.CreateTime,
                        UpdateBy = e.PickupPoint.UpdateBy,
                        UpdateTime = e.PickupPoint.UpdateTime,
                        Status = e.PickupPoint.Status
                    }).ToList()
                })
            .Where(e =>
                (e.ArrivalDate == request.ArrivalDate.ToDateTime(TimeOnly.MinValue) ||
                (e.PickStatus == PickingInstruction.PickingStatus.InProgress && !e.Untracked)
                ) &&
                e.PickupPoints.Any()
            ).AsNoTracking()
            .AsSplitQuery()
            .OrderByDescending(e => e.PickStatus == PickingInstruction.PickingStatus.InProgress
                ? 2
                : e.PickStatus >= PickingInstruction.PickingStatus.GateIn
                    ? 0
                    : 1
            )
            .ThenByDescending(e => e.ArrivalDate)
            .ThenByDescending(e => e.ArrivalTime)
            .ToListAsync();

        return Result.Success(result);
    }

    // TODO: Validate mismatch route or transporter code in OKB list
    public async Task<Result> InsertOrUpdatePickingOKBAsync(PickingInstruction pickingInstruction, ICollection<string> okbNumbers, CancellationToken ct)
    {
        var foundOkbs = await _okbRepository.GetOKBsByListAsync(okbNumbers, ct);

        var notFoundOKBs = foundOkbs.Count > 0 ? okbNumbers.Except(foundOkbs.Select(o => o.DnNo)).ToList() : new List<string>();

        if (notFoundOKBs.Count() > 0)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PartDeliveryDomainError.OKBNotFound(string.Join(", ", notFoundOKBs)));
        }

        var foundPickupPoints = await _pickupPointRepository.GetPickupPointsByPickNoAsync(pickingInstruction.PickNo, ct);

        if (foundPickupPoints.IsFailure || foundPickupPoints.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(foundPickupPoints.Error);
        }

        var pickupPoints = new List<PickupPoint>();

        // new PickupPoint
        var newOkbNumbers = new List<string>();
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite)
            .Where(e => !foundPickupPoints.Value.Any(p => p.VendorSite == e.Key)))
        {
            var pickPoint = new PickupPoint
            {
                Id = 0,
                PickingInstructionId = pickingInstruction.Id,
                VendorSite = okbGroup.Key,
                VendorCode = okbGroup.First().VendorCode,
            };

            pickPoint.SetOkb(okbGroup.Select(e => e.DnNo));
            newOkbNumbers.AddRange(okbGroup.Select(e => e.DnNo));
            pickupPoints.Add(pickPoint);
        }

        // existing PickupPoint
        var deletedOkbNumbers = new List<string>();
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite)
            .Where(e => foundPickupPoints.Value.Any(p => p.VendorSite == e.Key)))
        {
            var pickPoint = foundPickupPoints.Value.First(p => p.VendorSite == okbGroup.Key);
            _dbContext.Attach(pickPoint);

            var deletedOkbs = pickPoint.SetOkb(okbGroup.Select(e => e.DnNo));

            if (deletedOkbs.Value is not null)
                deletedOkbNumbers.AddRange(deletedOkbs.Value);

            var newOkbs = okbGroup.Select(e => e.DnNo).Except(pickPoint.OKBs.Select(e => e.OkbNo)).ToList();
            newOkbNumbers.AddRange(newOkbs);

            pickupPoints.Add(pickPoint);
        }

        // set advance flag in pickupOkb
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite))
        {
            var pickPoint = pickupPoints.FirstOrDefault(p => p.VendorSite == okbGroup.Key);
            var advancedOkbList = okbGroup
                .Where(e => e.DlvDate > pickingInstruction.ArrivalDate ||
                    (e.DlvDate == pickingInstruction.ArrivalDate && e.DlvTime?.CompareTo(pickingInstruction.ArrivalTime) > 0)
                )
                .Select(e => e.DnNo).ToList();

            if (advancedOkbList.Count() > 0 && pickPoint is not null)
            {
                pickPoint.AdvanceOkbs(advancedOkbList);
            }
        }

        // delete non existing pickup point in request
        var pickupPointToBeDeleted = foundPickupPoints
            .Value
            .Except(pickupPoints)
            .ToList();

        var deleteResult = await _pickupPointRepository
            .DeletePickupPointRangeAsync(pickupPointToBeDeleted.Select(e => e.Id).ToList(), ct);

        // remove Pick No in OKBs
        deletedOkbNumbers.AddRange(pickupPointToBeDeleted.SelectMany(e => e.OKBs).Select(e => e.OkbNo));

        // set pickup status to delay if previously reassigned
        await SetDelayIfReassignedAsync(deletedOkbNumbers, ct);

        // set pickup status to reassigned if previously delayed
        await SetReassignedIfDelayAsync(newOkbNumbers, ct);

        // remove pick no in TR_POS_DN for removed OKBs
        await _okbRepository.RemovePickNoAsync(deletedOkbNumbers, ct);

        if (deleteResult.IsFailure)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(deleteResult.Error);
        }

        var pickPointResult = await _pickupPointRepository.CreateOrUpdateRangeAsync(pickupPoints, ct);

        if (pickPointResult.IsFailure || pickPointResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickPointResult.Error);
        }

        return Result.Success();
    }

    private async Task<Result> SetDelayIfReassignedAsync(ICollection<string> okbNumbers, CancellationToken ct)
    {
        var pickupPoints = await _pickupPointRepository.GetLastPickupPointOfOkbsAsync(okbNumbers, ct);

        if (pickupPoints.IsFailure || pickupPoints.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickupPoints.Error);
        }

        var okbs = pickupPoints.Value
            .SelectMany(e => e.OKBs)
            .OrderByDescending(e => e.CreateTime)
            .ThenByDescending(e => e.UpdateTime)
            .ToList();

        foreach (var okbNo in okbNumbers)
        {
            var pickupOkb = okbs
                .FirstOrDefault(e => e.OkbNo == okbNo);

            if (pickupOkb is not null && pickupOkb.Status == PickupOKB.PickupOKBStatus.Reassigned)
            {
                pickupOkb.Delay(pickupOkb.DelayReason ?? "Removed from picking instruction");
            }
        }

        return Result.Success();
    }

    private async Task<Result> SetReassignedIfDelayAsync(ICollection<string> okbNumbers, CancellationToken ct)
    {
        var pickupPoints = await _pickupPointRepository.GetLastPickupPointOfOkbsAsync(okbNumbers, ct);

        if (pickupPoints.IsFailure || pickupPoints.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickupPoints.Error);
        }

        var okbs = pickupPoints.Value
            .SelectMany(e => e.OKBs)
            .OrderByDescending(e => e.CreateTime)
            .ThenByDescending(e => e.UpdateTime)
            .ToList();

        foreach (var okbNo in okbNumbers)
        {
            var pickupOkb = okbs
                .FirstOrDefault(e => e.OkbNo == okbNo);

            if (pickupOkb is not null && pickupOkb.Status == PickupOKB.PickupOKBStatus.Delayed)
            {
                pickupOkb.Reassign();
            }
        }

        return Result.Success();
    }

    public async Task<Result> AssignPickingOKBAsync(PickingInstruction pickingInstruction, ICollection<string> okbNumbers, CancellationToken ct)
    {
        var foundOkbs = await _okbRepository.GetOKBsByListAsync(okbNumbers, ct);

        var notFoundOKBs = foundOkbs.Count > 0 ? okbNumbers.Except(foundOkbs.Select(o => o.DnNo)).ToList() : new List<string>();

        if (notFoundOKBs.Count() > 0)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PartDeliveryDomainError.OKBNotFound(string.Join(", ", notFoundOKBs)));
        }

        // validate if foundOkbs has the same transporter code, route code, and cycle
        var firstOkb = foundOkbs.FirstOrDefault();

        if (firstOkb is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PickingDomainError.OKBNotFound);
        }

        if (foundOkbs.Any(e => e.TransporterCode != firstOkb.TransporterCode ||
            e.RouteCode != firstOkb.RouteCode))
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(PickingDomainError.OKBHasDifferentPickingDetails);
        }

        var alreadyExistInPickInsOkbs = foundOkbs.Where(e => e.PickNo == pickingInstruction.PickNo).ToList();

        if (alreadyExistInPickInsOkbs.Count() > 0)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(
                PickingDomainError
                    .OKBAlreadyInPickingInstruction(
                        string.Join(", ", alreadyExistInPickInsOkbs.Select(e => e.DnNo))
                    ));
        }

        // set last pickup okb status to reassigned
        var lastPickupPoints = await _pickupPointRepository.GetLastPickupPointOfOkbsAsync(okbNumbers, ct);
        if (lastPickupPoints.Value is not null)
        {
            var reassignedOkbs = lastPickupPoints.Value
                .SelectMany(e => e.OKBs)
                .IntersectBy(okbNumbers, e => e.OkbNo)
                .ToList();

            reassignedOkbs
                .ForEach(okb => okb.Reassign());

            await _unitOfWork.SaveChangesAsync(ct);
        }

        // destination pickup points
        var foundPickupPoints = await _pickupPointRepository.GetPickupPointsByPickNoAsync(pickingInstruction.PickNo, ct);

        if (foundPickupPoints.IsFailure || foundPickupPoints.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(foundPickupPoints.Error);
        }

        var pickupPoints = new List<PickupPoint>();

        // new PickupPoint
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite)
            .Where(e => !foundPickupPoints.Value.Any(p => p.VendorSite == e.Key)))
        {
            var pickPoint = new PickupPoint
            {
                Id = 0,
                PickingInstructionId = pickingInstruction.Id,
                VendorSite = okbGroup.Key,
                VendorCode = okbGroup.First().VendorCode,
            };

            pickPoint.SetOkb(okbGroup.Select(e => e.DnNo));

            pickupPoints.Add(pickPoint);
        }

        // existing PickupPoint
        var finishedPickupPoint = new List<PickupPoint>();
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite)
            .Where(e => foundPickupPoints.Value.Any(p => p.VendorSite == e.Key)))
        {
            var pickPoint = foundPickupPoints.Value.First(p => p.VendorSite == okbGroup.Key);
            _dbContext.Entry(pickPoint).State = EntityState.Modified;

            foreach (var okb in okbGroup)
            {
                pickPoint.AddOkb(okb.DnNo);
            }

            pickupPoints.Add(pickPoint);

            if (pickPoint.Status == PickupPoint.PickupPointStatus.Picked)
            {
                finishedPickupPoint.Add(pickPoint);
            }
        }

        if (finishedPickupPoint.Count() > 0)
        {
            return Result.Failure(PickingDomainError.CannotAssignOKBToCompletedPickupPoints(string.Join(", ", finishedPickupPoint.Select(e => e.VendorSite))));
        }

        // set advance flag in pickupOkb
        foreach (var okbGroup in foundOkbs
            .GroupBy(e => e.VendorSite))
        {
            var pickPoint = pickupPoints.First(p => p.VendorSite == okbGroup.Key);
            var advancedOkbList = okbGroup
                .Where(e => e.DlvDate > pickingInstruction.ArrivalDate ||
                    (e.DlvDate == pickingInstruction.ArrivalDate && e.DlvTime?.CompareTo(pickingInstruction.ArrivalTime) > 0)
                )
                .Select(e => e.DnNo).ToList();

            if (advancedOkbList.Count() > 0)
            {
                pickPoint.AdvanceOkbs(advancedOkbList);
            }
        }

        var pickPointResult = await _pickupPointRepository.CreateOrUpdateRangeAsync(pickupPoints, ct);

        if (pickPointResult.IsFailure || pickPointResult.Value is null)
        {
            return Result.Failure<CreatePickingInstructionUseCaseResult>(pickPointResult.Error);
        }

        return Result.Success();
    }

    public async Task<PagingResult<OKB>> QueryOKBToBeProcessedAsync(QueryDelayedOrUnassignedOKBUseCase pagingQuery, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
        var qry = _dbContext.CutoffedOKBs(okbCutoff).AsQueryable();

        qry = qry
            .GroupJoin(_dbContext.PickupPoints.SelectMany(e => e.OKBs),
                okb => okb.DnNo,
                po => po.OkbNo,
                (okb, po) => new { okb, po })
            .SelectMany(x => x.po.DefaultIfEmpty(),
                (x, po) => new { x.okb, po })
#pragma warning disable
            .Where(e => e.po == null || e.po.Status == PickupOKB.PickupOKBStatus.Delayed)
            .Select(e => new OKB
            {
                Id = e.okb.Id,
                DnNo = e.okb.DnNo,
                DnDate = e.okb.DnDate,
                DnType = e.okb.DnType,
                SapPoNo = e.okb.SapPoNo,
                PosOrderId = e.okb.PosOrderId,
                PlantCode = e.okb.PlantCode,
                VendorCode = e.okb.VendorCode,
                VendorSite = e.okb.VendorSite,
                WarehouseCode = e.okb.WarehouseCode,
                MaterialCat = e.okb.MaterialCat,
                DockNo = e.okb.DockNo,
                ParkNo = e.okb.ParkNo,
                DeliveryType = e.okb.DeliveryType,
                TransporterCode = e.okb.TransporterCode,
                RouteCode = e.okb.RouteCode,
                CfcCode = e.okb.CfcCode,
                DlvDate = e.okb.DlvDate,
                DlvShift = e.okb.DlvShift,
                DlvTime = e.okb.DlvTime,
                DlvCycleNo = e.okb.DlvCycleNo,
                DnDesc100 = e.okb.DnDesc100,
                PrintStatus = e.okb.PrintStatus,
                PrintDate = e.okb.PrintDate,
                PrintBy = e.okb.PrintBy,
                RcvStatus = e.okb.RcvStatus,
                PickNo = e.okb.PickNo,
                SjNo = e.okb.SjNo,
                SjDate = e.okb.SjDate,
                ShopCode = e.okb.ShopCode,
                Status = e.po != null ? e.po.Status : 0,
                DelayReason = e.po != null ? e.po.DelayReason : "",
                CreateBy = e.okb.CreateBy,
                CreateTime = e.okb.CreateTime,
                UpdateBy = e.okb.UpdateBy,
                UpdateTime = e.okb.UpdateTime
            });
#pragma warning restore

        var predicate = PredicateBuilder.True<OKB>();

        if (!string.IsNullOrEmpty(pagingQuery.OkbNo))
        {
            predicate = predicate.And(e => e.DnNo.Contains(pagingQuery.OkbNo));
        }
#pragma warning disable
        if (!string.IsNullOrEmpty(pagingQuery.PickNo))
            predicate = predicate.And(e => e.PickNo.Contains(pagingQuery.PickNo));

        if (!string.IsNullOrEmpty(pagingQuery.RouteCode))
            predicate = predicate.And(e => e.RouteCode.Contains(pagingQuery.RouteCode));

        if (!string.IsNullOrEmpty(pagingQuery.TransporterCode))
            predicate = predicate.And(e => e.TransporterCode.Contains(pagingQuery.TransporterCode));
#pragma warning restore
        if (pagingQuery.ArrivalDate is not null)
        {
            if (pagingQuery.ArrivalDate.From != null)
            {
                var date = pagingQuery.ArrivalDate.From.Value.ToDateTime(TimeOnly.MinValue);
                predicate = predicate.And(x => x.DlvDate >= date);
            }

            if (pagingQuery.ArrivalDate.To != null)
            {
                var date = pagingQuery.ArrivalDate.To.Value.ToDateTime(TimeOnly.MinValue);
                predicate = predicate.And(x => x.DlvDate <= date);
            }
        }

        if (pagingQuery.ArrivalTime is not null)
        {
            if (!string.IsNullOrEmpty(pagingQuery.ArrivalTime.From))
            {
                var time = pagingQuery.ArrivalTime.From;
                predicate = predicate.And(x => string.Compare(x.DlvTime, time) >= 0);
            }

            if (!string.IsNullOrEmpty(pagingQuery.ArrivalTime.To))
            {
                var time = pagingQuery.ArrivalTime.To;
                predicate = predicate.And(x => string.Compare(x.DlvTime, time) <= 0);
            }
        }

        if (!string.IsNullOrEmpty(pagingQuery.VendorSite))
            predicate = predicate.And(e => e.VendorSite.Contains(pagingQuery.VendorSite));

        predicate = predicate.And(e => e.DeliveryType == OKB.DeliveryTypeEnum.MilkRun);

        qry = qry
            .Where(predicate);

        if (pagingQuery.SortBy is not null && pagingQuery.SortBy.Contains("DnNo"))
        {
            return await PagingService.PaginateQueryAsync(qry, pagingQuery, ct);
        }

        var newPaging = pagingQuery with
        {
            SortBy = string.IsNullOrEmpty(pagingQuery.SortBy) ? "-DnNo" : pagingQuery.SortBy + ",-DnNo",
        };

        return await PagingService.PaginateQueryAsync(qry, newPaging, ct);
    }

    public Task<Result> RemoveOKBFromPickupPointAsync(PickupPoint pickupPoint, string okbNo, CancellationToken ct)
    {
        _dbContext.Attach(pickupPoint);
        var removeResult = pickupPoint.RemoveOkb(okbNo);

        if (removeResult.IsFailure)
        {
            return Task.FromResult(removeResult);
        }

        return Task.FromResult(Result.Success());
    }

    public async Task<Result<ICollection<GetPickupPointsByPickNoUseCaseResult>>> GetPickupPointsUseCaseResultByPickNoAsync(string pickNo, CancellationToken ct)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(ct);
#pragma warning disable CS8602
        ICollection<GetPickupPointsByPickNoUseCaseResult> result = await _dbContext
            .PickupPoints
            .Join(_dbContext.CutoffedPickingInstructions(okbCutoff),
                pp => pp.PickingInstructionId,
                pi => pi.Id,
                (pp, pi) => new { PickupPoint = pp, PickNo = pi.PickNo })
            .GroupJoin(_dbContext.PartSuppliers,
                pp => pp.PickupPoint.VendorCode,
                ps => ps.VendorCode,
                (pp, ps) => new { PickupPoint = pp.PickupPoint, PartSupplier = ps, PickNo = pp.PickNo })
            .SelectMany(e => e.PartSupplier.DefaultIfEmpty(),
                (pp, ps) => new { PickupPoint = pp.PickupPoint, PartSupplier = ps, PickNo = pp.PickNo })
            .Where(e => e.PickNo == pickNo)
            .Select(e => new { e.PickupPoint, e.PartSupplier })
            .SelectMany(pp => pp.PickupPoint.OKBs, (pp, okb) => new
            {
                PickupPoint =
                pp.PickupPoint,
                OKB = okb,
                PartSupplier = pp.PartSupplier
            })
            .Join(_dbContext.CutoffedOKBs(okbCutoff), pp => pp.OKB.OkbNo, okb => okb.DnNo, (pp, okb) => new { pp.PickupPoint, PickupOKB = pp.OKB, OKB = okb, pp.PartSupplier })
            .GroupBy(e => e.PickupPoint)
            .Select(e => new GetPickupPointsByPickNoUseCaseResult
            {
                Id = e.Key.Id,
                VendorSite = e.Key.VendorSite,
                VendorCode = e.Key.VendorCode,
                Supplier = e.FirstOrDefault().PartSupplier,
                PickingInstructionId = e.Key.PickingInstructionId,
                Status = e.Key.Status,
                CreateBy = e.Key.CreateBy,
                CreateTime = e.Key.CreateTime,
                UpdateBy = e.Key.UpdateBy,
                UpdateTime = e.Key.UpdateTime,
                OKBs = e.Select(o => new OKB
                {
                    Id = o.OKB.Id,
                    DnNo = o.OKB.DnNo,
                    DnDate = o.OKB.DnDate,
                    DnType = o.OKB.DnType,
                    SapPoNo = o.OKB.SapPoNo,
                    PosOrderId = o.OKB.PosOrderId,
                    PlantCode = o.OKB.PlantCode,
                    VendorCode = o.OKB.VendorCode,
                    VendorSite = o.OKB.VendorSite,
                    WarehouseCode = o.OKB.WarehouseCode,
                    MaterialCat = o.OKB.MaterialCat,
                    DockNo = o.OKB.DockNo,
                    ParkNo = o.OKB.ParkNo,
                    DeliveryType = o.OKB.DeliveryType,
                    TransporterCode = o.OKB.TransporterCode,
                    RouteCode = o.OKB.RouteCode,
                    CfcCode = o.OKB.CfcCode,
                    DlvDate = o.OKB.DlvDate,
                    DlvShift = o.OKB.DlvShift,
                    DlvTime = o.OKB.DlvTime,
                    DlvCycleNo = o.OKB.DlvCycleNo,
                    DnDesc100 = o.OKB.DnDesc100,
                    PrintStatus = o.OKB.PrintStatus,
                    PrintDate = o.OKB.PrintDate,
                    PrintBy = o.OKB.PrintBy,
                    RcvStatus = o.OKB.RcvStatus,
                    PickNo = o.OKB.PickNo,
                    SjNo = o.OKB.SjNo,
                    SjDate = o.OKB.SjDate,
                    ShopCode = o.OKB.ShopCode,
                    Status = o.PickupOKB.Status,
                    DelayReason = o.PickupOKB.DelayReason,
                    CreateBy = o.OKB.CreateBy,
                    CreateTime = o.OKB.CreateTime,
                    UpdateBy = o.OKB.UpdateBy,
                    UpdateTime = o.OKB.UpdateTime
                }).ToList()
            })
            .ToListAsync();
#pragma warning restore CS8602

        return Result.Success(result);
    }
    private List<string> _filesToClean = new List<string>();

    public async Task<byte[]> DownloadPickingSheetAsync(PickingInstructionPDFDto pickingInstruction)
    {
        return await Task.Run(() =>
        {
            var document = new MigraDoc.DocumentObjectModel.Document();

            // Set default font
            var style = document.Styles["Normal"] ?? document.Styles.AddStyle("Normal", "Normal");
            style.Font.Name = "Courier";
            style.Font.Size = 8;

            int rowsPerPage = 30;
            int totalOkb = pickingInstruction.PickupPoints.Sum(e => e.OKBs.Count);
            int pageCount = Math.Max(1, (int)Math.Ceiling((double)totalOkb / rowsPerPage));
            var okbs = pickingInstruction.PickupPoints.SelectMany(e => e.OKBs, (p, okb) => new { p.SupplierAlias, OKB = okb });

            int currentSupplierNumber = 1;
            int lastOkb = 0;
            for (int currentPage = 1; currentPage <= pageCount; currentPage++)
            {
                var section = document.AddSection();

                string binDirectory = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)!;
                var imagePath = Path.Combine(binDirectory, DocumentConstants.TemplateFolder, DocumentConstants.IsuzuLogo);

                var header = section.AddTable();
                header.AddColumn(Unit.FromCentimeter(14));
                header.AddColumn(Unit.FromCentimeter(2.7));

                var headRow = header.AddRow();

                var barcodeContent = pickingInstruction.PickNo;
                headRow.Cells[0].AddImage(imagePath);
                AddBarcode(headRow.Cells[1], barcodeContent, BarcodeFormat.QR_CODE, 2.5, 2.5);
                var text = headRow.Cells[1].AddParagraph(barcodeContent);
                text.Format.Alignment = ParagraphAlignment.Center;
                section.AddParagraph("");

                // Title
                var title = section.AddParagraph("PICK-UP SHEET");
                title.Format.Alignment = ParagraphAlignment.Center;
                title.Format.Font.Bold = true;
                title.Format.Font.Size = 16;
                title.Format.SpaceAfter = 10;

                // Header Info Table
                var infoTable = section.AddTable();
                infoTable.AddColumn(Unit.FromCentimeter(4));  // Label
                infoTable.AddColumn(Unit.FromCentimeter(5));  // Value
                infoTable.AddColumn(Unit.FromCentimeter(4));  // Label
                infoTable.AddColumn(Unit.FromCentimeter(5));  // Value

                string formattedArrivalDate = pickingInstruction.ArrivalDate.ToString("dddd, dd.MM.yy", new CultureInfo("id-ID"));

                // Row 1
                var row1 = infoTable.AddRow();
                row1.Format.Font.Size = 10;
                row1.Cells[0].AddParagraph("Tanggal");
                row1.Cells[1].AddParagraph(": " + formattedArrivalDate);
                row1.Cells[2].AddParagraph("Pickup No");
                row1.Cells[3].AddParagraph(": " + pickingInstruction.PickNo);

                // Row 2
                var row2 = infoTable.AddRow();
                row2.Format.Font.Size = 10;
                row2.Cells[0].AddParagraph("Group Milkrun");
                row2.Cells[1].AddParagraph(": Bekasi Karawang");
                row2.Cells[2].AddParagraph("No PO");
                row2.Cells[3].AddParagraph(": PO20240101001");

                // Row 3
                var row3 = infoTable.AddRow();
                row3.Format.Font.Size = 10;
                row3.Cells[0].AddParagraph("Cycle");
                row3.Cells[1].AddParagraph(": " + pickingInstruction.CycleNo.ToString());
                row3.Cells[2].AddParagraph("Vendor Code");
                row3.Cells[3].AddParagraph(": " + pickingInstruction.TransporterCode);

                // Row 4
                var row4 = infoTable.AddRow();
                row4.Format.Font.Size = 10;
                row4.Cells[0].AddParagraph("No. Police");
                row4.Cells[1].AddParagraph(": F 4912 FGC");

                section.AddParagraph(""); // Spacing

                // Main Table
                var table = section.AddTable();
                table.Borders.Width = 0.5;

                // Add columns
                table.AddColumn(Unit.FromCentimeter(1.5));  // No
                table.AddColumn(Unit.FromCentimeter(3));    // Supplier
                table.AddColumn(Unit.FromCentimeter(2.5));  // Pickup Time
                table.AddColumn(Unit.FromCentimeter(4));    // OKB
                table.AddColumn(Unit.FromCentimeter(2));    // Stempel
                table.AddColumn(Unit.FromCentimeter(2));    // Paraf
                table.AddColumn(Unit.FromCentimeter(2));    // Remark

                // Add header row
                var headerRow2 = table.AddRow();
                headerRow2.Format.Font.Size = 10;
                string[] headers = ["No", "Supplier", "Pickup Time", "OKB", "Stempel", "Paraf", "Remark"];

                for (int i = 0; i < headers.Length; i++)
                {
                    headerRow2.Cells[i].AddParagraph(headers[i]);
                    headerRow2.Cells[i].Format.Alignment = ParagraphAlignment.Center;
                    headerRow2.Cells[i].VerticalAlignment = VerticalAlignment.Center;
                }

                if (totalOkb > 1)
                {
                    // insert okb
                    string? currentSuppAlias = okbs.ElementAt(lastOkb).SupplierAlias;
                    for (int i = lastOkb; i <= (currentPage * rowsPerPage) && i <= okbs.Count(); i++)
                    {
                        var currentOkb = okbs.ElementAt(i == okbs.Count() ? okbs.Count() - 1 : i);
                        if (currentOkb.SupplierAlias != currentSuppAlias)
                        {
                            AddSupplierRow(
                                table,
                                currentSupplierNumber++.ToString(),
                                currentSuppAlias,
                                [.. okbs.Skip(lastOkb).Take(i - lastOkb).Select(e => e.OKB.OkbNo)]
                            );
                            currentSuppAlias = currentOkb.SupplierAlias;
                            lastOkb = i;
                        }
                        else if (i == currentPage * rowsPerPage || i == okbs.Count())
                        {
                            AddSupplierRow(
                                table,
                                currentSupplierNumber.ToString(),
                                currentSuppAlias,
                                [.. okbs.Skip(lastOkb).Take(i - lastOkb).Select(e => e.OKB.OkbNo)]
                            );
                            currentSuppAlias = currentOkb.SupplierAlias;
                            lastOkb = i;
                        }
                    }
                }

                // Add Note
                section.Footers.Primary.AddParagraph("");
                section.Footers.Primary.AddParagraph("Note:").Format.Font.Size = 10;
                section.Footers.Primary.AddParagraph("");

                var footer = section.Footers.Primary.AddTable();
                footer.Borders.Width = 0.5;

                // Add columns
                footer.AddColumn(Unit.FromCentimeter(9));
                footer.AddColumn(Unit.FromCentimeter(8));

                // Add header row
                var footerRow = footer.AddRow();
                footerRow.VerticalAlignment = VerticalAlignment.Center;
                footerRow.Format.Font.Size = 10;
                footerRow.Cells[0].AddParagraph("No. Good Receive:");
                footerRow.Cells[0].Format.Alignment = ParagraphAlignment.Left;
                footerRow.Cells[1].AddParagraph($"Lembar: {currentPage} dari {pageCount}");
                footerRow.Cells[1].Format.Alignment = ParagraphAlignment.Right;
                footerRow.Cells[1].Borders.Width = 0;
            }

            // Render PDF
            var pdfRenderer = new PdfDocumentRenderer();
            pdfRenderer.Document = document;
            pdfRenderer.RenderDocument();

            using var stream = new MemoryStream();
            pdfRenderer.PdfDocument.Save(stream);
            // CleanFiles();
            return stream.ToArray();
        });
    }
    private void AddSupplierRow(Table table, string no, string supplier, string[] okbNumbers)
    {
        var row = table.AddRow();
        row.Format.Font.Size = 10;
        row.VerticalAlignment = VerticalAlignment.Center;
        row.Format.Alignment = ParagraphAlignment.Center;

        const double minimumRowHeightInCm = 1;
        if (okbNumbers.Length == 1)
        {
            row.Height = Unit.FromCentimeter(minimumRowHeightInCm);
        }

        row.Cells[0].AddParagraph(no);
        row.Cells[1].AddParagraph(supplier);

        var okbCell = row.Cells[3];
        if (okbCell.Column != null)
        {
            okbCell.Column.LeftPadding = 0;
            okbCell.Column.RightPadding = 0;
        }

        for (int i = 0; i < okbNumbers.Length; i++)
        {
            var paragraph = okbCell.AddParagraph(okbNumbers[i]);

            if (i < okbNumbers.Length - 1)
            {
                paragraph.Format.Borders.Bottom.Width = 0.5;
                paragraph.Format.Borders.Bottom.Style = BorderStyle.Single;
                paragraph.Format.SpaceAfter = 5; // Add some space after each line
                paragraph.Format.SpaceBefore = 5; // Add some space before each line
            }
        }

        okbCell.Borders.Width = 0.5;
    }

    private void AddBarcode(Cell section, string qrCodeText, BarcodeFormat format, double height = 2, double width = 6)
    {
        var barcodeWriter = new ZXing.ImageSharp.BarcodeWriter<Rgba32>
        {
            Format = format,
            Options = new EncodingOptions
            {
                Height = (int)(height * 100),
                Width = (int)(width * 100),
                Margin = 0
            }
        };

        var tempBarcodeFileName = Path.Combine(Path.GetTempPath(), "barcode" + new Guid().ToString() + ".png");
        using (Image<Rgba32> barcodeBitmap = barcodeWriter.Write(qrCodeText))
        {
            barcodeBitmap.Save(tempBarcodeFileName, new PngEncoder());

            var image = section.AddImage(tempBarcodeFileName);

            image.Width = Unit.FromCentimeter(width);
            image.Height = Unit.FromCentimeter(height);
            image.LockAspectRatio = true;
        }

        _filesToClean.Add(tempBarcodeFileName);
    }

    private void CleanFiles()
    {
        foreach (var file in _filesToClean)
        {
            try
            {
                File.Delete(file);
            }
            catch
            { }
        }
    }
}

