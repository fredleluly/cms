using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Application.Features.ComponentTracking.Picking;
using IDTrack.Application.Features.ComponentTracking.Picking.UseCases;
using IDTrack.Application.Features.PickingPreparation.Picking.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Picking;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using static IDTrack.Domain.Features.Picking.Entities.PickupOKB;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class PickupPointRepository : IPickupPointRepository
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly AppDbContext _dbContext;
    private readonly IAppConfigurationService _appConfigurationService;

    public PickupPointRepository(AppDbContext dbContext, IUnitOfWork unitOfWork, IAppConfigurationService appConfigurationService)
    {
        _dbContext = dbContext;
        _unitOfWork = unitOfWork;
        _appConfigurationService = appConfigurationService;
    }

    public void AttachPickupPoints(ICollection<PickupPoint> pickups)
    {
        _dbContext.AttachRange(pickups);
    }

    public async Task<Result<ICollection<PickupPoint>>> CreateOrUpdateRangeAsync(ICollection<PickupPoint> pickupPoints, CancellationToken cancellationToken)
    {
        await _dbContext.PickupPoints.AddRangeAsync(pickupPoints.Where(e => e.Id == 0));

        foreach (var pickupPoint in pickupPoints.Where(e => e.Id != 0))
        {
            _dbContext.PickupPoints.Update(pickupPoint);
        }

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);
        if (result.IsFailure)
        {
            return Result.Failure<ICollection<PickupPoint>>(result.Error);
        }

        return Result.Success(pickupPoints);
    }

    public async Task<Result<PickupPoint>> CreatePickupPointAsync(PickupPoint pickupPoint, CancellationToken cancellationToken)
    {
        await _dbContext.PickupPoints.AddAsync(pickupPoint);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickupPoint>(result.Error);
        }

        return Result.Success(pickupPoint);
    }

    public async Task<Result<ICollection<PickupPoint>>> CreateRangeAsync(ICollection<PickupPoint> pickupPoints, CancellationToken cancellationToken)
    {
        await _dbContext.PickupPoints.AddRangeAsync(pickupPoints);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<ICollection<PickupPoint>>(result.Error);
        }

        return Result.Success(pickupPoints);
    }

    public async Task<Result<PickupPoint>> DeletePickupPointAsync(long id, CancellationToken cancellationToken)
    {
        var entity = await _dbContext.PickupPoints.FindAsync(id);

        if (entity is null)
        {
            return Result.Failure<PickupPoint>(PickingDomainError.PickupPointNotFound);
        }

        _dbContext.PickupPoints.Remove(entity);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickupPoint>(result.Error);
        }

        return Result.Success(entity);
    }

    public Task<Result> DeletePickupPointRangeAsync(ICollection<long> ids, CancellationToken cancellationToken)
    {
        _dbContext.PickupPoints.RemoveRange(_dbContext.PickupPoints.Where(e => ids.Contains(e.Id)));

        return _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<Result<ICollection<PickupPoint>>> GetPickupByActiveOkbsAsync(ICollection<string> okbs, CancellationToken cancellationToken)
    {
        ICollection<PickupPoint> result = await _dbContext.PickupPoints.Where(e => e.OKBs.Any(o =>
            okbs.Contains(EF.Functions.Collate(o.OkbNo, "Latin1_General_CI_AS"))
            && ((o.Status == PickupOKBStatus.Unpicked))
        ))
            .AsNoTracking()
            .ToListAsync();

        return Result.Success(result);
    }

    public async Task<Result<ICollection<PickupPoint>>> GetLastPickupPointOfOkbsAsync(ICollection<string> okbs, CancellationToken cancellationToken)
    {
#pragma warning disable
        ICollection<PickupPoint> result = await _dbContext.PickupPoints
            .Where(e => e.OKBs
                .Any(o => okbs.Contains(EF.Functions.Collate(o.OkbNo, "Latin1_General_CI_AS"))))
            .GroupBy(e => e.OKBs
                .FirstOrDefault(o => okbs.Contains(EF.Functions.Collate(o.OkbNo, "Latin1_General_CI_AS"))).OkbNo)
            .Select(g => g.OrderByDescending(e => e.CreateTime).First())
            .ToListAsync();
#pragma warning restore

        return Result.Success(result);
    }

    public async Task<Result<PickupPoint>> GetPickupPointByIdAsync(long id, CancellationToken cancellationToken)
    {
        var result = await _dbContext.PickupPoints.FindAsync(id, cancellationToken);

        if (result is null)
        {
            return Result.Failure<PickupPoint>(PickingDomainError.PickupPointNotFound);
        }

        return Result.Success(result);
    }

    public async Task<Result<ICollection<PickupPoint>>> GetPickupPointsByPickNoAsync(string pickNo, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        ICollection<PickupPoint> pickupPoint = await _dbContext
            .PickupPoints
            .Join(
                _dbContext.CutoffedPickingInstructions(okbCutoff),
                pi => pi.PickingInstructionId,
                pp => pp.Id,
                (pp, pi) => new { PickupPoint = pp, PickingInstruction = pi })
            .Join(
                _dbContext.PartSuppliers,
                pp => pp.PickupPoint.VendorCode,
                ps => ps.VendorCode, (pp, ps) => new { pp.PickupPoint, PartSupplier = ps, pp.PickingInstruction })
            .Where(e => e.PickingInstruction.PickNo == pickNo)
            .Select(e => new PickupPoint
            {
                Id = e.PickupPoint.Id,
                PickingInstructionId = e.PickupPoint.PickingInstructionId,
                VendorCode = e.PartSupplier.VendorCode,
                VendorSite = e.PickupPoint.VendorSite,
                OKBs = e.PickupPoint.OKBs,
                Supplier = e.PartSupplier,
                Status = e.PickupPoint.Status,
                CreateBy = e.PickupPoint.CreateBy,
                CreateTime = e.PickupPoint.CreateTime,
                UpdateBy = e.PickupPoint.UpdateBy,
                UpdateTime = e.PickupPoint.UpdateTime,
            })
            .AsNoTracking()
            .ToListAsync();

        return Result.Success(pickupPoint);
    }

    public Task<PagingResult<PickupPoint>> LoadPageAsync(IQueryable<PickupPoint> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _dbContext, ct);
    }

    public async Task<Result<ICollection<PickupPoint>>> LoadQueryAsync(IQueryable<PickupPoint> query, CancellationToken cancellationToken)
    {
        ICollection<PickupPoint> result = await query.ToListAsync(cancellationToken);
        return Result.Success(result);
    }

    public Task<bool> PickupPointsHasActivityAsync(long pickId, CancellationToken ct)
    {
        return _dbContext.PickupPoints
            .Where(e => e.PickingInstructionId == pickId)
            .AnyAsync(e => (short)e.Status != PickupPoint.PickupPointStatus.Unpicked);
    }

    public IQueryable<PickupPoint> Query()
    {
        return _dbContext.PickupPoints;
    }

    public async Task<Result<PickupPoint>> UpdatePickupPointAsync(PickupPoint pickupPoint, CancellationToken cancellationToken)
    {
        _dbContext.PickupPoints.Update(pickupPoint);

        var result = await _unitOfWork.SaveChangesAsync(cancellationToken);

        if (result.IsFailure)
        {
            return Result.Failure<PickupPoint>(PickingDomainError.FailedToUpdatePickupPoint(result.Error.Description));
        }

        return Result.Success(pickupPoint);
    }

    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> query, PagingQuery page, CancellationToken ct) where T : class
    {
        return PagingService.LoadQueryAsync(query, page, _dbContext, ct);
    }

    public async Task<Result<ICollection<PickupPointPDFDto>>> GetPickupPointsByPickNoForPdfAsync(string pickNo, CancellationToken cancellationToken)
    {
        var okbCutoff = await _appConfigurationService.GetOkbCutoffDateAsync(cancellationToken);
        ICollection<PickupPointPDFDto> pickupPoint = await _dbContext
            .PickupPoints
            .Join(
                _dbContext.CutoffedPickingInstructions(okbCutoff),
                pi => pi.PickingInstructionId,
                pp => pp.Id,
                (pp, pi) => new { PickupPoint = pp, PickingInstruction = pi })
            .Join(
                _dbContext.PartSuppliers,
                pp => pp.PickupPoint.VendorSite,
                ps => ps.VendorCode, (pp, ps) => new { pp.PickupPoint, PartSupplier = ps, pp.PickingInstruction })
            .Where(e => e.PickingInstruction.PickNo == pickNo)
            .Select(e => new PickupPointPDFDto
            (
                e.PartSupplier.AliasName,
                e.PickupPoint.OKBs.Select(okb => new PickupOKBPDFDto
                (
                    okb.OkbNo
                ))
                .ToList()
            ))
            .AsNoTracking()
            .ToListAsync();

        return Result.Success(pickupPoint);
    }
}
