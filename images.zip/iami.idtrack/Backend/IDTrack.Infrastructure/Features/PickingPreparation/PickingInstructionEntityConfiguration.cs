using IDTrack.Domain.Features.Picking;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.PickingPreparation;

public class PickingInstructionbuilderConfiguration : IEntityTypeConfiguration<PickingInstruction>
{
    public void Configure(EntityTypeBuilder<PickingInstruction> builder)
    {
        builder.ToTable("TR_POS_PICK");
        builder.HasKey(e => e.Id).HasName("PK__TR_POS_P__3214EC2737FFEBDF");

        builder.HasIndex(e => e.PickNo, "UQ__TR_POS_P__AAD1C4B21C11E9A6").IsUnique();

        builder.Ignore(e => e.CreateByStr);
        builder.Ignore(e => e.UpdateByStr);

        builder.Property(e => e.Id).HasColumnName("ID");
        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
        builder.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");
        builder.Property(e => e.CycleNo).HasColumnName("DLV_CYCLE_NO");
        builder.Property(e => e.ArrivalDate)
            .HasColumnType("date")
            .HasColumnName("DLV_DATE");
        // builder.Property(e => e.DlvShift)
        //     .HasMaxLength(1)
        //     .IsUnicode(false)
        //     .IsFixedLength()
        //     .HasColumnName("DLV_SHIFT");
        builder.Property(e => e.ArrivalTime)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("DLV_TIME");
        // builder.Property(e => e.DockNo)
        //     .HasMaxLength(10)
        //     .IsUnicode(false)
        //     .HasColumnName("DOCK_NO");
        // builder.Property(e => e.ParkNo)
        //     .HasMaxLength(10)
        //     .IsUnicode(false)
        //     .HasColumnName("PARK_NO");
        builder.Property(e => e.PickDate)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("PICK_DATE");
        // builder.Property(e => e.PickDesc100)
        //     .HasMaxLength(100)
        //     .IsUnicode(false)
        //     .HasColumnName("PICK_DESC100");
        builder.Property(e => e.PickNo)
            .IsRequired()
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("PICK_NO");
        // builder.Property(e => e.PlantCode)
        //     .HasMaxLength(10)
        //     .IsUnicode(false)
        //     .HasColumnName("PLANT_CODE");
        // builder.Property(e => e.PrintBy).HasColumnName("PRINT_BY");
        // builder.Property(e => e.PrintDate)
        //     .HasColumnType("datetime")
        //     .HasColumnName("PRINT_DATE");
        // builder.Property(e => e.PrintStatus)
        //     .HasDefaultValue((short)0)
        //     .HasColumnName("PRINT_STATUS");
        builder.Property(e => e.RcvStatus)
            .HasDefaultValue((short)0)
            .HasColumnName("RCV_STATUS");
        builder.Property(e => e.RouteCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("ROUTE_CODE");
        builder.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");
        builder.Property(e => e.TransporterCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("TRANSPORTER_CODE");
        builder.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
        builder.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_DATE");
        builder
            .Property(e => e.GeofencingEnabled)
            .HasColumnName("GEOFENCING_ENABLED");
        builder
            .Property(e => e.Untracked)
            .HasColumnName("UNTRACKED")
            .HasDefaultValue(false);
        builder
            .Property(e => e.PickStatus)
            .HasColumnName("PICK_STATUS")
            .HasDefaultValue((short)0);
        builder
            .Property(e => e.DriverId)
            .IsRequired(false)
            .HasColumnName("DRIVER_ID");
        builder
            .Property(e => e.PickStartTime)
            .IsRequired(false)
            .HasColumnName("PICK_START_TIME");
        builder
            .Property(e => e.GateInTime)
            .IsRequired(false)
            .HasColumnName("GATE_IN_TIME");
        // builder.Property(e => e.WarehouseCode)
        //     .HasMaxLength(10)
        //     .IsUnicode(false)
        //     .HasColumnName("WAREHOUSE_CODE");
        builder.Property(e => e.StartByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("START_BY_DEVICE_ID");

        builder.Property(e => e.GateInByDeviceId)
            .HasMaxLength(36)
            .IsUnicode(false)
            .HasColumnName("GATE_IN_BY_DEVICE_ID");

        builder.Property(e => e.SapPoNo)
            .HasMaxLength(15)
            .IsUnicode(false)
            .IsRequired(false)
            .HasColumnName("SAP_PO_NO");
    }
}

