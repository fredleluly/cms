using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using IDTrack.Application.Features.Auth;
using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Models;
using Microsoft.AspNetCore.Http;

namespace IDTrack.Infrastructure.Features.Auth;

public class AuthenticationService : IAuthenticationService
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IIdentityService _identityService;

    public AuthenticationService(IHttpContextAccessor httpContextAccessor, IIdentityService identityService)
    {
        _httpContextAccessor = httpContextAccessor;
        _identityService = identityService;
    }

    public async Task<Result<User>> GetAuthenticatedUserAsync(CancellationToken cancellationToken = default)
    {
        var id = await GetAuthenticatedUserIdAsync(cancellationToken);

        if (id.IsFailure)
        {
            return Result.Failure<User>(id.Error);
        }

        var user = await _identityService.GetUserByIdAsync(id.Value);

        if (user is null)
        {
            return Result.Failure<User>(IdentityDomainError.UserNotFound(id.Value.ToString()));
        }

        return Result.Success(user);
    }

    public Task<Result<int>> GetAuthenticatedUserIdAsync(CancellationToken cancellationToken = default)
    {
        var user = _httpContextAccessor.HttpContext?.User;

        if (user is null)
        {
            return Task.FromResult(Result.Failure<int>(IdentityDomainError.UserIsNotAuthenticated));
        }

        if (int.TryParse(user.FindFirstValue(JwtRegisteredClaimNames.Sub), out var userId))
        {
            return Task.FromResult(Result.Success(userId));
        }

        return Task.FromResult(Result.Failure<int>(IdentityDomainError.UserIsNotAuthenticated));
    }

    public Task<Result<ICollection<Claim>>> GetAuthenticatedUserClaimsAsync(CancellationToken cancellationToken = default)
    {
        var user = _httpContextAccessor.HttpContext?.User;

        if (user is null)
        {
            return Task.FromResult(Result.Failure<ICollection<Claim>>(IdentityDomainError.UserIsNotAuthenticated));
        }

        var claims = user.Claims.ToList();

        return Task.FromResult(Result.Success<ICollection<Claim>>(claims));
    }
}

