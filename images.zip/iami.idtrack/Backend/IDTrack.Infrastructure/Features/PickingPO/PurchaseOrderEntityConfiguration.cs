using IDTrack.Domain.Features.PickingPO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.PickingPO
{
    public partial class PurchaseOrderEntityConfiguration : IEntityTypeConfiguration<PurchaseOrder>
    {
        public void Configure(EntityTypeBuilder<PurchaseOrder> entity)
        {
            entity.HasKey(e => e.Id).HasName("PK_TR_TRACK_PICK_PO");

            entity.ToTable("TR_TRACK_PICK_PO");

            entity.HasIndex(e => e.PoNo, "UQ_TR_TRACK_PICK_PO").IsUnique();

            entity.Property(e => e.Id).HasColumnName("ID");

            entity.Property(e => e.PoNo)
                .HasMaxLength(15)
                .IsUnicode(false)
                .HasColumnName("PO_NO");

            entity.Property(e => e.DocType)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("DOC_TYPE");

            entity.Property(e => e.PoDate)
                .HasColumnType("datetime")
                .HasColumnName("PO_DATE");

            entity.Property(e => e.VendorId)
                .HasColumnName("VENDOR_ID");

            entity.Property(e => e.VendorCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("VENDOR_CODE");

            entity.Property(e => e.PlantCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("PLANT_CODE");

            entity.Property(e => e.SapPlantCode)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("SAP_PLANT_CODE");

            entity.Property(e => e.PurchaseOrg)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("PURCH_ORG");

            entity.Property(e => e.PurchaseGroup)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("PURCH_GROUP");

            entity.Property(e => e.ValidStart)
                .HasColumnType("datetime")
                .HasColumnName("VALID_START");

            entity.Property(e => e.ValidEnd)
                .HasColumnType("datetime")
                .HasColumnName("VALID_END");

            entity.Property(e => e.Currency)
                .HasMaxLength(6)
                .IsUnicode(false)
                .HasColumnName("CURRENCY");

            entity.Property(e => e.CfcCode)
                .HasMaxLength(5)
                .IsUnicode(false)
                .HasColumnName("CFC_CODE");

            entity.Property(e => e.PoStatus)
                .HasColumnName("PO_STATUS");

            entity.Property(e => e.Status)
                .HasColumnName("STATUS");

            entity.Property(e => e.CreateTime)
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("CREATE_TIME");

            entity.Property(e => e.CreateBy)
                .HasColumnName("CREATE_BY");

            entity.Property(e => e.UpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_TIME");

            entity.Property(e => e.UpdateBy)
                .HasColumnName("UPDATE_BY");

            entity.Ignore(e => e.CreateByStr);
            entity.Ignore(e => e.UpdateByStr);

            entity.OwnsMany(e => e.Details, db => {
                db.ToTable("TR_TRACK_PICK_PO_DTL");

                db.HasKey(e => e.Id).HasName("PK_TR_TRACK_PICK_PO_DTL");

                db.WithOwner().HasForeignKey("TRACK_PICK_PO_ID");

                db.HasIndex(e => e.PoNo).HasDatabaseName("UQ_TR_TRACK_SAP_PICK_PO_DTL").IsUnique();

                db.Ignore(e => e.CreateByStr);
                db.Ignore(e => e.UpdateByStr);

                db.Property(e => e.Id).HasColumnName("ID");

                db.Property(e => e.PoNo)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("PO_NO");

                db.Property(e => e.ItemNo).HasColumnName("ITEM_NO");

                db.Property(e => e.PlantCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("PLANT_CODE");

                db.Property(e => e.SapPlantCode)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("SAP_PLANT_CODE");

                db.Property(e => e.MaterialId).HasColumnName("MATERIAL_ID");

                db.Property(e => e.SlocCode)
                    .HasColumnName("SLOC_CODE")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                db.Property(e => e.MaterialNo)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("MATERIAL_NO");

                db.Property(e => e.QtyPo).HasColumnName("QTY_PO");

                db.Property(e => e.ScVendor)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("SC_VENDOR");

                db.Property(e => e.SuppVendor)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("SUPP_VENDOR");

                db.Property(e => e.VendorName)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("VENDOR_NAME");

                db.Property(e => e.DeleteInd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("DELETE_IND");

                db.Property(e => e.PoDtlStatus).HasColumnName("PO_DTL_STATUS");

                db.Property(e => e.Status)
                    .HasDefaultValue((short)0)
                    .HasColumnName("STATUS");

                db.Property(e => e.CreateTime)
                    .HasDefaultValueSql("(getdate())")
                    .HasColumnType("datetime")
                    .HasColumnName("CREATE_TIME");

                db.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

                db.Property(e => e.UpdateTime)
                    .HasColumnType("datetime")
                    .HasColumnName("UPDATE_TIME");

                db.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
            });
        }
    }
}
