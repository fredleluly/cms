using IDTrack.Application.Features.PickingPO;

namespace IDTrack.Infrastructure.Features.PickingPO;

public class PickingPODomainService : IPickingPODomainService
{

}
