using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.PickingPO;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Features.PickingPO.Entities;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;

namespace IDTrack.Infrastructure.Features.InterfaceSAPRepository;

public class InterfaceSAPRepository : IInterfaceSAPRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public InterfaceSAPRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public Task<Result<InterfaceSAP>> GetByIdAsync(long id, CancellationToken ct)
    {
        throw new NotImplementedException();
    }

    public Task<Result<ICollection<InterfaceSAPRequest>>> GetInterfaceDetailAsync(long id, CancellationToken ct)
    {
        throw new NotImplementedException();
    }

    public Task<PagingResult<InterfaceSAP>> LoadPageAsync(IQueryable<InterfaceSAP> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<InterfaceSAP> Query()
    {
        return _context.InterfaceSAPs;
    }
}
