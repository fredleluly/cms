using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.PickingPO;
using IDTrack.Application.Features.PickingPO.UseCase;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.PickingPO;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.PickingPO;

public class PickingPORepository : IPickingPORepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public PickingPORepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<PurchaseOrder>> AddAsync(PurchaseOrder purchaseOrder, CancellationToken ct)
    {
        await _context.PickingPOs.AddAsync(purchaseOrder, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PurchaseOrder>(result.Error);

        return Result.Success(purchaseOrder);
    }

    public async Task<Result<PurchaseOrder>> DeleteAsync(long id, CancellationToken ct)
    {
        var purchaseOrder = await _context.PickingPOs.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (purchaseOrder is null)
            return Result.Failure<PurchaseOrder>(PurchaseOrderDomainError.PickingPONotFound(id.ToString()));

        _context.PickingPOs.Remove(purchaseOrder);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PurchaseOrder>(result.Error);

        return Result.Success(purchaseOrder);
    }

    public Task<Result<GetPickingPODetailUseCaseResult>> GetByIdAsync(long id, CancellationToken ct)
    {
        throw new NotImplementedException();
    }

    public Task<PagingResult<PurchaseOrder>> LoadPageAsync(IQueryable<PurchaseOrder> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PurchaseOrder> Query()
    {
        return _context.PickingPOs;
    }

    public async Task<Result<PurchaseOrder>> UpdateAsync(PurchaseOrder purchaseOrder, CancellationToken ct)
    {
        _context.Update(purchaseOrder);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PurchaseOrder>(result.Error);

        return Result.Success(purchaseOrder);
    }
}