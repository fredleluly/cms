using IDTrack.Domain.Features.Masters.GateIn;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.GateIn;

public class PickingGateInEntityConfiguration : IEntityTypeConfiguration<PickingGateIn>
{
    public void Configure(EntityTypeBuilder<PickingGateIn> entity)
    {
        entity.HasKey(e => e.Id).HasName("PK_MS_TRACK_GATE_IN");

        entity.ToTable("MS_TRACK_GATE_IN");

        entity.HasIndex(e => e.Token, "UQ_MS_TRACK_GATE_IN").IsUnique();

        entity.Ignore(e => e.CreateByStr);
        entity.Ignore(e => e.UpdateByStr);

        entity.Property(e => e.Id).HasColumnName("ID");

        entity.Property(e => e.Token)
            .IsRequired()
            .HasMaxLength(36)
            .HasColumnName("TOKEN");

        entity.Property(e => e.Name)
            .IsRequired()
            .HasMaxLength(30)
            .HasColumnName("NAME");

        entity.Property(e => e.Lat)
            .HasMaxLength(120)
            .HasColumnName("LAT");

        entity.Property(e => e.Lng)
            .HasMaxLength(120)
            .HasColumnName("LNG");

        entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        entity.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");

        entity.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        entity.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        entity.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_DATE");
    }
}
