using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.GateIn;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.GateIn;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.GateIn;

public class PickingGateInRepository : IPickingGateInRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public PickingGateInRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<PickingGateIn>> AddAsync(PickingGateIn gateIn, CancellationToken ct)
    {
        await _context.PickingGateIns.AddAsync(gateIn, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingGateIn>(result.Error);

        return Result.Success(gateIn);
    }

    public async Task<Result<PickingGateIn>> GetByIdAsync(long id, CancellationToken ct)
    {
        var gateIn = await _context.PickingGateIns.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (gateIn is null)
            return Result.Failure<PickingGateIn>(PickingGateInDomainError.PickingGateInNotFound(id));

        return Result.Success(gateIn);
    }

    public async Task<Result<PickingGateIn>> UpdateAsync(PickingGateIn gateIn, CancellationToken ct)
    {
        _context.Update(gateIn);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingGateIn>(result.Error);

        return Result.Success(gateIn);
    }

    public async Task<Result<PickingGateIn>> DeleteAsync(long id, CancellationToken ct)
    {
        var gateIn = await _context.PickingGateIns.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (gateIn is null)
            return Result.Failure<PickingGateIn>(PickingGateInDomainError.PickingGateInNotFound(id));

        _context.PickingGateIns.Remove(gateIn);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingGateIn>(result.Error);

        return Result.Success(gateIn);
    }

    public Task<PagingResult<PickingGateIn>> LoadPageAsync(IQueryable<PickingGateIn> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PickingGateIn> Query()
    {
        return _context.PickingGateIns;
    }

    public async Task<Result<PickingGateIn>> GetByTokenAsync(string token, CancellationToken ct)
    {
        var result = await _context.PickingGateIns.FirstOrDefaultAsync(e => e.Token == token, ct);

        if (result is null)
            return Result.Failure<PickingGateIn>(PickingGateInDomainError.InvalidGateInToken);

        return Result.Success(result);
    }

    public async Task<Result<bool>> ExistsByNameAsync(string name, CancellationToken ct)
    {
        var exists = await _context.PickingGateIns.AnyAsync(g => g.Name == name, ct);
        return Result.Success(exists);
    }
}
