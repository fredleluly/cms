using IDTrack.Domain.Features.Masters.Route;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.Route;

public class PickingRouteEntityConfiguration : IEntityTypeConfiguration<PickingRoute>
{
    public void Configure(EntityTypeBuilder<PickingRoute> entity)
    {
        entity.HasKey(e => e.Id).HasName("PK__MS_POS_R__3214EC27F88276DC");

        entity.ToTable("MS_POS_ROUTE");

        entity.HasIndex(e => e.RouteCode, "UQ__MS_POS_R__2730D5C2852E462B").IsUnique();

        entity.Ignore(e => e.CreateByStr);
        entity.Ignore(e => e.UpdateByStr);

        entity.Property(e => e.Id).HasColumnName("ID");
        entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
        entity.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");
        entity.Property(e => e.RouteCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("ROUTE_CODE");
        entity.Property(e => e.RouteDesc100)
            .HasMaxLength(100)
            .IsUnicode(false)
            .HasColumnName("ROUTE_DESC100");
        entity.Property(e => e.RouteName)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("ROUTE_NAME");
        entity.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");
        entity.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
        entity.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_DATE");
    }
}
