using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.Route;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Features.Identity.Data;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.Route;

public class PickingRouteRepository : IPickingRouteRepository
{
    private readonly AppDbContext _context;
    private readonly IdentityContext _identityContext;
    private readonly IUnitOfWork _uow;

    public PickingRouteRepository(AppDbContext context, IUnitOfWork uow, IdentityContext identityContext)
    {
        _context = context;
        _uow = uow;
        _identityContext = identityContext;
    }

    public async Task<Result<PickingRoute>> AddAsync(PickingRoute route, CancellationToken ct)
    {
        await _context.PickingRoutes.AddAsync(route, ct);
        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingRoute>(result.Error);

        return Result.Success(route);
    }

    public async Task<Result<PickingRoute>> GetByIdAsync(long id, CancellationToken ct)
    {
        var route = await _context.PickingRoutes.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (route is null)
            return Result.Failure<PickingRoute>(PickingRouteDomainError.PickingRouteNotFound(id));

        return Result.Success(route);
    }

    public async Task<Result<PickingRoute>> UpdateAsync(PickingRoute route, CancellationToken ct)
    {
        _context.Update(route);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingRoute>(result.Error);

        return Result.Success(route);
    }

    public async Task<Result<PickingRoute>> DeleteAsync(long id, CancellationToken ct)
    {
        var route = await _context.PickingRoutes.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (route is null)
            return Result.Failure<PickingRoute>(PickingRouteDomainError.PickingRouteNotFound(id));

        _context.PickingRoutes.Remove(route);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingRoute>(result.Error);

        return Result.Success(route);
    }

    public Task<PagingResult<PickingRoute>> LoadPageAsync(IQueryable<PickingRoute> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PickingRoute> Query()
    {
        return _context.PickingRoutes;
    }

    public async Task<Result<PickingRoute>> GetByRouteCodeAsync(string routeCode, CancellationToken ct)
    {
        var route = await _context.PickingRoutes.FirstOrDefaultAsync(e => e.RouteCode == routeCode, ct);

        if (route is null)
            return Result.Failure<PickingRoute>(PickingRouteDomainError.PickingRouteNotFound(routeCode));

        return Result.Success(route);
    }

    public async Task<BulkResult> CheckRouteNameExistenceAsync(IEnumerable<string> routeCodes, int startRow, CancellationToken ct)
    {
        var errors = new List<Error>();
        var existingRoute = new List<string>();
        var nonExistingRoute = new List<string>();

        var index = 0;
        foreach (var route in routeCodes)
        {
            if (existingRoute.Contains(route))
                continue;
            
            if (nonExistingRoute.Contains(route))
            {
                errors.Add(PickingRouteDomainError.PickingRouteNotFound(route, $"{startRow + index}"));
                continue;
            }

            var routeExist = await _context.PickingRoutes.AnyAsync(e => e.RouteCode == route);

            if (routeExist)
                existingRoute.Add(route);
            else
            {
				errors.Add(PickingRouteDomainError.PickingRouteNotFound(route, $"{startRow + index}"));
                nonExistingRoute.Add(route);
            }

            index++;
        }

        if (errors.Any())
        {
            var result = BulkResult.Failure(PickingRouteDomainError.SomeRoutesDoesNotExists);
            result.SetErrors(errors);
            return result;
        }

        return BulkResult.Success();
    }
}
