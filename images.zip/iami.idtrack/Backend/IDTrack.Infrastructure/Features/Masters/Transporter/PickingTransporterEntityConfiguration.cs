using IDTrack.Domain.Features.Masters.Transporter;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.Transporter;

public class PickingTransporterEntityConfiguration : IEntityTypeConfiguration<PickingTransporter>
{
    public void Configure(EntityTypeBuilder<PickingTransporter> entity)
    {
        entity.HasKey(e => e.Id).HasName("PK__MS_TRANS__3214EC2740257DE4");

        entity.ToTable("MS_TRANSPORTER");

        entity.HasIndex(e => e.TransporterCode, "UQ__MS_TRANS__8D94EF09CB42F278").IsUnique();

        entity.Ignore(e => e.CreateByStr);
        entity.Ignore(e => e.UpdateByStr);

        entity.Property(e => e.Id).HasColumnName("ID");

        entity.Property(e => e.TransporterCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("TRANSPORTER_CODE");

        entity.Property(e => e.TransporterName)
            .IsRequired()
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("TRANSPORTER_NAME");

        entity.Property(e => e.TransporterDesc100)
            .HasMaxLength(100)
            .IsUnicode(false)
            .HasColumnName("TRANSPORTER_DESC100");

        entity.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        entity.Property(e => e.CreateTime)
            .HasColumnType("datetime")
            .HasDefaultValueSql("(getdate())")
            .HasColumnName("CREATE_TIME");

        entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        entity.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_TIME");

        entity.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        entity.Property(e => e.Address)
            .HasMaxLength(150)
            .IsUnicode(false)
            .HasColumnName("ADDRESS");

        entity.Property(e => e.City)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("CITY");

        entity.Property(e => e.PostalCode)
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("POSTAL_CODE");

        entity.Property(e => e.RegionCode)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("REGION_CODE");

        entity.Property(e => e.CountryCode)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("COUNTRY_CODE");

        entity.Property(e => e.ContactName)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("CONTACT_NAME");

        entity.Property(e => e.PhoneNo1)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("PHONE_NO1");

        entity.Property(e => e.PhoneNo2)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("PHONE_NO2");

        entity.Property(e => e.FaxNo1)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("FAX_NO1");

        entity.Property(e => e.FaxNo2)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("FAX_NO2");

        entity.Property(e => e.Email)
            .HasMaxLength(500)
            .IsUnicode(false)
            .HasColumnName("EMAIL");

        entity.Property(e => e.TaxCode)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("TAX_CODE");

        entity.Property(e => e.VendorDesc100)
            .HasMaxLength(100)
            .IsUnicode(false)
            .HasColumnName("VENDOR_DESC100");

        entity.Property(e => e.VendorType)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("VENDOR_TYPE");
    }
}
