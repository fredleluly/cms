using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.Transporter;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.Transporter;

public class PickingTransporterRepository : IPickingTransporterRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public PickingTransporterRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<PickingTransporter>> AddAsync(PickingTransporter transporter, CancellationToken ct)
    {
        await _context.PickingTransporters.AddAsync(transporter, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingTransporter>(result.Error);

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporter>> GetByIdAsync(long id, CancellationToken ct)
    {
        var transporter = await _context.PickingTransporters.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (transporter is null)
            return Result.Failure<PickingTransporter>(PickingTransporterDomainError.PickingTransporterNotFound(id.ToString()));

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporter>> UpdateAsync(PickingTransporter transporter, CancellationToken ct)
    {
        _context.Update(transporter);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingTransporter>(result.Error);

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporter>> DeleteAsync(long id, CancellationToken ct)
    {
        var transporter = await _context.PickingTransporters.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (transporter is null)
            return Result.Failure<PickingTransporter>(PickingTransporterDomainError.PickingTransporterNotFound(id.ToString()));

        _context.PickingTransporters.Remove(transporter);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingTransporter>(result.Error);

        return Result.Success(transporter);
    }

    public Task<PagingResult<PickingTransporter>> LoadPageAsync(IQueryable<PickingTransporter> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PickingTransporter> Query()
    {
        return _context.PickingTransporters;
    }

    public async Task<Result<PickingTransporter>> GetByTransporterCodeAsync(string transporterCode, CancellationToken ct)
    {
        var transporter = await _context.PickingTransporters.FirstOrDefaultAsync(e => e.TransporterCode == transporterCode, ct);

        if (transporter is null)
            return Result.Failure<PickingTransporter>(PickingTransporterDomainError.PickingTransporterNotFound(transporterCode));

        return Result.Success(transporter);
    }
}
