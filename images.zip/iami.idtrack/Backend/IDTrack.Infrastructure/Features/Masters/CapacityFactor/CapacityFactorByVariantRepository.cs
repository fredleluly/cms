using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.CapacityFactor;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByVariantRepository : ICapacityFactorByVariantRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public CapacityFactorByVariantRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<CapacityFactorByVariant>> AddAsync(CapacityFactorByVariant capacityFactor, CancellationToken ct)
    {
        await _context.CapacityFactorByVariants.AddAsync(capacityFactor);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByVariant>(result.Error);

        return Result.Success(capacityFactor);
    }

    public async Task<Result<CapacityFactorByVariant>> DeleteAsync(long id, CancellationToken ct)
    {
        var capacityFactor = await _context.CapacityFactorByVariants.FindAsync(id);
        if (capacityFactor is null)
            return Result.Failure<CapacityFactorByVariant>(CapacityFactorByVariantDomainError.CapacityFactorByVariantNotFound(id));

        _context.CapacityFactorByVariants.Remove(capacityFactor);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByVariant>(result.Error);

        return Result.Success(capacityFactor);
    }

    public async Task<Result<CapacityFactorByVariant>> GetByIdAsync(long id, CancellationToken ct)
    {
        var capacityFactor = await _context.CapacityFactorByVariants.FindAsync(id);
        if (capacityFactor is null)
            return Result.Failure<CapacityFactorByVariant>(CapacityFactorByVariantDomainError.CapacityFactorByVariantNotFound(id));

        return Result.Success(capacityFactor);
    }

    public async Task<BulkResult> MergeBulkAsync(IEnumerable<CapacityFactorByVariant> capacityFactors, CancellationToken ct)
    {
        var existingFactors = await _context.CapacityFactorByVariants.ToListAsync(ct);
        var newFactors = capacityFactors.Where(f => !existingFactors.Any(ef => ef.RouteCode == f.RouteCode && ef.Katashiki == f.Katashiki && ef.Suffix == f.Suffix)).ToList();

        _context.CapacityFactorByVariants.AddRange(newFactors);

        // update existing factors
        foreach (var factor in capacityFactors)
        {
            var existingFactor = existingFactors.FirstOrDefault(ef => ef.RouteCode == factor.RouteCode && ef.Katashiki == factor.Katashiki && ef.Suffix == factor.Suffix);
            if (existingFactor is not null)
            {
                existingFactor.CapacityFactorInPercentage = factor.CapacityFactorInPercentage;
                _context.CapacityFactorByVariants.Update(existingFactor);
            }
        }

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return BulkResult.Failure<CapacityFactorByVariant>(result.Error);

        return BulkResult.Success();
    }

    public Task<PagingResult<CapacityFactorByVariant>> LoadPageAsync(IQueryable<CapacityFactorByVariant> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<CapacityFactorByVariant> Query()
    {
        return _context.CapacityFactorByVariants;
    }

    public async Task<Result<CapacityFactorByVariant>> UpdateAsync(CapacityFactorByVariant capacityFactor, CancellationToken ct)
    {
        _context.CapacityFactorByVariants.Update(capacityFactor);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByVariant>(result.Error);

        return Result.Success(capacityFactor);
    }

    public async Task<HashSet<Tuple<string, string>>> GetAllMtVariantKeysAsync(CancellationToken ct)
    {
        var queryResult = await _context.MtVariants.ToListAsync();

        return queryResult
            .Select(e => new Tuple<string, string>(e.Katashiki, e.Suffix))
            .ToHashSet();
    }
}

