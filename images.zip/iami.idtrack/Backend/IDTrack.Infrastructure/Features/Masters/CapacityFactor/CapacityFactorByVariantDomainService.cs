using ClosedXML.Excel;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Document;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByVariantDomainService : ICapacityFactorByVariantDomainService
{
    private readonly AppDbContext _dbContext;

    public CapacityFactorByVariantDomainService(AppDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<BulkResult<ICollection<CapacityFactorByVariant>>> ReadCapacityFactorsFromExcelAsync(
        Stream file, 
        CancellationToken cancellationToken)
    {
        return ReadCapacityFactorsFromExcelAsync(file, null, cancellationToken);
    }

    public Task<BulkResult<ICollection<CapacityFactorByVariant>>> ReadCapacityFactorsFromExcelAsync(Stream file, Func<CapacityFactorByVariant, ICollection<Error>>? validate, CancellationToken cancellationToken)
    {
        if (!IsExcelFile(file))
        {
            return Task.FromResult(BulkResult.Failure<ICollection<CapacityFactorByVariant>>(CapacityFactorByVariantDomainError.FileIsNotExcel));
        }

        using var workbook = new XLWorkbook(file);
        var worksheet = workbook.Worksheet(1);

        ICollection<CapacityFactorByVariant> capacityFactors = new List<CapacityFactorByVariant>();
        var errors = new List<Error>();

        for (int row = 3; row <= worksheet.LastRowUsed().RowNumber(); row++)
        {
            var routeCode = worksheet.Cell(row, 2).Value.ToString();

            for (int col = 3; col <= worksheet.LastColumnUsed().ColumnNumber(); col++)
            {
                if (string.IsNullOrWhiteSpace(worksheet.Cell(row, col).Value.ToString()))
                    continue;

                if (!decimal.TryParse(worksheet.Cell(row, col).Value.ToString(), out decimal factor))
                {
                    errors.Add(CapacityFactorByVariantDomainError.ValueIsNoDecimal(
                        worksheet.Cell(row, col).Address.ToString()!));
                    continue;
                }

                var capacityFactor = new CapacityFactorByVariant
                {
                    RouteCode = routeCode,
                    Katashiki = worksheet.Cell(1, col).Value.ToString(),
                    Suffix = worksheet.Cell(2, col).Value.ToString(),
                    CapacityFactorInPercentage = factor
                };

                ICollection<Error> validationResult = new List<Error>();

                if (validate != null)
                    validationResult = validate(capacityFactor);

                if (validationResult.Count > 0)
                {
                    foreach (var error in validationResult)
                    {
                        errors.Add(CapacityFactorByVariantDomainError.InvalidCapacityFactor(
                            worksheet.Cell(row, col).Address.ToString()!, error));
                    }
                    continue;
                }

                capacityFactors.Add(capacityFactor);
            }
        }

        if (errors.Any())
        {
            var result = BulkResult.Failure<ICollection<CapacityFactorByVariant>>(CapacityFactorByVariantDomainError.FailedToUploadCapacityFactorByVariant("One or more validation error occurred"));
            result.SetErrors(errors);

            return Task.FromResult(result);
        }

        return Task.FromResult(BulkResult.Success(capacityFactors));
    }

    public bool IsExcelFile(Stream fileStream)
    {
        // File signatures for .xls and .xlsx
        byte[] xlsHeader = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
        byte[] xlsxHeader = { 0x50, 0x4B, 0x03, 0x04 };

        byte[] fileHeader = new byte[8];
        fileStream.Read(fileHeader, 0, fileHeader.Length);

        // Reset the position of the stream to the beginning
        fileStream.Position = 0;

        // Check if the file header matches either .xls or .xlsx
        var isExcelSignature = fileHeader.Take(xlsHeader.Length).SequenceEqual(xlsHeader) || 
               fileHeader.Take(xlsxHeader.Length).SequenceEqual(xlsxHeader);

        if (!isExcelSignature)
            return false;

        try 
        {
            using var workbook = new XLWorkbook(fileStream);
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public async Task<Stream> DownloadTruckCapacityFactorTemplateAsync(CancellationToken cancellationToken)
    {
		string binDirectory = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)!;
		var filePath = Path.Combine(binDirectory, DocumentConstants.TemplateFolder, DocumentConstants.TruckCapacityFactorTemplate);
        if (!File.Exists(filePath))
        {
            throw new ErrorException(CapacityFactorByVariantDomainError.FailedToDownloadTemplate("Template file not found"));
        }

        using var file = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        var stream = new MemoryStream();

        await file.CopyToAsync(stream, cancellationToken);

        stream.Position = 0;
        using var workbook = new XLWorkbook(stream);
        var worksheet = workbook.Worksheet(1);

        var row = 3;
        foreach (var route in await _dbContext.PickingRoutes.Select(e => e.RouteCode).ToListAsync())
        {
            worksheet.Cell(row++, 2).Value = route;
        }

        var col = 3;
        foreach (var variant in await _dbContext.MtVariants.Select(e => new { e.Katashiki, e.Suffix }).ToListAsync())
        {
            worksheet.Cell(1, col).Value = variant.Katashiki;
            worksheet.Cell(2, col++).Value = variant.Suffix;
        }

        workbook.Save();

        return stream;
    }
}

