using IDTrack.Domain.Features.Masters.CapacityFactor;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByPartEntityConfiguration : IEntityTypeConfiguration<CapacityFactorByPart>
{
    public void Configure(EntityTypeBuilder<CapacityFactorByPart> builder)
    {
        builder.ToTable("MS_TRACK_CPCTY_FCTR_PART");

        builder.HasKey(e => e.Id);

        builder.Ignore(e => e.CreateByStr);
        builder.Ignore(e => e.UpdateByStr);

        builder.Property(e => e.Id)
            .HasColumnName("ID")
            .ValueGeneratedOnAdd();

        builder.Property(e => e.RouteCode)
            .HasColumnName("ROUTE_CODE")
            .HasMaxLength(10)
            .IsRequired();

        builder.Property(e => e.PartNo)
            .HasColumnName("MATERIAL_NO")
            .HasMaxLength(50)
            .IsRequired();

        builder.Property(e => e.CapacityFactor)
            .HasColumnName("CAPACITY_FACTOR")
            .HasColumnType("decimal")
            .IsRequired();

        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        builder.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");

        builder.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        builder.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        builder.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_DATE");
    }
}
