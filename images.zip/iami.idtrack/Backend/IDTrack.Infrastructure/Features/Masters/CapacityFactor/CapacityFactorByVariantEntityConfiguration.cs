using IDTrack.Domain.Features.Masters.CapacityFactor;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByVariantEntityConfiguration : IEntityTypeConfiguration<CapacityFactorByVariant>
{
    public void Configure(EntityTypeBuilder<CapacityFactorByVariant> builder)
    {
        builder.ToTable("MS_TRACK_CPCTY_FCTR_VARIANT");

        builder.HasKey(e => e.Id);

        builder
            .HasIndex(e => new { e.Katashiki, e.Suffix, e.RouteCode })
            .IsUnique();

        builder.Ignore(e => e.PickingRoute);
        builder.Ignore(e => e.CreateByStr);
        builder.Ignore(e => e.UpdateByStr);

        builder.Property(e => e.Id)
            .HasColumnName("ID")
            .ValueGeneratedOnAdd();

        builder.Property(e => e.Suffix)
            .HasColumnName("SUFFIX")
            .HasMaxLength(2)
            .IsRequired();

        builder.Property(e => e.Katashiki)
            .HasColumnName("KATASHIKI")
            .HasMaxLength(20)
            .IsRequired();

        builder.Property(e => e.RouteCode)
            .HasColumnName("ROUTE_CODE")
            .HasMaxLength(10)
            .IsRequired();

        builder.Property(e => e.CapacityFactorInPercentage)
            .HasColumnName("CAPACITY_FACTOR")
            .HasColumnType("decimal")
            .IsRequired();

        builder.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        builder.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");

        builder.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        builder.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        builder.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_DATE");
    }
}

