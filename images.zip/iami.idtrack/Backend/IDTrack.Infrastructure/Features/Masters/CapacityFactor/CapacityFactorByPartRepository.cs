using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByPartRepository : ICapacityFactorByPartRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public CapacityFactorByPartRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<CapacityFactorByPart>> AddAsync(CapacityFactorByPart routePartCapacity, CancellationToken ct)
    {
        await _context.RoutePartCapacities.AddAsync(routePartCapacity);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByPart>(result.Error);

        return Result.Success(routePartCapacity);
    }

    public async Task<Result<CapacityFactorByPart>> DeleteAsync(long id, CancellationToken ct)
    {
        var routeCapacity = await _context.RoutePartCapacities.FindAsync(id);
        if (routeCapacity is null)
            return Result.Failure<CapacityFactorByPart>(CapacityFactorByPartDomainError.CapacityFactorByPartNotFound(id));

        _context.RoutePartCapacities.Remove(routeCapacity);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByPart>(result.Error);

        return Result.Success(routeCapacity);
    }

    public async Task<Result<CapacityFactorByPart>> GetByIdAsync(long id, CancellationToken ct)
    {
        var routeCapacity = await _context.RoutePartCapacities.FindAsync(id);
        if (routeCapacity is null)
            return Result.Failure<CapacityFactorByPart>(CapacityFactorByPartDomainError.CapacityFactorByPartNotFound(id));

        return Result.Success(routeCapacity);
    }

    public Task<PagingResult<CapacityFactorByPart>> LoadPageAsync(IQueryable<CapacityFactorByPart> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public async Task<BulkResult> MergeBulkAsync(IEnumerable<CapacityFactorByPart> routePartCapacities, CancellationToken ct)
    {
        var existingFactors = await _context.RoutePartCapacities.ToListAsync(ct);
        var newFactors = routePartCapacities.Where(f => !existingFactors.Any(ef => ef.RouteCode == f.RouteCode && ef.PartNo == f.PartNo)).ToList();

        _context.RoutePartCapacities.AddRange(newFactors);

        // update existing factors
        foreach (var factor in routePartCapacities)
        {
            var existingFactor = existingFactors.FirstOrDefault(ef => ef.RouteCode == factor.RouteCode && ef.PartNo == factor.PartNo);
            if (existingFactor is not null)
            {
                existingFactor.CapacityFactor = factor.CapacityFactor;
                _context.RoutePartCapacities.Update(existingFactor);
            }
        }

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return BulkResult.Failure<CapacityFactorByPart>(result.Error);

        return BulkResult.Success();
    }

    public IQueryable<CapacityFactorByPart> Query()
    {
        return _context.RoutePartCapacities;
    }

    public async Task<Result<CapacityFactorByPart>> UpdateAsync(CapacityFactorByPart routePartCapacity, CancellationToken ct)
    {
        _context.RoutePartCapacities.Update(routePartCapacity);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<CapacityFactorByPart>(result.Error);

        return Result.Success(routePartCapacity);
    }
}