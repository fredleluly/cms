using ClosedXML.Excel;
using IDTrack.Application.Features.Masters.CapacityFactor;
using IDTrack.Domain.Features.Masters.CapacityFactor;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Document;
using IDTrack.Infrastructure.Persistence.Data;

namespace IDTrack.Infrastructure.Features.Masters.CapacityFactor;

public class CapacityFactorByPartDomainService : ICapacityFactorByPartDomainService
{
    private readonly AppDbContext _dbContext;

    public CapacityFactorByPartDomainService(AppDbContext dbContext)
    {
        _dbContext = dbContext;
    }
    public Task<BulkResult<ICollection<CapacityFactorByPart>>> ReadRouteCapacityFromExcelAsync(Stream file, CancellationToken cancellationToken)
    {
        return ReadRouteCapacityFromExcelAsync(file, null, cancellationToken);
    }

    public async Task<BulkResult<ICollection<CapacityFactorByPart>>> ReadRouteCapacityFromExcelAsync(Stream file, Func<CapacityFactorByPart, ICollection<Error>>? validate, CancellationToken cancellationToken)
    {
        if (!IsExcelFile(file))
        {
            return BulkResult.Failure<ICollection<CapacityFactorByPart>>(CapacityFactorByPartDomainError.FileIsNotExcel);
        }

        using var workbook = new XLWorkbook(file);
        var worksheet = workbook.Worksheet(1);

        ICollection<CapacityFactorByPart> capacityFactors = new List<CapacityFactorByPart>();
        var errors = new List<Error>();

        for (int row = 3; row <= worksheet.LastRowUsed().RowNumber(); row++)
        {
            var routeCode = worksheet.Cell(row, 2).Value.ToString();

            for (int col = 3; col <= worksheet.LastColumnUsed().ColumnNumber(); col++)
            {
                var partNo = worksheet.Cell(row, col).Value.ToString();
                if (string.IsNullOrWhiteSpace(worksheet.Cell(row, col).Value.ToString()))
                    continue;

                if (!decimal.TryParse(worksheet.Cell(row, col).Value.ToString(), out decimal factor))
                {
                    errors.Add(CapacityFactorByVariantDomainError.ValueIsNoDecimal(
                        worksheet.Cell(row, col).Address.ToString()!));
                    continue;
                }

                var capacityFactor = new CapacityFactorByPart
                {
                    RouteCode = routeCode,
                    PartNo = partNo,
                    CapacityFactor = factor
                };

                ICollection<Error> validationResult = new List<Error>();

                if (validate != null)
                    validationResult = validate(capacityFactor);

                if (validationResult.Count > 0)
                {
                    foreach (var error in validationResult)
                    {
                        errors.Add(CapacityFactorByPartDomainError.InvalidCapacityFactor(
                            worksheet.Cell(row, col).Address.ToString()!, error));
                    }
                    continue;
                }

                capacityFactors.Add(capacityFactor);
            }
        }

        if (errors.Any())
        {
            var result = BulkResult.Failure<ICollection<CapacityFactorByPart>>(CapacityFactorByVariantDomainError.FailedToUploadCapacityFactorByVariant("One or more validation error occurred"));
            result.SetErrors(errors);

            return result;
        }

        return BulkResult.Success(capacityFactors);
    }

    public bool IsExcelFile(Stream fileStream)
    {
        // File signatures for .xls and .xlsx
        byte[] xlsHeader = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
        byte[] xlsxHeader = { 0x50, 0x4B, 0x03, 0x04 };

        byte[] fileHeader = new byte[8];
        fileStream.Read(fileHeader, 0, fileHeader.Length);

        // Reset the position of the stream to the beginning
        fileStream.Position = 0;

        // Check if the file header matches either .xls or .xlsx
        return fileHeader.Take(xlsHeader.Length).SequenceEqual(xlsHeader) ||
               fileHeader.Take(xlsxHeader.Length).SequenceEqual(xlsxHeader);
    }

    public Task<Stream> DownloadTemplateAsync(CancellationToken cancellationToken)
    {
        string binDirectory = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)!;
        var filePath = Path.Combine(binDirectory, DocumentConstants.TemplateFolder, DocumentConstants.RoutePartCapacityTemplate);
        if (!File.Exists(filePath))
        {
            throw new ErrorException(CapacityFactorByVariantDomainError.FailedToDownloadTemplate("Template file not found"));
        }

        var file = new FileStream(filePath, FileMode.Open, FileAccess.Read);

        return Task.FromResult((Stream)file);
    }
}
