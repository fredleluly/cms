using IDTrack.Domain.Features.Masters.Supplier;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.Supplier;

public class PartSupplierEntityConfiguration : IEntityTypeConfiguration<PartSupplier>
{
    public void Configure(EntityTypeBuilder<PartSupplier> entity)
    {
        entity.HasKey(e => e.Id).HasName("PK__MS_VENDO__3214EC2700750D23");

        entity.ToTable("MS_VENDOR");

        entity.HasIndex(e => e.VendorCode, "UQ__MS_VENDO__E99CB384035179CE").IsUnique();

        entity.Property(e => e.Id).HasColumnName("ID");

        entity.Ignore(e => e.CreateByStr);
        entity.Ignore(e => e.UpdateByStr);

        entity.Property(e => e.VendorCode)
            .IsRequired()
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("VENDOR_CODE");

        entity.Property(e => e.VendorName)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("VENDOR_NAME");

        entity.Property(e => e.AliasName)
            .HasMaxLength(20)
            .IsUnicode(false)
            .HasColumnName("ALIAS_NAME");

        entity.Property(e => e.Address)
            .HasMaxLength(150)
            .IsUnicode(false)
            .HasColumnName("ADDRESS");

        entity.Property(e => e.City)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("CITY");

        entity.Property(e => e.PostalCode)
            .HasMaxLength(10)
            .IsUnicode(false)
            .HasColumnName("POSTAL_CODE");

        entity.Property(e => e.RegionCode)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("REGION_CODE");

        entity.Property(e => e.CountryCode)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("COUNTRY_CODE");

        entity.Property(e => e.ContactName)
            .HasMaxLength(60)
            .IsUnicode(false)
            .HasColumnName("CONTACT_NAME");

        entity.Property(e => e.PhoneNo1)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("PHONE_NO1");

        entity.Property(e => e.PhoneNo2)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("PHONE_NO2");

        entity.Property(e => e.FaxNo1)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("FAX_NO1");

        entity.Property(e => e.FaxNo2)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("FAX_NO2");

        entity.Property(e => e.Email)
            .HasMaxLength(500)
            .IsUnicode(false)
            .HasColumnName("EMAIL");

        entity.Property(e => e.TaxCode)
            .HasMaxLength(30)
            .IsUnicode(false)
            .HasColumnName("TAX_CODE");

        entity.Property(e => e.VendorDesc100)
            .HasMaxLength(100)
            .IsUnicode(false)
            .HasColumnName("VENDOR_DESC100");

        entity.Property(e => e.VendorType)
            .HasMaxLength(5)
            .IsUnicode(false)
            .HasColumnName("VENDOR_TYPE");

        entity
            .Property(e => e.ParentId)
            .IsRequired(false)
            .HasColumnName("PARENT_ID");

        entity.Property(e => e.Lat)
            .HasMaxLength(120)
            .IsUnicode(false)
            .HasColumnName("LAT");

        entity.Property(e => e.Lng)
            .HasMaxLength(120)
            .IsUnicode(false)
            .HasColumnName("LNG");

        entity.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");
        entity.Property(e => e.CreateTime)
            .HasDefaultValueSql("(getdate())")
            .HasColumnType("datetime")
            .HasColumnName("CREATE_TIME");

        entity.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
        entity.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_TIME");
    }
}
