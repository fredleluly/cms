using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.Supplier;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.Supplier;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.Supplier;

public class PartSupplierRepository : IPartSupplierRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public PartSupplierRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<PartSupplier>> AddAsync(PartSupplier supplier, CancellationToken ct)
    {
        await _context.PartSuppliers.AddAsync(supplier, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PartSupplier>(result.Error);

        return Result.Success(supplier);
    }

    public async Task<Result<PartSupplier>> GetByIdAsync(long id, CancellationToken ct)
    {
        var supplier = await _context.PartSuppliers.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (supplier is null)
            return Result.Failure<PartSupplier>(PartSupplierDomainError.PartSupplierNotFound(id.ToString()));

        return Result.Success(supplier);
    }

    public async Task<Result<PartSupplier>> UpdateAsync(PartSupplier supplier, CancellationToken ct)
    {
        _context.Update(supplier);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PartSupplier>(result.Error);

        return Result.Success(supplier);
    }

    public async Task<Result<PartSupplier>> DeleteAsync(long id, CancellationToken ct)
    {
        var supplier = await _context.PartSuppliers.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (supplier is null)
            return Result.Failure<PartSupplier>(PartSupplierDomainError.PartSupplierNotFound(id.ToString()));

        _context.PartSuppliers.Remove(supplier);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PartSupplier>(result.Error);

        return Result.Success(supplier);
    }

    public Task<PagingResult<PartSupplier>> LoadPageAsync(IQueryable<PartSupplier> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PartSupplier> Query()
    {
        return _context.PartSuppliers;
    }

    public async Task<Result<PartSupplier>> GetByCodeAsync(string code, CancellationToken ct)
    {
        var supplier = await _context.PartSuppliers.FirstOrDefaultAsync(e => e.VendorCode == code, ct);

        if (supplier is null)
            return Result.Failure<PartSupplier>(PartSupplierDomainError.PartSupplierNotFound(code));

        return Result.Success(supplier);
    }

    public Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> query, PagingQuery page, CancellationToken ct) where T : class
    {
        return PagingService.LoadQueryAsync(query, page, _context, ct);
    }
}
