using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Masters.TransporterRoute;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Masters.TransporterRoute;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.Masters.TransporterRoute;

public class PickingTransporterRouteRepository : IPickingTransporterRouteRepository
{
    private readonly AppDbContext _context;
    private readonly IUnitOfWork _uow;

    public PickingTransporterRouteRepository(AppDbContext context, IUnitOfWork uow)
    {
        _context = context;
        _uow = uow;
    }

    public async Task<Result<PickingTransporterRoute>> AddAsync(PickingTransporterRoute transporter, CancellationToken ct)
    {
        await _context.PickingTransporterRoutes.AddAsync(transporter, ct);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.Error == UnitOfWorkDomainError.DuplicateEntry)
            return Result.Failure<PickingTransporterRoute>(PickingTransporterRouteDomainError.DuplicatePickingTransporterRoute);

        if (result.IsFailure)
            return Result.Failure<PickingTransporterRoute>(result.Error);

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporterRoute>> GetByIdAsync(long id, CancellationToken ct)
    {
        var transporter = await _context.PickingTransporterRoutes.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (transporter is null)
            return Result.Failure<PickingTransporterRoute>(PickingTransporterRouteDomainError.PickingTransporterRouteNotFound(id));

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporterRoute>> UpdateAsync(PickingTransporterRoute transporter, CancellationToken ct)
    {
        _context.Update(transporter);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingTransporterRoute>(result.Error);

        return Result.Success(transporter);
    }

    public async Task<Result<PickingTransporterRoute>> DeleteAsync(long id, CancellationToken ct)
    {
        var transporter = await _context.PickingTransporterRoutes.FirstOrDefaultAsync(e => e.Id == id, ct);

        if (transporter is null)
            return Result.Failure<PickingTransporterRoute>(PickingTransporterRouteDomainError.PickingTransporterRouteNotFound(id));

        _context.PickingTransporterRoutes.Remove(transporter);

        var result = await _uow.SaveChangesAsync(ct);

        if (result.IsFailure)
            return Result.Failure<PickingTransporterRoute>(result.Error);

        return Result.Success(transporter);
    }

    public Task<PagingResult<PickingTransporterRoute>> LoadPageAsync(IQueryable<PickingTransporterRoute> query, PagingQuery page, CancellationToken ct)
    {
        return PagingService.PaginateQueryAsync(query, page, _context, ct);
    }

    public IQueryable<PickingTransporterRoute> Query()
    {
        return (from transporterRoute in _context.PickingTransporterRoutes
                join route in _context.PickingRoutes on transporterRoute.PickingRouteId equals route.Id
                join transporter in _context.PickingTransporters on transporterRoute.PickingTransporterId equals transporter.Id
                select new PickingTransporterRoute
                {
                    Id = transporterRoute.Id,
                    PickingRouteId = transporterRoute.PickingRouteId,
                    PickingTransporterId = transporterRoute.PickingTransporterId,
                    Transporter = transporter,
                    Route = route,
                    Cycles = transporterRoute.Cycles,
                    Status = transporterRoute.Status,
                    CreateTime = transporterRoute.CreateTime,
                    UpdateTime = transporterRoute.UpdateTime,
                    CreateBy = transporterRoute.CreateBy,
                    UpdateBy = transporterRoute.UpdateBy
                }).AsQueryable();
    }
}
