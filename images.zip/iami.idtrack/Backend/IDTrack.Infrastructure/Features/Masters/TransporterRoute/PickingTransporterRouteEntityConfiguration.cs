using IDTrack.Domain.Features.Masters.TransporterRoute;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IDTrack.Infrastructure.Features.Masters.TransporterRoute;

public class PickingTransporterRouteEntityConfiguration : IEntityTypeConfiguration<PickingTransporterRoute>
{
    public void Configure(EntityTypeBuilder<PickingTransporterRoute> entity)
    {
        entity.HasKey(e => e.Id).HasName("PK_MS_TRACK_TRANSPORTER_ROUTE");

        entity.ToTable("MS_TRACK_TRANSPORTER_ROUTE");

        entity.HasIndex(e => new { e.PickingRouteId, e.PickingTransporterId }, "UQ_MS_TRACK_TRANSPORTER_ROUTE_CYCLE")
            .IsUnique();

        entity.Ignore(e => e.CreateByStr);
        entity.Ignore(e => e.UpdateByStr);

        entity.Property(e => e.Id).HasColumnName("ID");

        entity.Property(e => e.PickingRouteId).HasColumnName("POS_ROUTE_ID");

        entity.Property(e => e.PickingTransporterId).HasColumnName("TRANSPORTER_ID");

        entity.OwnsMany(e => e.Cycles, cb =>
        {
            cb.ToTable("MS_TRACK_TRANSPORTER_ROUTE_CYCLE");

            cb.WithOwner().HasForeignKey("TRANSPORTER_ROUTE_ID");

            cb.HasKey(e => e.Id).HasName("PK_MS_TRACK_TRANSPORTER_ROUTE_CYCLE");

            cb.Ignore(e => e.CreateByStr);
            cb.Ignore(e => e.UpdateByStr);

            cb.Property(e => e.Id).HasColumnName("ID");

            cb.Property(e => e.CycleNo).HasColumnName("CYCLE_NO");
            cb.Property(e => e.DeparturePlan).HasColumnName("DEPT_PLAN");
            cb.Property(e => e.ArrivalPlan).HasColumnName("ARRIVE_PLAN");

            cb.Property(e => e.Status)
                .HasDefaultValue(0)
                .HasColumnName("STATUS");

            cb.Property(e => e.CreateTime)
                .HasColumnType("datetime")
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("CREATE_TIME");

            cb.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

            cb.Property(e => e.UpdateTime)
                .HasColumnType("datetime")
                .HasColumnName("UPDATE_TIME");

            cb.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");
        });

        entity.Property(e => e.Status)
            .HasDefaultValue(0)
            .HasColumnName("STATUS");

        entity.Property(e => e.CreateTime)
            .HasColumnType("datetime")
            .HasDefaultValueSql("(getdate())")
            .HasColumnName("CREATE_TIME");

        entity.Property(e => e.CreateBy).HasColumnName("CREATE_BY");

        entity.Property(e => e.UpdateTime)
            .HasColumnType("datetime")
            .HasColumnName("UPDATE_TIME");

        entity.Property(e => e.UpdateBy).HasColumnName("UPDATE_BY");

        entity.HasOne(e => e.Transporter).WithMany().HasForeignKey(e => e.PickingTransporterId);
        entity.HasOne(e => e.Route).WithMany().HasForeignKey(e => e.PickingRouteId);
    }
}
