using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.AppConfiguration;
using IDTrack.Domain.Features.AppConfiguration;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Persistence.Data;
using IDTrack.Infrastructure.Persistence.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace IDTrack.Infrastructure.Features.AppConfiguration;

public class AppConfigurationService : IAppConfigurationService
{
    private readonly AppDbContext _context;

    private readonly IUnitOfWork _unitOfWork;
    private const double DEFAULT_GEOFENCE_RADIUS = 200;
    private const bool DEFAULT_ENABLED_GEOFENCE = true;
    private const bool DEFAULT_ENABLED_REALTIME_MONITORING = true;

    public AppConfigurationService(AppDbContext context, IUnitOfWork unitOfWork)
    {
        _context = context;
        _unitOfWork = unitOfWork;
    }

    public async Task<double> GetGeofenceRadiusInMeterAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SetParams
            .FirstOrDefaultAsync(
                e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.GEOFENCE_RADIUS_KEY,
                cancellationToken);

        if (result is null)
            return DEFAULT_GEOFENCE_RADIUS;

        return double.Parse(result.ParamValue);
    }

    public async Task<bool> IsDirectDlvGeofenceEnabledAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SetParams
            .FirstOrDefaultAsync(
                e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_DIRECT_GEOFENCE_KEY,
                cancellationToken);

        if (result is null)
            return DEFAULT_ENABLED_GEOFENCE;

        return bool.Parse(result.ParamValue);
    }

    public async Task<bool> IsPickingGeofenceEnabledAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SetParams
            .FirstOrDefaultAsync(
                e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_GEOFENCE_KEY,
                cancellationToken);

        if (result is null)
            return DEFAULT_ENABLED_GEOFENCE;

        return bool.Parse(result.ParamValue);
    }

    public async Task<DateTime> GetOkbCutoffDateAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SetParams
            .FirstOrDefaultAsync(
                e => e.ParamGroup == IAppConfigurationService.GLOBAL_APP_GROUP &&
                    e.ParamName == IAppConfigurationService.OKB_CUTOFF_KEY,
                cancellationToken);

        if (result is null)
            return DateTime.MinValue;

        return DateTime.Parse(result.ParamValue);
    }

    public async Task<bool> IsRealtimeMonitoringEnabledAsync(CancellationToken cancellationToken)
    {
        var result = await _context.SetParams
            .FirstOrDefaultAsync(
                e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_REALTIME_MONITORING_KEY,
                cancellationToken);

        if (result is null)
            return DEFAULT_ENABLED_REALTIME_MONITORING;

        return bool.Parse(result.ParamValue);
    }

    public async Task<Result> UpdateAppConfigurationAsync(
        AppConfig geofencedEnable, 
        AppConfig geofenceRadius, 
        bool directDlvGeofenceEnabled,
        bool enableRealtimeMonitoring,
        DateTime oldDataCutoffDate,
        CancellationToken cancellationToken)
    {
        try
        {
            var radiusParam = await _context.SetParams
                .FirstOrDefaultAsync(e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.GEOFENCE_RADIUS_KEY,
                    cancellationToken);

            if (radiusParam != null)
            {
                radiusParam.ParamValue = geofenceRadius.Value;
            }
            else
            {
                radiusParam = new SetParam
                {
                    ParamGroup = IAppConfigurationService.APP_GROUP_KEY,
                    ParamName = IAppConfigurationService.GEOFENCE_RADIUS_KEY,
                    ParamValue = geofenceRadius.Value
                };
                await _context.SetParams.AddAsync(radiusParam, cancellationToken);
            }

            var geofenceEnabledParam = await _context.SetParams
                .FirstOrDefaultAsync(e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_GEOFENCE_KEY,
                    cancellationToken);

            if (geofenceEnabledParam != null)
            {
                geofenceEnabledParam.ParamValue = geofencedEnable.Value;
            }
            else
            {
                geofenceEnabledParam = new SetParam
                {
                    ParamGroup = IAppConfigurationService.APP_GROUP_KEY,
                    ParamName = IAppConfigurationService.ENABLE_GEOFENCE_KEY,
                    ParamValue = geofencedEnable.Value
                };
                await _context.SetParams.AddAsync(geofenceEnabledParam, cancellationToken);
            }

            var directDlvGeofenceEnabledParam = await _context.SetParams
                .FirstOrDefaultAsync(e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_DIRECT_GEOFENCE_KEY,
                    cancellationToken);

            if (directDlvGeofenceEnabledParam != null)
            {
                directDlvGeofenceEnabledParam.ParamValue = directDlvGeofenceEnabled.ToString();
            }
            else
            {
                directDlvGeofenceEnabledParam = new SetParam
                {
                    ParamGroup = IAppConfigurationService.APP_GROUP_KEY,
                    ParamName = IAppConfigurationService.ENABLE_DIRECT_GEOFENCE_KEY,
                    ParamValue = directDlvGeofenceEnabled.ToString()
                };
                await _context.SetParams.AddAsync(directDlvGeofenceEnabledParam, cancellationToken);
            }

            var realtimeMonitoringParam = await _context.SetParams
                .FirstOrDefaultAsync(e => e.ParamGroup == IAppConfigurationService.APP_GROUP_KEY &&
                    e.ParamName == IAppConfigurationService.ENABLE_REALTIME_MONITORING_KEY,
                    cancellationToken);

            if (realtimeMonitoringParam != null)
            {
                realtimeMonitoringParam.ParamValue = enableRealtimeMonitoring.ToString();
            }
            else
            {
                realtimeMonitoringParam = new SetParam
                {
                    ParamGroup = IAppConfigurationService.APP_GROUP_KEY,
                    ParamName = IAppConfigurationService.ENABLE_REALTIME_MONITORING_KEY,
                    ParamValue = enableRealtimeMonitoring.ToString()
                };
                await _context.SetParams.AddAsync(realtimeMonitoringParam, cancellationToken);
            }

            var okbCutoffParam = await _context.SetParams
                .FirstOrDefaultAsync(e => e.ParamGroup == IAppConfigurationService.GLOBAL_APP_GROUP &&
                    e.ParamName == IAppConfigurationService.OKB_CUTOFF_KEY,
                    cancellationToken);

            if (okbCutoffParam != null)
            {
                okbCutoffParam.ParamValue = oldDataCutoffDate.ToString();
            }
            else
            {
                okbCutoffParam = new SetParam
                {
                    ParamGroup = IAppConfigurationService.GLOBAL_APP_GROUP,
                    ParamName = IAppConfigurationService.OKB_CUTOFF_KEY,
                    ParamValue = oldDataCutoffDate.ToString("yyyy-MM-dd")
                };
                await _context.SetParams.AddAsync(okbCutoffParam, cancellationToken);
            }

            return await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            return Result.Failure<AppConfig>(AppConfigurationDomainError.FailedToUpdateAppConfiguration(ex.Message));
        }
    }
}

