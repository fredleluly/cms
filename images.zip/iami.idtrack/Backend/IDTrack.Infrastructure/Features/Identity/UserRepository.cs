using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Identity.UseCases;
using IDTrack.Application.Paging;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Features.Identity.Data;
using IDTrack.Infrastructure.Features.Identity.Data.Entities;
using IDTrack.Infrastructure.Paging;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace IDTrack.Infrastructure.Features.Identity;

public class UserRepository : IUserRepository
{
    private readonly AppDbContext _context;
    private readonly IdentityContext _identityContext;
    private readonly IIdentityUnitOfWork _unitOfWork;

    public UserRepository(AppDbContext context, IdentityContext identityContext, IIdentityUnitOfWork unitOfWork)
    {
        _context = context;
        _identityContext = identityContext;
        _unitOfWork = unitOfWork;
    }

    public Task<PagingResult<QueryUserUseCaseResult>> LoadPageAsync(QueryUserUseCase req, CancellationToken ct)
    {
        var predicate = PredicateBuilder.True<SecUserInfra>();

        if (!string.IsNullOrEmpty(req.UserName))
            predicate = predicate.And(x => x.UserName!.Contains(req.UserName));

        if (!string.IsNullOrEmpty(req.WarehouseCode))
            predicate = predicate.And(x => x.WarehouseCode!.Contains(req.WarehouseCode));

        if (!string.IsNullOrEmpty(req.PlantCode))
            predicate = predicate.And(x => x.PlantCode!.Contains(req.PlantCode));

        if (!string.IsNullOrEmpty(req.Role))
            predicate = predicate.And(x => x.SecUserRoles.Any(r => r.SecRole.Name!.ToLower().Contains(req.Role)));

        return PagingService
            .PaginateQueryAsync(
                _identityContext.Users
                    .Where(predicate)
                    .Select(e => new QueryUserUseCaseResult(
                        e.Id,
                        e.UserName!, 
                        e.Fullname, 
                        e.Email!, 
                        e.PhoneNumber, 
                        e.PlantCode, 
                        e.WarehouseCode, 
#pragma warning disable CS8602 // Dereference of a possibly null reference.
                        e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.SupplierId).ClaimValue,
                        e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.LogisticPartnerId).ClaimValue,
#pragma warning restore CS8602 // Dereference of a possibly null reference.
                        // e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.SupplierId) == null ? "" : e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.SupplierId)!.ClaimValue,
                        // e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.LogisticPartnerId) == null ? "" : e.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.LogisticPartnerId)!.ClaimValue,
                        e.Disabled, 
                        e.EmailConfirmed, 
                        e.LockoutEnabled, 
                        e.SecUserRoles.Select(r => r.SecRole.Name!).ToArray()
                    )
                ),
                req, 
                ct
            );
    }

    public async Task<PagingResult<T>> LoadPageAsync<T>(IQueryable<T> qry, PagingQuery page, CancellationToken ct)
        where T : class
    {
        return await PagingService.LoadQueryAsync<T>(qry, page, _context, ct);
    }

    public async Task<PagingResult<User>> LoadPageAsync(IQueryable<User> query, PagingQuery page, CancellationToken ct)
    {
        return await PagingService.PaginateQueryAsync(query, page, ct);
    }

    public IQueryable<User> Query()
    {
#pragma warning disable CS8601 // Possible null reference return.
#pragma warning disable CS8604 // Possible null reference return.
        return _context.Users.Select(e => new User
        {
            Fullname = e.Fullname,
            Username = e.UserName,
            Email = e.Email,
            PhoneNumber = e.PhoneNumber,
            PlantCode = e.PlantCode,
            WarehouseCode = e.WarehouseCode,
            Disabled = e.Disabled,
            EmailConfirmed = e.EmailConfirmed,
            LockoutEnabled = e.LockoutEnabled,
            Claims = e.SecUserClaims.Select(e => new Claim(e.ClaimType, e.ClaimValue)).ToList(),
        });
#pragma warning restore
    }

    public IQueryable<User> QueryDrivers()
    {
#pragma warning disable CS8601 // Possible null reference return.
#pragma warning disable CS8604 // Possible null reference return.
        return _context
            .Users
            .Where(u => u.SecUserClaims.Any(c => c.ClaimType == ClaimType.LogisticPartnerId))
            .Select(e => new User
            {
                Id = e.Id,
                Fullname = e.Fullname,
                Username = e.UserName,
                Email = e.Email,
                PhoneNumber = e.PhoneNumber,
                PlantCode = e.PlantCode,
                WarehouseCode = e.WarehouseCode,
                Disabled = e.Disabled,
                EmailConfirmed = e.EmailConfirmed,
                LockoutEnabled = e.LockoutEnabled,
                Claims = e.SecUserClaims.Select(e => new Claim(e.ClaimType, e.ClaimValue)).ToList(),
            });
#pragma warning restore
    }
    public async Task<Result> UpdateUserAsync(User user, CancellationToken ct = default)
    {
        var foundUser = await _identityContext.Users.Include(e => e.SecUserClaims).FirstOrDefaultAsync(e => e.Id == user.Id, ct);

        if (foundUser is null)
            return IdentityDomainError.UserNotFound(user.Id.ToString());

        foundUser.Disabled = user.Disabled;

        var foundUserSupplierClaim = foundUser.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.SupplierId);
        var userSupplierClaim = user.Claims.FirstOrDefault(e => e.Type == ClaimType.SupplierId);

        if (userSupplierClaim is not null && foundUserSupplierClaim is not null)
            foundUserSupplierClaim.ClaimValue = userSupplierClaim.Value;

        if (userSupplierClaim is not null && foundUserSupplierClaim is null)
            foundUser.SecUserClaims.Add(new SecUserClaimInfra
            {
                UserId = foundUser.Id,
                ClaimType = userSupplierClaim.Type,
                ClaimValue = userSupplierClaim.Value
            });

        if (userSupplierClaim is null && foundUserSupplierClaim is not null)
            foundUser.SecUserClaims.Remove(foundUserSupplierClaim);

        var foundUserLogisticPartnerClaim = foundUser.SecUserClaims.FirstOrDefault(e => e.ClaimType == ClaimType.LogisticPartnerId);
        var userLogisticPartnerClaim = user.Claims.FirstOrDefault(e => e.Type == ClaimType.LogisticPartnerId);

        if (userLogisticPartnerClaim is not null && foundUserLogisticPartnerClaim is not null)
            foundUserLogisticPartnerClaim.ClaimValue = userLogisticPartnerClaim.Value;

        if (userLogisticPartnerClaim is not null && foundUserLogisticPartnerClaim is null)
            foundUser.SecUserClaims.Add(new SecUserClaimInfra
            {
                UserId = foundUser.Id,
                ClaimType = userLogisticPartnerClaim.Type,
                ClaimValue = userLogisticPartnerClaim.Value
            });

        if (userLogisticPartnerClaim is null && foundUserLogisticPartnerClaim is not null)
            foundUser.SecUserClaims.Remove(foundUserLogisticPartnerClaim);

        return await _unitOfWork.SaveChangesAsync(ct);
    }
}

