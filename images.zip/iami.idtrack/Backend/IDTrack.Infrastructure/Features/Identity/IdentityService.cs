using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using IDTrack.Application.Email;
using IDTrack.Application.Features.Identity;
using IDTrack.Application.Features.Identity.Models;
using IDTrack.Domain.Features.Identity;
using IDTrack.Domain.Features.Identity.Entities;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Features.Identity.Data;
using IDTrack.Infrastructure.Features.Identity.Data.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using User = IDTrack.Domain.Features.Identity.User;

namespace IDTrack.Infrastructure.Features.Identity;

public class IdentityService : IIdentityService
{
    private readonly string _origin = "https://localhost:5001/";
    private readonly UserManager<SecUserInfra> _userManager;
    private readonly RoleManager<SecRole> _roleManager;
    private readonly IUserClaimsPrincipalFactory<SecUserInfra> _userClaimsPrincipalFactory;
    private readonly Models.IdentityOptions _identityOptions;
    private readonly JwtOptions _jwtOptions;
    private readonly IdentityContext _context;
    private readonly IEmailService _emailService;

    public IdentityService(IOptions<Models.IdentityOptions> identityOptions,
        UserManager<SecUserInfra> userManager,
        RoleManager<SecRole> roleManager,
        IUserClaimsPrincipalFactory<SecUserInfra> userClaimsPrincipalFactory,
        IOptions<JwtOptions> jwtOptions,
        IdentityContext context,
        IEmailService emailService)
    {
        _userManager = userManager;
        _roleManager = roleManager;
        _userClaimsPrincipalFactory = userClaimsPrincipalFactory;
        _identityOptions = identityOptions.Value;
        _jwtOptions = jwtOptions.Value;
        _context = context;
        _emailService = emailService;
    }

    public bool AutoEmailConfirmedSetting { get { return _identityOptions.AutoEmailConfirmed; } }
    public bool SendEmailVerificationSetting { get { return _identityOptions.SendEmailVerification; } }

    public async Task<IEnumerable<Role>> GetAllRolesAsync()
    {
        return await _context.SecRole
            .AsNoTracking()
            .Select(e => new Role
            {
                Id = e.Id,
                Name = e.Name ?? "",
                RoleDescription = e.RoleDescription
            }).ToListAsync();
    }

    public async Task<Result> CreateUserAsync(
        string username,
        string email,
        string firstName,
        string lastName,
        string? phoneNumber,
        Boolean lockoutEnabled,
        Boolean disabled,
        string password,
        IList<string> roles
    )
    {
        if (await _userManager.FindByNameAsync(username) is not null)
            return IdentityDomainError.UsernameAlreadyUsed;
        if (await _userManager.FindByEmailAsync(email) is not null)
            return IdentityDomainError.EmailAlreadyUsed;

        var newUser = new SecUserInfra
        {
            UserName = username,
            Fullname = firstName.Trim() + " " + lastName.Trim(),
            FirstName = firstName,
            LastName = lastName,
            Email = email,
            EmailConfirmed = AutoEmailConfirmedSetting,
            PhoneNumber = phoneNumber,
            LockoutEnabled = lockoutEnabled,
            Disabled = disabled,
        };

        var result = await _userManager.CreateAsync(newUser, password);
        if (!result.Succeeded)
            return IdentityDomainError.FailedToCreateUser(result.Errors.First().Description);

        var user = await _userManager.FindByNameAsync(username);

        if (user is null) return IdentityDomainError.FailedToFindUserAfterCreated;

        return await UpdateAssignedUserRoles(user.Id, roles);
    }

    public async Task<Result> UpdateUserAsync(
        int userId,
        string firstName,
        string lastName,
        string? phoneNumber,
        Boolean lockoutEnabled,
        Boolean disabled,
        IList<string> roles
    )
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());

        if (user == null) return IdentityDomainError.UserNotFound(userId.ToString());

        user.FirstName = firstName;
        user.LastName = lastName;
        user.PhoneNumber = phoneNumber;
        user.LockoutEnabled = lockoutEnabled;
        user.Disabled = disabled;

        var result = await _userManager.UpdateAsync(user);
        if (!result.Succeeded)
            return IdentityDomainError.FailedToUpdateUser(result.Errors.First().Description);

        return await UpdateAssignedUserRoles(userId, roles);
    }

    public async Task<Result> DeleteUserAsync(int userId)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());

        if (user == null) return IdentityDomainError.UserNotFound(userId.ToString());

        var result = await _userManager.DeleteAsync(user);
        if (!result.Succeeded) return IdentityDomainError.FailedToDeleteUser(result.Errors.First().Description);

        return Result.Success();
    }

    public async Task<User?> GetUserByIdAsync(int userId)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());

        if (user is null) return null;

        var claims = await GetUserClaimsAsync(user);

        return new User
        {
            Id = user.Id,
            Fullname = user!.Fullname,
            Username = user.UserName!,
            Email = user.Email!,
            EmailConfirmed = user.EmailConfirmed,
            PhoneNumber = user.PhoneNumber,
            LockoutEnabled = user.LockoutEnabled,
            Disabled = user.Disabled,
            PlantCode = user.PlantCode,
            WarehouseCode = user.WarehouseCode,
            Claims = claims.ToList()
        };
    }

    public async Task<User?> GetUserByNameAsync(string username)
    {
        var user = await _userManager.FindByNameAsync(username);

        if (user is null) return null;

        var claims = await GetUserClaimsAsync(user);

        return new User
        {
            Id = user.Id,
            Fullname = user!.Fullname,
            Username = user.UserName!,
            Email = user.Email!,
            EmailConfirmed = user.EmailConfirmed,
            PhoneNumber = user.PhoneNumber,
            LockoutEnabled = user.LockoutEnabled,
            Disabled = user.Disabled,
            PlantCode = user.PlantCode,
            WarehouseCode = user.WarehouseCode,
            Claims = claims.ToList()
        };
    }

    public async Task<User?> GetUserByEmailAsync(string email)
    {
        var user = await _userManager.FindByEmailAsync(email);

        if (user is null) return null;

        var claims = await GetUserClaimsAsync(user);

        return new User
        {
            Id = user.Id,
            Fullname = user!.Fullname,
            Username = user.UserName!,
            Email = user.Email!,
            EmailConfirmed = user.EmailConfirmed,
            PhoneNumber = user.PhoneNumber,
            LockoutEnabled = user.LockoutEnabled,
            Disabled = user.Disabled,
            PlantCode = user.PlantCode,
            WarehouseCode = user.WarehouseCode,
            Claims = claims.ToList()
        };
    }

    public async Task<SecUserInfra?> GetUserByUsernameOrEmailAsync(string username)
    {
        var user = await _userManager.FindByNameAsync(username);
        if (user is not null)
            return user;

        return await _userManager.FindByEmailAsync(username);
    }

    public async Task<bool> CheckEmailConfirmedAsync(SecUserInfra user)
    {
        if (_identityOptions.RequiredEmailConfirmed)
            return await _userManager.IsEmailConfirmedAsync(user);

        return true;
    }

    public async Task<bool> IsLockedOutAsync(SecUserInfra user)
    {
        return await _userManager.IsLockedOutAsync(user);
    }

    public async Task<bool> CheckUserAccessAsync(SecUserInfra user, string password)
    {
        if (!await _userManager.CheckPasswordAsync(user, password))
        {
            await _userManager.AccessFailedAsync(user);
            return false;
        }
        await _userManager.ResetAccessFailedCountAsync(user);
        return true;
    }

    public async Task<IEnumerable<string>> GetUserRolesAsync(int userId)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());
        return (user is not null) ? await _userManager.GetRolesAsync(user) : new List<string>();
    }

    public async Task<IEnumerable<Claim>> GetUserClaimsAsync(int userId)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());
        return (user is not null) ? await _userManager.GetClaimsAsync(user) : new List<Claim>();
    }

    public async Task<IEnumerable<Claim>> GetUserClaimsAsync(SecUserInfra user)
    {
        return await _userManager.GetClaimsAsync(user);
    }

    public async Task<IEnumerable<Claim>> GetAllUserClaimsAsync(SecUserInfra user)
    {
        var claims = new List<Claim>();

        var userClaims = await GetUserClaimsAsync(user);
        claims.AddRange(userClaims);

        var userRoles = await GetUserRolesAsync(user.Id);
        foreach (var userRole in userRoles)
        {
            claims.Add(new Claim("role", userRole));
            if (await _roleManager.RoleExistsAsync(userRole))
            {
                var roleClaims = await GetRoleClaimsAsync(userRole);
                foreach (var roleClaim in roleClaims)
                {
                    if (claims.Contains(roleClaim))
                        continue;
                    claims.Add(roleClaim);
                }
            }
        }

        return claims;
    }

    public async Task<IEnumerable<Claim>> GetRoleClaimsAsync(string roleName)
    {
        var role = await _roleManager.FindByNameAsync(roleName);
        if (role is null)
            return new List<Claim>();
        return await _roleManager.GetClaimsAsync(role);
    }

    public async Task<IEnumerable<Claim>> GetRoleClaimsAsync(SecRole role)
    {
        return await _roleManager.GetClaimsAsync(role);
    }

    public async Task<Result> UpdateAssignedUserRoles(int userId, IList<string> roles)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());

        if (user == null)
            return IdentityDomainError.UserNotFound(userId.ToString());

        IList<String> curRoles = await _userManager.GetRolesAsync(user);
        if ((roles.Count == 0) && (curRoles.Count == 0))
            return Result.Success();
        else if ((roles.Count == 0) && (curRoles.Count > 0))
        {
            var result = await _userManager.RemoveFromRolesAsync(user, curRoles);
            if (!result.Succeeded)
                return IdentityDomainError.FailedToRemoveRole(result.Errors.First().Description);

            return Result.Success();
        }
        else if ((roles.Count > 0) && (curRoles.Count == 0))
        {
            var result = await _userManager.AddToRolesAsync(user, roles);
            if (!result.Succeeded)
                return IdentityDomainError.FailedToAddRole(result.Errors.First().Description);

            return Result.Success();
        }
        else
        {
            var result = await _userManager.AddToRolesAsync(user, roles.Select(e => e.ToLower()).Except(curRoles.Select(e => e.ToLower())));
            if (!result.Succeeded)
                return IdentityDomainError.FailedToAddRole(result.Errors.First().Description);

            result = await _userManager.RemoveFromRolesAsync(user, curRoles.Select(e => e.ToLower()).Except(roles.Select(e => e.ToLower())));

            if (!result.Succeeded)
                return IdentityDomainError.FailedToRemoveRole(result.Errors.First().Description);

            return Result.Success();
        }
    }

    public async Task<Result> ChangePasswordAsync(int userId, string oldPassword, string newPassword)
    {
        var user = await _userManager.FindByIdAsync(userId.ToString());
        if (user is null)
            return IdentityDomainError.UserNotFound(userId.ToString());

        var result = await _userManager.ChangePasswordAsync(user, oldPassword, newPassword);
        if (!result.Succeeded)
            return IdentityDomainError.FailedToChangePassword(result.Errors.First().Description);

        return Result.Success();
    }

    public async Task<string> GenerateEmailConfirmationTokenAsync(string email)
    {
        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
            return "";

        var token = await _userManager.GenerateEmailConfirmationTokenAsync(user);
        return token;
    }

    public async Task<string> GenerateEmailConfirmationTokenAsync(SecUserInfra user)
    {
        return await _userManager.GenerateEmailConfirmationTokenAsync(user);
    }

    public async Task<Result> ConfirmedEmailAsync(string email, string token)
    {
        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
            return IdentityDomainError.UserNotFoundByEmail(email);
        var result = await _userManager.ConfirmEmailAsync(user, token);

        if (!result.Succeeded)
            return IdentityDomainError.FailedToConfirmEmail(result.Errors.First().Description);

        return Result.Success();
    }

    public async Task<string> GeneratePasswordResetTokenAsync(string email)
    {
        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
            return "";

        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        return token;
    }

    public async Task<Result> ResetPasswordAsync(string email, string token, string newPassword)
    {
        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
            return IdentityDomainError.UserNotFoundByEmail(email);

        var result = await _userManager.ResetPasswordAsync(user, token, newPassword);
        if (!result.Succeeded)
            return IdentityDomainError.FailedToResetPassword(result.Errors.First().Description);

        return Result.Success();
    }

    public async Task<Result> SignUpAsync(string username, string email, string firstName, string lastName, string password)
    {
        if (await GetUserByNameAsync(username) is not null)
            return IdentityDomainError.UsernameAlreadyUsed;
        if (await GetUserByEmailAsync(email) is not null)
            return IdentityDomainError.EmailAlreadyUsed;

        var result = await CreateUserAsync(username, email, firstName, lastName, null, true, false, password, new List<string>());

        if (!result.IsSuccess)
            return result;

        return Result.Success();
    }

    public async Task<Result<AuthenticationResult>> SignInAsync(string username, string password, CancellationToken ct = default)
    {
        var user = await GetUserByUsernameOrEmailAsync(username);
        if (user is null)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.IncorrectUsernameOrPassword);

        if (!await CheckEmailConfirmedAsync(user))
            return Result.Failure<AuthenticationResult>(IdentityDomainError.EmailNotConfirmed);

        if (user.Disabled)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.CannotSignInUserIsDisabled);

        if (await IsLockedOutAsync(user))
            return Result.Failure<AuthenticationResult>(IdentityDomainError.IncorrectUsernameOrPassword);

        if (!await CheckUserAccessAsync(user, password))
            return Result.Failure<AuthenticationResult>(IdentityDomainError.IncorrectUsernameOrPassword);

        return await GenerateAuthenticationResultForUserAsync(user, ct);
    }

    public async Task<Result<AuthenticationResult>> RefreshTokenAsync(string jwtToken, string refreshToken, CancellationToken ct = default)
    {
        var jtiResult = GetRefreshTokenJti(refreshToken);

        if (jtiResult.IsFailure || jtiResult.Value is null)
            return Result.Failure<AuthenticationResult>(jtiResult.Error);

        var refreshTokenEntity = await GetRefreshTokenById(jtiResult.Value, ct);
        if (refreshTokenEntity == null)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.RefreshTokenNotFound);

        if (refreshTokenEntity.RevokedDate.HasValue)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.RefreshTokenUsed);

        var userId = GetUserIdFromToken(refreshToken);
        var user = await _userManager.FindByIdAsync(userId.ToString());
        if (user is null)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.UserNotFound(userId.ToString()));

        if (user.Disabled)
            return Result.Failure<AuthenticationResult>(IdentityDomainError.UserIsDisabled);

        await RevokeRefreshTokenAsync(userId, jtiResult.Value, ct);
        return await GenerateAuthenticationResultForUserAsync(user, ct);
    }

    public async Task<Result> ForgotPasswordAsync(string email, CancellationToken ct = default)
    {
        var token = await GeneratePasswordResetTokenAsync(email);
        if (!string.IsNullOrWhiteSpace(token))
        {
            string plainToken = $"{{\"email\": \"{email}\", \"token\": \"{token}\"}}";
            string bToken = ToBase64Url(plainToken);

            var verifyUrl = $"{_origin}site/reset-password?t={bToken}";
            var message = $@"
                <h4>Reset Password</h4>
                <p>Please click the below link to reset your password:</p>
                <p><a href=""{verifyUrl}"">Reset password</a></p>
                <p>Please use the below token to reset password <code>reset-password</code> api route:</p>
                <p>{token}</p>";
            var result = await _emailService.SendSimpleHtmlMessageAsync(
                "ISEI - Reset your password",
                message,
                "",
                email, null, null, ct);

            return result;
        }
        return Result.Success();
    }

    public async Task<Result> SendConfirmedEmailAsync(string email, CancellationToken ct = default)
    {
        var user = await _userManager.FindByEmailAsync(email);
        if (user is null)
            return Result.Success();

        var token = await GenerateEmailConfirmationTokenAsync(user.Email ?? "");
        if (!string.IsNullOrWhiteSpace(token))
        {
            string plainToken = $"{{\"email\": \"{email}\", \"token\": \"{token}\"}}";
            string bToken = ToBase64Url(plainToken);

            var verifyUrl = $"{_origin}site/confirm-email?t={bToken}";
            var message = $@"
                <h4>Confirm Email</h4>
                <p>Please click the below link to verify your email address:</p>
                <p><a href=""{verifyUrl}"">Verify Email</a></p>
                <p>Please use the below token to verify your email address with the <code>email-verification</code> api route:</p>
                <p>{token}</p>";
            var result = await _emailService.SendSimpleHtmlMessageAsync(
                "ISEI - Confirmed your email",
                message,
                $"{user.FirstName} {user.LastName}",
                email, null, null, ct);
            return result;
        }

        return Result.Success();
    }

    private async Task<Result<AuthenticationResult>> GenerateAuthenticationResultForUserAsync(SecUserInfra user, CancellationToken cancellationToken)
    {
        string jwtId = Guid.NewGuid().ToString();
        string refreshTokenId = Guid.NewGuid().ToString();

        var accessClaims = await GetAllUserClaimsAsync(user);
        var accessToken = GenerateToken(user.Id, user.FirstName, user.LastName, jwtId, accessClaims);
        var refreshClaims = new List<Claim>();
        var refreshToken = RefreshToken(user.Id, jwtId, refreshClaims);
        await CreateRefreshTokenAsync(user.Id, jwtId, refreshToken, _jwtOptions.TokenExpiryInMinutes, _jwtOptions.RefreshTokenExpiryInMinutes, cancellationToken);

        return Result.Success(new AuthenticationResult(accessToken, refreshToken, "bearer", null, _jwtOptions.TokenExpiryInMinutes));
    }

    public string GenerateToken(int userId, string firstName, string lastName, string jwtId, IEnumerable<Claim> userClaims)
    {
        var signingCredentials = new SigningCredentials(
            new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwtOptions.SecretKey)),
            SecurityAlgorithms.HmacSha256);

        var newClaims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, userId.ToString()),
            // new(JwtRegisteredClaimNames.GivenName, firstName),
            // new(JwtRegisteredClaimNames.FamilyName, lastName),
            new(JwtRegisteredClaimNames.Jti, jwtId),
        };
        if (userClaims is not null && userClaims.Any())
            newClaims.AddRange(userClaims);

        var token = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
            audience: _jwtOptions.Audience,
            claims: newClaims,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddMinutes(_jwtOptions.TokenExpiryInMinutes),
            signingCredentials: signingCredentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public string RefreshToken(int userId, string jwtId, IEnumerable<Claim> claims)
    {
        var signingCredentials = new SigningCredentials(
            new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_jwtOptions.RefreshTokenSecretKey)),
            SecurityAlgorithms.HmacSha256);

        var newClaims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, userId.ToString()),
            new(JwtRegisteredClaimNames.Jti, jwtId),
        };
        if (claims is not null && claims.Any())
            newClaims.AddRange(claims);

        var token = new JwtSecurityToken(
            issuer: _jwtOptions.Issuer,
            audience: _jwtOptions.Audience,
            claims: newClaims,
            notBefore: DateTime.UtcNow,
            expires: DateTime.UtcNow.AddMinutes(_jwtOptions.RefreshTokenExpiryInMinutes),
            signingCredentials: signingCredentials);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public async Task<SecRefreshToken?> GetRefreshTokenById(string id, CancellationToken cancellationToken = default)
    {
        return await _context.SecRefreshToken.AsNoTracking().FirstOrDefaultAsync(e => e.JwtId == id, cancellationToken);
    }

    public async Task<Result> CreateRefreshTokenAsync(int userId, string jwtId, string token, int tokenExpiryInMin, int RefreshExpiryInMin, CancellationToken cancellationToken = default)
    {
        var row = new SecRefreshToken
        {
            JwtId = jwtId,
            SecUserId = userId,
            Token = jwtId,
            ExpiredDate = DateTimeOffset.Now.AddMinutes(tokenExpiryInMin)
        };

        await _context.AddAsync(row, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }

    public async Task<Result> RevokeRefreshTokenAsync(int userId, string jwtId, CancellationToken cancellationToken = default)
    {
        var row = await _context.SecRefreshToken.FirstOrDefaultAsync(e => e.JwtId == jwtId, cancellationToken);

        if (row is null)
            return IdentityDomainError.RefreshTokenNotFound;

        row.RevokedDate = DateTimeOffset.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }

    public async Task<Result> SignOutAsync(string jwtId, CancellationToken cancellationToken = default)
    {
        var row = await _context.SecRefreshToken.FirstOrDefaultAsync(e => e.JwtId == jwtId, cancellationToken);
        if (row is null)
            return IdentityDomainError.RefreshTokenNotFound;

        row.RevokedDate = DateTimeOffset.UtcNow;
        await _context.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }

    private string ToBase64Url(string plain)
    {
        return Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(plain))
            .TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }

    private string GetJti(string token)
    {
        var jwt = new JwtSecurityToken(token);
        return jwt.Id;
    }

    private Result<string> GetRefreshTokenJti(string token)
    {
        // validate jwt with secret key
        var tokenHandler = new JwtSecurityTokenHandler();
        var validationParameters = new TokenValidationParameters
        {
            ValidateIssuer = false,
            ValidateAudience = false,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtOptions.RefreshTokenSecretKey))
        };

        try
        {
            var principal = tokenHandler.ValidateToken(token, validationParameters, out var validatedToken);
            return Result.Success<string>(validatedToken.Id);
        }
        catch (Exception)
        {
            return Result.Failure<string>(IdentityDomainError.InvalidToken);
        }
    }

    // create function to get "sub" from a refresh token
    private int GetUserIdFromToken(string token)
    {
        var jwt = new JwtSecurityToken(token);
        return int.Parse(jwt.Subject);
    }

}
