namespace IDTrack.Application.Features.Identity.Models;

public class JwtOptions
{
    public required string Issuer { get; set; }
    public required string Audience { get; set; }
    public required string SecretKey { get; set; }
    public int TokenExpiryInMinutes { get; set; }
    public int RefreshTokenExpiryInMinutes { get; set; }
    public required string RefreshTokenSecretKey { get; set; }
}
