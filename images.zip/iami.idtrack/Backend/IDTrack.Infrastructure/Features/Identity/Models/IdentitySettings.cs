namespace IDTrack.Infrastructure.Features.Identity.Models;

public class IdentityOptions
{
    public bool SendEmailVerification { get; set; }
    public bool AutoEmailConfirmed { get; set; }
    public bool RequiredEmailConfirmed { get; set; }
}
