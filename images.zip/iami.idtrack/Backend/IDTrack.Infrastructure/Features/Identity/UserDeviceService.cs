using IDTrack.Application.Abstractions.Data;
using IDTrack.Application.Features.Identity;
using IDTrack.Domain.Models;
using IDTrack.Infrastructure.Persistence.Data;
using Microsoft.AspNetCore.Http;

namespace IDTrack.Infrastructure.Features.Identity;

public class UserDeviceService : IUserDeviceService
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public UserDeviceService(IHttpContextAccessor httpContextAccessor){
        _httpContextAccessor = httpContextAccessor;
    }

    public Task<Result<string>> GetUserDeviceIdfromHeadersAsync(CancellationToken ct)
    {
        var deviceId = _httpContextAccessor.HttpContext?.Request.Headers["X-Device-Id"].ToString();

        if (deviceId == null)
        {
            return Task.FromResult(Result.Success<string>(""));
        }

        return Task.FromResult(Result.Success<string>(deviceId));
    }
}