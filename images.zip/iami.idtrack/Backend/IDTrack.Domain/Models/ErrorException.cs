namespace IDTrack.Domain.Models;

public class ErrorException : Exception
{
    public ErrorException(Error error) : base(error.Description)
    {
        Error = error;
    }

    public Error Error { get; }
}
