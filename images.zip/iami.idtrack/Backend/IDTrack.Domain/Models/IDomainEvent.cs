using MediatR;

namespace IDTrack.Domain.Models;

public interface IDomainEvent : INotification
{
}
