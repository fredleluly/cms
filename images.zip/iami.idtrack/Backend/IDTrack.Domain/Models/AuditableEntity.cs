using System.Text.Json.Serialization;

namespace IDTrack.Domain.Models;

public abstract class AuditableEntity
{
    public int Status { get; set; } = 0;
    [JsonConverter(typeof(DateTimeJsonConverter))]
    public DateTime CreateTime { get; set; } = DateTime.Now;
    [JsonConverter(typeof(DateTimeJsonConverter))]
    public DateTime? UpdateTime { get; set; }
    [JsonIgnore]
    public long CreateBy { get; set; }
    [JsonIgnore]
    public long? UpdateBy { get; set; }

    [JsonPropertyName("createBy")]
    public string? CreateByStr { get; set; }
    [JsonPropertyName("updateBy")]
    public string? UpdateByStr { get; set; }
}
