using IDTrack.Domain.Models;

namespace IDTrack.Domain.Internationalization;

public interface IDomainErrorLocalizer
{
    public Error Error<T>(string code, params object[] args);
}
