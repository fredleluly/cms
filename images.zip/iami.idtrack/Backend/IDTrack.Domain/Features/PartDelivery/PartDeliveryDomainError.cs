using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PartDelivery;

public class PartDeliveryDomainError
{
    public static Error OKBNotFound(string okbNo) => Error.CreateError<PartDeliveryDomainError>(
        nameof(OKBNotFound),
        null,
        okbNo
    );
}
