using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PartDelivery;

public class OKB : AggregateRoot<long>
{
    public static class DeliveryTypeEnum
    {
        public const string Direct = "DIRECT";
        public const string MilkRun = "MILK-RUN";
    }
    public string DnNo { get; set; } = "";
    public DateTime? DnDate { get; set; }
    public string? DnType { get; set; }
    public string? SapPoNo { get; set; }
    public long? PosOrderId { get; set; }
    public string? PlantCode { get; set; }
    public string VendorCode { get; set; } = "";
    public string VendorSite { get; set; } = "";
    public string? WarehouseCode { get; set; }
    public string? MaterialCat { get; set; }
    public string? DockNo { get; set; }
    public string? ParkNo { get; set; }
    public string? DeliveryType { get; set; }
    public string? TransporterCode { get; set; }
    public string? RouteCode { get; set; }
    public string? CfcCode { get; set; }
    public DateTime? DlvDate { get; set; }
    public string? DlvShift { get; set; }
    public string? DlvTime { get; set; }
    public int? DlvCycleNo { get; set; }
    public string? DnDesc100 { get; set; }
    public short? PrintStatus { get; set; }
    public DateTime? PrintDate { get; set; }
    public long? PrintBy { get; set; }
    public short? RcvStatus { get; set; }
    public string? PickNo { get; set; }
    public string? SjNo { get; set; }
    public DateTime? SjDate { get; set; }
    public string? ShopCode { get; set; }
    public string? DelayReason { get; set; } 
}
