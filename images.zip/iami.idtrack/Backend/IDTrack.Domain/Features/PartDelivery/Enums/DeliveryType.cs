namespace IDTrack.Domain.Features.PartDelivery.Enums;

public static class DeliveryType
{
    public const string Direct = "DIRECT";
    public const string MilkRun = "MILKRUN";
}
