namespace IDTrack.Domain.Features.AppConfiguration.Enums;

public static class AppConfigType
{
    public const string EnablePickingGeofence = "ENABLE_PICKING_GEOFENCE";
    public const string GeofenceRadiusInMeter = "GEOFENCE_RADIUS_IN_METER";
}
