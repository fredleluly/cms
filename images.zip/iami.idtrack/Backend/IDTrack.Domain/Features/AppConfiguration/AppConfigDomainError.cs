using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.AppConfiguration;

public static class AppConfigurationDomainError{
public static Error FailedToUpdateAppConfiguration(string message) =>
        new Error(nameof(FailedToUpdateAppConfiguration), "Failed to update app configuration: " + message);
}
