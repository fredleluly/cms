namespace IDTrack.Domain.Features.AppConfiguration;

public record AppConfig(string Name, string Value);
