using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Route;

public class PickingRoute : AggregateRoot<long>
{
    public string RouteCode { get; set; } = "";
    public string RouteName { get; set; } = "";
    public string? RouteDesc100 { get; set; }
}
