using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Route;

public static class PickingRouteDomainError
{
    public static Error FailedToCreatePickingRoute(string errorMessage) => new(nameof(FailedToCreatePickingRoute), "Failed to create picking route: " + errorMessage + ", please try again");
    public static Error FailedToUpdatePickingRoute(string errorMessage) => new(nameof(FailedToUpdatePickingRoute), "Failed to update picking route: " + errorMessage + ", please try again");
    public static Error PickingRouteNotFound(long id) => new(nameof(PickingRouteNotFound), $"Failed to find picking route with id: {id}, please try again");
    public static Error PickingRouteNotFound(string routeCode) => new(nameof(PickingRouteNotFound), $"Failed to find picking route with code: {routeCode}, please try again");
    public static Error PickingRouteNotFound(string routeCode, string row) => new(nameof(PickingRouteNotFound), $"Failed to find picking route with code: {routeCode} at row [{row}], please try again");
    public static Error CannotDeletePickingRouteWithTransactionData => new(nameof(CannotDeletePickingRouteWithTransactionData), "Cannot delete route that is used by picking instruction.");
    public static Error SomeRoutesDoesNotExists => new(nameof(SomeRoutesDoesNotExists), "Some routes does not exists");
}
