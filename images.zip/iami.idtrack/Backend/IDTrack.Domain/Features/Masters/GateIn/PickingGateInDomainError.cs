using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.GateIn;

public static class PickingGateInDomainError
{
    public static Error FailedToCreatePickingGateIn(string errorMessage) => new(nameof(FailedToCreatePickingGateIn), "Failed to create picking gate in: " + errorMessage + ", please try again");
    public static Error FailedToUpdatePickingGateIn(string errorMessage) => new(nameof(FailedToUpdatePickingGateIn), "Failed to update picking gate in: " + errorMessage + ", please try again");
    public static Error PickingGateInNotFound(long id) => new(nameof(PickingGateInNotFound), $"Failed to find picking gate in with id: {id}, please try again");
    public static Error InvalidGateInToken => new(nameof(InvalidGateInToken), "Invalid gate token.");
    public static Error GateInNameAlreadyExist => new(nameof(GateInNameAlreadyExist), "Failed to create picking gate in: A gate-in with the same name already exists, please try another name and coordinates");
}
