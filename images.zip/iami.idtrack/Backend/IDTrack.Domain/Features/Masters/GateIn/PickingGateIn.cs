using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.GateIn;

public class PickingGateIn : AggregateRoot<long>
{
    public string Token { get; set; } = "";
    public string Name { get; set; } = "";
    public string Lat { get; set; } = "";
    public string Lng { get; set; } = "";
}
