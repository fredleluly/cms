using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Transporter;

public static class PickingTransporterDomainError
{
    public static Error FailedToCreatePickingTransporter(string errorMessage) => new(nameof(FailedToCreatePickingTransporter), "Failed to create picking transporter: " + errorMessage + ", please try again.");
    public static Error FailedToUpdatePickingTransporter(string errorMessage) => new(nameof(FailedToUpdatePickingTransporter), "Failed to update picking transporter: " + errorMessage + ", please try again.");
    public static Error PickingTransporterNotFound(string id) => new(nameof(PickingTransporterNotFound), $"Failed to find picking transporter: {id}, please try again");
    public static Error CannotDeletePickingTransporterWithTransactionData => new(nameof(CannotDeletePickingTransporterWithTransactionData), "Cannot delete transporter that is used by picking instruction.");
}
