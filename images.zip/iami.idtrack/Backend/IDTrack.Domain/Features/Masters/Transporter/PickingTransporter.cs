using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Transporter;

public class PickingTransporter : AggregateRoot<long>
{
    public string TransporterCode { get; set; } = "";
    public string TransporterName { get; set; } = "";
    public string? TransporterDesc100 { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public string? RegionCode { get; set; }
    public string? CountryCode { get; set; }
    public string? ContactName { get; set; }
    public string? PhoneNo1 { get; set; }
    public string? PhoneNo2 { get; set; }
    public string? FaxNo1 { get; set; }
    public string? FaxNo2 { get; set; }
    public string? Email { get; set; }
    public string? TaxCode { get; set; }
    public string? VendorDesc100 { get; set; }
    public string? VendorType { get; set; }
}
