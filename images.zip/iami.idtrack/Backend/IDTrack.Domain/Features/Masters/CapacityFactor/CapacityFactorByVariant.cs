using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.CapacityFactor;

public class CapacityFactorByVariant : AggregateRoot<long>
{
    public string Suffix { get; init; } = "";
    public string Katashiki { get; init; } = "";
    public string RouteCode { get; init; } = "";
    public decimal CapacityFactorInPercentage { get; set; }

    public PickingRoute? PickingRoute { get; set; }
}
