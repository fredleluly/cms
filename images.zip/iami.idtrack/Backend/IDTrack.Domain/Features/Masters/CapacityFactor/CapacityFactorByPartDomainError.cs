using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.CapacityFactor;

public static class CapacityFactorByPartDomainError
{
    public static Error FailedToCreateCapacityFactorByPart(string message) =>
        new Error(nameof(FailedToCreateCapacityFactorByPart), "Failed to create capacity factor by part: " + message);

    public static Error FailedToUpdateCapacityFactorByPart(string message) =>
        new Error(nameof(FailedToUpdateCapacityFactorByPart), "Failed to update capacity factor by part: " + message);

    public static Error CapacityFactorByPartNotFound(long id) =>
        new Error(nameof(CapacityFactorByPartNotFound), $"Route part capacity was not found");

    public static Error FailedToDeleteCapacityFactorByPart(string message) =>
        new Error(nameof(FailedToDeleteCapacityFactorByPart), "Failed to delete capacity factor by part: " + message);

    public static Error FileIsNotExcel =>
        new Error(nameof(FileIsNotExcel), "File is not an Excel file");

    public static Error FailedToUploadCapacityFactorByPart(string message) =>
        new Error(nameof(FailedToUploadCapacityFactorByPart), "Failed to upload capacity factor by part: " + message);

    public static Error InvalidCapacityFactor(string cell, Error error) =>
        new Error(nameof(InvalidCapacityFactor), "Invalid capacity factor at cell [" + cell + "]: " + error.Description);
}