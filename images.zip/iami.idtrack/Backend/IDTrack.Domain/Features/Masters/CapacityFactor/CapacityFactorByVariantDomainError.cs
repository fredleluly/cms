using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.CapacityFactor;

public static class CapacityFactorByVariantDomainError
{
    public static Error FailedToCreateCapacityFactorByVariant(string message) =>
        new Error(nameof(FailedToCreateCapacityFactorByVariant), "Failed to create capacity factor by variant: " + message);

    public static Error FailedToUpdateCapacityFactorFactor(string message) =>
        new Error(nameof(FailedToUpdateCapacityFactorFactor), "Failed to update capacity factor by variant: " + message);

    public static Error CapacityFactorByVariantNotFound(long id) =>
        new Error(nameof(CapacityFactorByVariantNotFound), $"The capacity factor by variant was not found");

    public static Error FailedToDeleteCapacityFactorByVariant(string message) =>
        new Error(nameof(FailedToDeleteCapacityFactorByVariant), "Failed to delete capacity factor by variant: " + message);

    public static Error FileIsNotExcel =>
        new Error(nameof(FileIsNotExcel), "File is not an Excel file");

    public static Error FailedToDownloadTemplate(string message) =>
        new Error(nameof(FailedToDownloadTemplate), "Failed to download template: " + message);

    public static Error ValueIsNoDecimal(string cell) =>
        new Error(nameof(ValueIsNoDecimal), $"Value in cell '{cell}' is not a decimal");

    public static Error FailedToUploadCapacityFactorByVariant(string message) =>
        new Error(nameof(FailedToUploadCapacityFactorByVariant), "Failed to upload capacity factor by variant: " + message);

    public static Error InvalidCapacityFactor(string cell, Error error) =>
        new Error(nameof(InvalidCapacityFactor), "Invalid capacity factor at cell [" + cell + "]: " + error.Description);

    public static Error CapacityFactorCannotBeNegativeOrZero =>
        new Error(nameof(CapacityFactorCannotBeNegativeOrZero), "Capacity factor cannot be negative or zero");

    public static Error RouteCodeCannotBeEmpty =>
        new Error(nameof(RouteCodeCannotBeEmpty), "Route code cannot be empty");

    public static Error KatashikiCannotBeEmpty =>
        new Error(nameof(KatashikiCannotBeEmpty), "Katashiki cannot be empty");

    public static Error SuffixCannotBeEmpty =>
        new Error(nameof(SuffixCannotBeEmpty), "Suffix cannot be empty");

    public static Error VariantNotFound(string katashiki, string suffix) =>
        new Error(nameof(VariantNotFound), $"The katashiki {katashiki} and suffix {suffix} is not found.");
}
