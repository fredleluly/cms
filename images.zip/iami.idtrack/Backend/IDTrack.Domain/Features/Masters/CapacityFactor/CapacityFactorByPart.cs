using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.CapacityFactor;

public class CapacityFactorByPart : AggregateRoot<long>
{
    public string RouteCode { get; set; } = "";
    public string PartNo { get; set; } = "";
    public decimal CapacityFactor { get; set; }
}