using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.TransporterRoute.Entities;

public class Cycle : Entity<long>
{
    public int CycleNo { get; set; }
    public TimeOnly DeparturePlan { get; set; }
    public TimeOnly ArrivalPlan { get; set; }
}
