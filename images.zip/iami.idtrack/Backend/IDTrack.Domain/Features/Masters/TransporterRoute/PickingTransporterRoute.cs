using IDTrack.Domain.Features.Masters.Route;
using IDTrack.Domain.Features.Masters.Transporter;
using IDTrack.Domain.Features.Masters.TransporterRoute.Entities;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.TransporterRoute;

public class PickingTransporterRoute : AggregateRoot<long>
{
    public long PickingRouteId { get; set; }

    public long PickingTransporterId { get; set; }

    public ICollection<Cycle> Cycles { get; set; } = Enumerable.Empty<Cycle>().ToList();

    // TODO: Add logic for when there are duplicate departure and arrival plans
    public void UpdateCycle(ICollection<Cycle> cycle)
    {
        Cycles = cycle;

        int i = 1;
        foreach (var c in Cycles.OrderBy(e => e.DeparturePlan).ThenBy(e => e.ArrivalPlan))
        {
            c.CycleNo = i++;
        }
    }

    public PickingTransporter? Transporter { get; set; }
    public PickingRoute? Route { get; set; }
}
