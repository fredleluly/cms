using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.TransporterRoute;

public static class PickingTransporterRouteDomainError
{
    public static Error FailedToCreatePickingTransporterRoute(string errorMessage) => new(nameof(FailedToCreatePickingTransporterRoute), "Failed to create picking transporter route: " + errorMessage + ", please try again.");
    public static Error DuplicatePickingTransporterRoute => new(nameof(DuplicatePickingTransporterRoute), "Transporter Code and Route Code already exists");
    public static Error FailedToUpdatePickingTransporterRoute(string errorMessage) => new(nameof(FailedToUpdatePickingTransporterRoute), "Failed to update picking transporter route: " + errorMessage + ", please try again.");
    public static Error PickingTransporterRouteNotFound(long id) => new(nameof(PickingTransporterRouteNotFound), $"Failed to find picking transporter route with id: {id}, please try again");
    public static Error CannotDeletePickingTransporterRouteWithTransactionData => new(nameof(CannotDeletePickingTransporterRouteWithTransactionData), "Cannot delete transporter route that is used by picking instruction.");
}
