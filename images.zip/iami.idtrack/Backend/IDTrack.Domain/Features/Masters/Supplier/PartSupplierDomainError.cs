using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Supplier;

public static class PartSupplierDomainError
{
    public static Error FailedToCreatePartSupplier(string errorMessage) => new(nameof(FailedToCreatePartSupplier), "Failed to create part supplier : " + errorMessage + ", please try again.");
    public static Error FailedToUpdatePartSupplier(string errorMessage) => new(nameof(FailedToUpdatePartSupplier), "Failed to update part supplier : " + errorMessage + ", please try again.");
    public static Error PartSupplierNotFound(string id) => new(nameof(PartSupplierNotFound), $"Failed to find part supplier [{id}], please try again");

}
