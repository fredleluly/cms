using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Masters.Supplier;

public class PartSupplier : AggregateRoot<long>
{
    public string VendorCode { get; set; } = "";
    public string? VendorName { get; set; }
    public string? AliasName { get; set; }
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? PostalCode { get; set; }
    public string? RegionCode { get; set; }
    public string? CountryCode { get; set; }
    public string? ContactName { get; set; }
    public string? PhoneNo1 { get; set; }
    public string? PhoneNo2 { get; set; }
    public string? FaxNo1 { get; set; }
    public string? FaxNo2 { get; set; }
    public string? Email { get; set; }
    public string? TaxCode { get; set; }
    public string? VendorDesc100 { get; set; }
    public string? VendorType { get; set; }
    public long? ParentId { get; set; }
    public string? Lat { get; set; }
    public string? Lng { get; set; }
}
