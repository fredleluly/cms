using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Direct;

public class DirectDeliveryDomainError
{
    public static Error OKBNotFound(string okbNo) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(OKBNotFound),
        null,
        okbNo
    );

    public static Error OKBSupplierMismatch(string okbNo) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(OKBSupplierMismatch),
        null,
        okbNo
    );

    public static Error DeliveryMismatch => Error.CreateError<DirectDeliveryDomainError>(
        nameof(DeliveryMismatch)
    );

    public static Error OKBAlreadyExistsInDelivery(string okbNo) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(OKBAlreadyExistsInDelivery),
        null,
        okbNo
    );

    public static Error OKBDelivered(string okbNo) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(OKBDelivered),
        null,
        okbNo
    );

    public static Error DeliveryNotFound => Error.CreateError<DirectDeliveryDomainError>(
        nameof(DeliveryNotFound) 
    );

    public static Error GateInOutsideRadius(string distance) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(GateInOutsideRadius),
        null,
        distance
    );

    public static Error UserDoesNotHaveDeliverySession => Error.CreateError<DirectDeliveryDomainError>(
        nameof(UserDoesNotHaveDeliverySession)
    );

    public static Error DeliveryCompleted => Error.CreateError<DirectDeliveryDomainError>(
        nameof(DeliveryCompleted)
    );

    public static Error FailedToCreateDelivery(string message) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(FailedToCreateDelivery),
        null,
        message
    );

    public static Error FailedToDeleteDelivery(string message) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(FailedToDeleteDelivery),
        null,
        message
    );

    public static Error FailedToUpdateDelivery(string message) => Error.CreateError<DirectDeliveryDomainError>(
        nameof(FailedToUpdateDelivery),
        null,
        message
    );

    public static Error CannotCancelCompletedDelivery => Error.CreateError<DirectDeliveryDomainError>(
        nameof(CannotCancelCompletedDelivery)
    );

}
