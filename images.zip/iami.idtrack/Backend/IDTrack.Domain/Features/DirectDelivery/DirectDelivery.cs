using IDTrack.Domain.Features.Direct.Entities;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Direct;

public class DirectDelivery : AggregateRoot<long>
{
    public static class DirectDeliveryStatus 
    {
        public const short Cancelled = -1;
        public const short Pending = 0;
        public const short OnTheWay = 1;
        public const short Delivered = 2;
    }
    public string SupplierCode { get; init; } = "";
    public DateTime DeliveryDate { get; init; }
    public string? StartByDeviceId {get; set; } = "";
    public string? CancelByDeviceId {get; set; } = "";
    public string? GateInByDeviceId {get; set; } = "";
    
    public ICollection<DirectOKB> DirectOKBs { get; set; } = new List<DirectOKB>();

    public void Start(string? deviceId)
    {
        Status = DirectDeliveryStatus.OnTheWay;
        StartByDeviceId = deviceId;
    }

    public Result Cancel(string? deviceId)
    {
        if (Status == DirectDeliveryStatus.Delivered)
            return DirectDeliveryDomainError.CannotCancelCompletedDelivery;

        Status = DirectDeliveryStatus.Cancelled;
        CancelByDeviceId  = deviceId;

        return Result.Success();
    }
    
    public void Complete(string? deviceId)
    {
        foreach (var okb in DirectOKBs)
        {
            okb.Arrive();
        }

        GateInByDeviceId = deviceId;
        Status = DirectDeliveryStatus.Delivered;
    }

    public Result AddOkb(string okbNo)
    {
        if (DirectOKBs.Any(x => x.OkbNo == okbNo))
            return DirectDeliveryDomainError.OKBAlreadyExistsInDelivery(okbNo);
        DirectOKBs.Add(new DirectOKB(okbNo));
        return Result.Success();
    }

    public Result CancelOkb(string okbNo)
    {
        var okb = DirectOKBs.FirstOrDefault(x => x.OkbNo == okbNo);

        if (okb is null)
            return DirectDeliveryDomainError.OKBNotFound(okbNo);

        DirectOKBs.Remove(okb);

        return Result.Success();
    }
}
