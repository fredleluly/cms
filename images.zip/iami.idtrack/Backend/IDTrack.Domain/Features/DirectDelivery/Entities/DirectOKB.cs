using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Direct.Entities;

public class DirectOKB : Entity<long>
{
    public static class DirectOKBStatus
    {
        public const short OnTheWay = 0;
        public const short Delivered = 1;
    }
    public string OkbNo { get; init; }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public DirectOKB() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

    public DirectOKB(string okbNo)
    {
        OkbNo = okbNo;
    }

    public void Arrive()
    {
        Status = DirectOKBStatus.Delivered;
    }
}
