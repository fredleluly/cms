using IDTrack.Domain.Features.Masters.Supplier;
using IDTrack.Domain.Features.Picking.Entities;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Picking;

public class PickupPoint : AggregateRoot<long>
{
    public static class PickupPointStatus
    {
        public const short Unpicked = 0;
        public const short Loading = 1;
        public const short Picked = 2;
    }
    public long PickingInstructionId { get; init; }
    public string VendorCode { get; init; } = "";
    public string VendorSite { get; init; } = "";
    public ICollection<PickupOKB> OKBs { get; set; } = new List<PickupOKB>();
    public string? StartByDeviceId {get; set; } = "";
    public string? CompleteByDeviceId {get; set; } = "";
    public PartSupplier? Supplier { get; set; }

    // WebClient concerns
    public Result<ICollection<string>> SetOkb(IEnumerable<string> okbs)
    {
        // new okb
        var newOkb = okbs.Except(OKBs.Select(o => o.OkbNo));
        if (newOkb.Any())
        {
            OKBs = OKBs.Concat(newOkb.Select(o => new PickupOKB(o))).ToList();
        }

        // deleted okb
        ICollection<string> deletedOkb = OKBs.Select(o => o.OkbNo).Except(okbs).ToList();
        if (deletedOkb.Any())
        {
            foreach (var okbNo in deletedOkb)
            {
                var okb = OKBs.First(o => o.OkbNo == okbNo);
                OKBs.Remove(okb);
            }
        }

        return Result.Success(deletedOkb);
    }

    public Result AdvanceOkbs(IEnumerable<string> okbs)
    {
        foreach (var okbNo in okbs)
        {
            var okb = OKBs.FirstOrDefault(o => o.OkbNo == okbNo);
            if (okb is null)
            {
                return PickingDomainError.OKBNotFound;
            }
            okb.Advance();
        }
        return Result.Success();
    }

    public Result AddOkb(string okbNo)
    {
        if (OKBs.Any(o => o.OkbNo == okbNo))
        {
            return PickingDomainError.DuplicateOKB;
        }
        OKBs.Add(new PickupOKB(okbNo));
        return Result.Success();
    }

    public Result RemoveOkb(string okbNo)
    {
        var okb = OKBs.FirstOrDefault(o => o.OkbNo == okbNo);
        if (okb is null)
        {
            return PickingDomainError.OKBNotFound;
        }
        OKBs.Remove(okb);
        return Result.Success();
    }

    // LP concerns
    public Result PickOkb(string okbNo)
    {
        var okb = OKBs.FirstOrDefault(o => o.OkbNo == okbNo);
        if (okb is null)
        {
            return PickingDomainError.OKBNotFound;
        }
        var okbResult = okb.Pick();
        if (okbResult.IsFailure)
            return okbResult;

        Status = PickupPointStatus.Loading;
        return Result.Success();
    }

    public Result PickOkb(string okbNo, string? deviceId)
    {
        var okb = OKBs.FirstOrDefault(o => o.OkbNo == okbNo);
        if (okb is null)
        {
            return PickingDomainError.OKBNotFound;
        }
        StartByDeviceId = deviceId;
        var okbResult = okb.Pick(deviceId);
        if (okbResult.IsFailure)
            return okbResult;

        Status = PickupPointStatus.Loading;
        return Result.Success();
    }

    public Result DelayOkb(string okbNo, string reason)
    {
        var okb = OKBs.FirstOrDefault(o => o.OkbNo == okbNo);
        if (okb is null)
        {
            return PickingDomainError.OKBNotFound;
        }
        okb.Delay(reason);
        return Result.Success();
    }

    public Result DelayRestOfOKB(string reason)
    {
        foreach (var okb in OKBs.Where(o => o.Status <= PickupOKB.PickupOKBStatus.Unpicked))
        {
            okb.Delay(reason);
        }

        return Result.Success();
    }

    public Result DelayRestOfOKB(string reason, string? deviceId)
    {
        foreach (var okb in OKBs.Where(o => o.Status <= PickupOKB.PickupOKBStatus.Unpicked))
        {
            okb.Delay(reason, deviceId);
        }

        return Result.Success();
    }

    public Result Complete(string? deviceId)
    {
        if (OKBs.Any(o => o.Status == PickupOKB.PickupOKBStatus.Unpicked))
        {
            return PickingDomainError.ThereAreUnpickedOKBs;
        }

        CompleteByDeviceId = deviceId;
        Status = PickupPointStatus.Picked;
        return Result.Success();
    }
}
