using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Picking.Entities;

public class PickupOKB : Entity<long>
{
    public static class PickupOKBStatus
    {
        public const short Delayed = -1;
        public const short Unpicked = 0;
        public const short Picked = 1;
        public const short Reassigned = 2;
    }
    public string OkbNo { get; init; }

    public string? DelayReason { get; private set; }

    public bool IsAdvanced { get; set; } = false;
    public string? ScannedByDeviceId { get; set;} = "";
    public string? DelayedByDeviceId { get; set; }= "";

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    public PickupOKB() { }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.

    public PickupOKB(string okbNo) : this(okbNo, PickupOKBStatus.Unpicked) { }

    public PickupOKB(string okbNo, short status)
    {
        if (status != PickupOKBStatus.Unpicked && status != PickupOKBStatus.Picked && status != PickupOKBStatus.Delayed)
        {
            throw new ArgumentException("Invalid status");
        }

        OkbNo = okbNo;
        Status = status;
    }

    public void Reassign() 
    {
        Status = PickupOKBStatus.Reassigned;
    }

    public void Advance() 
    {
        IsAdvanced = true;
    }

    public Result Pick(bool force = false)
    {
        if (Status == PickupOKBStatus.Reassigned)
        {
            return PickingDomainError.CannotPickReassignedOKB(OkbNo);
        }
        DelayReason = null;
        Status = PickupOKBStatus.Picked;
        return Result.Success();
    }

    public Result Pick(string? deviceId, bool force = false)
    {
        if (Status == PickupOKBStatus.Reassigned)
        {
            return PickingDomainError.CannotPickReassignedOKB(OkbNo);
        }
        ScannedByDeviceId = deviceId;
        DelayReason = null;
        Status = PickupOKBStatus.Picked;
        return Result.Success();
    }

    public void Delay(string reason)
    {
        Status = PickupOKBStatus.Delayed;
        DelayReason = reason;
    }

    public void Delay(string reason, string? deviceId)
    {
        DelayedByDeviceId = deviceId;
        Delay(reason);
    }
}
