using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Picking;

public class PickingInstruction : AggregateRoot<long>
{
    public static class PickingStatus
    {
        public const short New = 0;
        public const short InProgress = 1;
        public const short GateIn = 2;
        public const short GR = 3;
    }
    public string PickNo { get; init; } = "";
    public string RouteCode { get; init; } = "";
    public string TransporterCode { get; init; } = "";
    public int? CycleNo { get; set; }
    public DateTime PickDate { get; init; }
    public DateTime ArrivalDate { get; init; }
    public string ArrivalTime { get; init; } = "";
    public short RcvStatus { get; set; }
    public bool GeofencingEnabled { get; set; } = true;
    public bool Untracked { get; set; } = false;
    public short? PickStatus { get; set; }
    public int? DriverId { get; set; }
    public DateTime? PickStartTime { get; set; }
    public DateTime? GateInTime { get; set; }
    public string? StartByDeviceId { get; set; } = "";
    public string? GateInByDeviceId { get; set; } = "";
    public string? SapPoNo { get; set; }

    public Result Start(int driverId)
    {
        if (PickStatus != PickingStatus.New)
        {
            return Result.Failure(PickingDomainError.PickingInstructionAlreadyStarted);
        }

        DriverId = driverId;
        PickStatus = PickingStatus.InProgress;
        PickStartTime = DateTime.Now;
        return Result.Success();
    }

    public Result Start(int driverId, string? deviceId)
    {
        if (PickStatus != PickingStatus.New)
        {
            return Result.Failure(PickingDomainError.PickingInstructionAlreadyStarted);
        }
        StartByDeviceId = deviceId;
        DriverId = driverId;
        PickStatus = PickingStatus.InProgress;
        PickStartTime = DateTime.Now;
        return Result.Success();
    }

    public Result GateIn(string? deviceId)
    {
        PickStatus = PickingStatus.GateIn;
        GateInTime = DateTime.Now;
        GateInByDeviceId = deviceId;
        return Result.Success();
    }

    public Result GateIn()
    {
        PickStatus = PickingStatus.GateIn;
        GateInTime = DateTime.Now;
        return Result.Success();
    }
}
