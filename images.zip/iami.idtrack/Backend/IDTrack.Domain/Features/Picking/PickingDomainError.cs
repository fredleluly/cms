using IDTrack.Domain.Models;
namespace IDTrack.Domain.Features.Picking;

public class PickingDomainError
{
    public static Error DuplicateOKB => Error.CreateError<PickingDomainError>(
        nameof(DuplicateOKB)
    );
    public static Error OKBNotFound => Error.CreateError<PickingDomainError>(
        nameof(OKBNotFound)
        );
    public static Error OKBAlreadyInOtherPickingInstruction(string okbNos) => Error.CreateError<PickingDomainError>(
        nameof(OKBAlreadyInOtherPickingInstruction), 
        null, 
        okbNos
    );
    public static Error ThereAreUnpickedOKBs => Error.CreateError<PickingDomainError>(
        nameof(ThereAreUnpickedOKBs)
    );
    public static Error FailedToCreatePickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(FailedToCreatePickingInstruction)
    );
    public static Error PickingInstructionNotFound => Error.CreateError<PickingDomainError>(
        nameof(PickingInstructionNotFound)
    );
    public static Error PickupPointNotFound => Error.CreateError<PickingDomainError>(
        nameof(PickupPointNotFound)
    );
    public static Error CannotEditStartedPickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(CannotEditStartedPickingInstruction)
    );
    public static Error FailedToUpdatePickingInstruction(string? msg) => Error.CreateError<PickingDomainError>(
        nameof(FailedToUpdatePickingInstruction), 
        null,
        msg ?? "Internal server error"
    );
    public static Error FailedToUpdatePickupPoint(string? msg) => Error.CreateError<PickingDomainError>(
        nameof(FailedToUpdatePickupPoint), 
        null,
        msg ?? "Internal server error"
    );
    public static Error FailedToTogglePickingGeofencing => Error.CreateError<PickingDomainError>(
        nameof(FailedToTogglePickingGeofencing)
    );
    public static Error FailedToDeletePickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(FailedToDeletePickingInstruction)
    );
    public static Error FailedToToggleUntrackPickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(FailedToToggleUntrackPickingInstruction)
    );
    public static Error DeviceIsNotInScanRadius => Error.CreateError<PickingDomainError>(
        nameof(DeviceIsNotInScanRadius)
    );
    public static Error PickingInstructionAlreadyStarted => Error.CreateError<PickingDomainError>(
        nameof(PickingInstructionAlreadyStarted)
    );
    public static Error LogisticPartnerCodeMismatch => Error.CreateError<PickingDomainError>(
        nameof(LogisticPartnerCodeMismatch)
    );
    public static Error OKBNotFoundInPickingInstruction(string okbNo) => Error.CreateError<PickingDomainError>(
        nameof(OKBNotFoundInPickingInstruction), 
        null,
        okbNo
    );
    public static Error CannotAssignOKBToCompletedPickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(CannotAssignOKBToCompletedPickingInstruction)
    );
    public static Error CannotAssignOKBToCompletedPickupPoints(string vendorCode) => Error.CreateError<PickingDomainError>(
        nameof(CannotAssignOKBToCompletedPickupPoints), 
        null,
        vendorCode
    );
    public static Error CannotCancelPickingInstruction => Error.CreateError<PickingDomainError>(
        nameof(CannotCancelPickingInstruction)
    );
    public static Error OKBHasDifferentPickingDetails => Error.CreateError<PickingDomainError>(
        nameof(OKBHasDifferentPickingDetails)
    );
    public static Error OKBAlreadyInPickingInstruction(string okbNos) => Error.CreateError<PickingDomainError>(
        nameof(OKBAlreadyInPickingInstruction), 
        null,
        okbNos
    );
    public static Error CannotPickReassignedOKB(string okbNo) => Error.CreateError<PickingDomainError>(
        nameof(CannotPickReassignedOKB), 
        null,
        okbNo
    );

}
