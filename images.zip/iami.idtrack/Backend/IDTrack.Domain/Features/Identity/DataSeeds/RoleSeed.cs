using IDTrack.Domain.Features.Identity.Entities;
using IDTrack.Domain.Features.Identity.Enums;

namespace IDTrack.Domain.Features.Identity.DataSeeds;

public class RoleSeed 
{
    public static ICollection<Role> Values = new List<Role>(
        new Role[] 
        {
            new Role { Id = 5, Name = RoleNames.Supplier, RoleDescription = "IAMI's part supplier" },
            new Role { Id = 6, Name = RoleNames.LogisticPartner, RoleDescription = "IAMI's logistic partner" },
        }
    );
}
