using System.Security.Claims;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Identity.Entities;

public class Role : Entity<int>
{
    public required string Name { get; set; }
    public required string RoleDescription { get; set; }

    public ICollection<Claim> Claims { get; set; } = new List<Claim>();
}
