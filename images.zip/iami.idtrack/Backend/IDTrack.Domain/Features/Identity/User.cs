using System.Security.Claims;
using IDTrack.Domain.Features.Identity.Enums;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Identity;

public class User : AggregateRoot<int>
{
	public required string Fullname { get; set; }
    public required string Username { get; set; }
    public required string Email { get; set; }
    public string? PhoneNumber { get; set; }
    public string? PlantCode { get; set; }
	public string? WarehouseCode { get; set; }
	public bool Disabled { get; set; }

    public bool EmailConfirmed { get; set; }
    public bool LockoutEnabled { get; set; }

	public ICollection<Claim> Claims { get; set; } = new List<Claim>();

    public void Disable()
    {
        Disabled = true;
    }

    public void Enable()
    {
        Disabled = false;
    }

	public bool IsSupplier()
	{
		return Claims.Any(c => c.Type == ClaimType.Role && c.Value == RoleNames.Supplier);
	}

	public bool IsLogisticPartner()
	{
		return Claims.Any(c => c.Type == ClaimType.Role && c.Value == RoleNames.LogisticPartner);
	}

    public void RemoveSupplierClaim()
    {
		if (Claims.Any(c => c.Type == ClaimType.SupplierId))
		{
			Claims.Remove(Claims.First(c => c.Type == ClaimType.SupplierId));
		}
    }

    public void RemoveLogisticPartnerClaim()
    {
		if (Claims.Any(c => c.Type == ClaimType.LogisticPartnerId))
		{
			Claims.Remove(Claims.First(c => c.Type == ClaimType.LogisticPartnerId));
		}
    }

	public void SetSupplier(string supplierCode)
	{
        RemoveSupplierClaim();
		Claims.Add(new Claim(ClaimType.SupplierId, supplierCode));
	}

	public void SetLogisticPartner(string logisticPartnerCode)
	{
        RemoveLogisticPartnerClaim();
		Claims.Add(new Claim(ClaimType.LogisticPartnerId, logisticPartnerCode));
	}
}
