namespace IDTrack.Domain.Features.Identity.Enums;

public static class ClaimType
{
    public const string SupplierId = "supplier-id";
    public const string LogisticPartnerId = "logistic-partner-id";
    public const string Role = "role";
}
