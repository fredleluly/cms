namespace IDTrack.Domain.Features.Identity.Enums;

public static class RoleNames
{
    public const string Admin = "administrator";
    public const string User = "user";
    public const string Supplier = "supplier";
    public const string LogisticPartner = "logistic-partner";
}
