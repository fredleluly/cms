using IDTrack.Domain.Internationalization;
using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.Identity;

public class IdentityDomainError
{
    public static Error FailedToCreateUser(string errorMessage) => new(nameof(FailedToCreateUser), "Failed to create user: " + errorMessage + ", please try again");
    public static Error FailedToUpdateUser(string errorMessage) => new(nameof(FailedToUpdateUser), "Failed to update user: " + errorMessage + ", please try again");
    public static Error FailedToDeleteUser(string errorMessage) => new(nameof(FailedToDeleteUser), "Failed to delete user: " + errorMessage + ", please try again");
    public static Error FailedToAddRole(string errorMessage) => new(nameof(FailedToAddRole), "Failed to add role: " + errorMessage + ", please try again");
    public static Error FailedToRemoveRole(string errorMessage) => new(nameof(FailedToRemoveRole), "Failed to remove role: " + errorMessage + ", please try again");
    public static Error FailedToChangePassword(string errorMessage) => new(nameof(FailedToChangePassword), "Failed to change password: " + errorMessage + ", please try again");
    public static Error FailedToResetPassword(string errorMessage) => new(nameof(FailedToResetPassword), "Failed to reset password: " + errorMessage + ", please try again");
    public static Error FailedToConfirmEmail(string errorMessage) => new(nameof(FailedToConfirmEmail), "Failed to confirm email: " + errorMessage + ", please try again");
    public static Error UsernameAlreadyUsed => new(nameof(UsernameAlreadyUsed), "Username is already used, please try another username");
    public static Error EmailAlreadyUsed => new(nameof(EmailAlreadyUsed), "Email is already used, please try another username");
    public static Error FailedToFindUserAfterCreated => new(nameof(FailedToFindUserAfterCreated), "Failed to find user after created, please try again");
    public static Error UserNotFound(string userId) => new(nameof(UserNotFound), $"Failed to find user with id: {userId}, please try again");
    public static Error UserNotFoundByEmail(string email) => new(nameof(UserNotFoundByEmail), $"Failed to find user with email: {email}, please try again");
    public static Error RefreshTokenNotFound => new(nameof(RefreshTokenNotFound), "Refresh token not found");
    public static Error IncorrectUsernameOrPassword => new(nameof(IncorrectUsernameOrPassword), "Incorrect username or password, please try again");
    public static Error EmailNotConfirmed => new(nameof(EmailNotConfirmed), "Your email is not confirmed, please confirm your email");
    public static Error RefreshTokenUsed => new(nameof(RefreshTokenUsed), "Refresh token is already used");
    public static Error UserIsDisabled => new(nameof(UserIsDisabled), "Cannot process request, user is disabled");
    public static Error CannotSignInUserIsDisabled => new(nameof(CannotSignInUserIsDisabled), "Access Disabled: Your account has been temporarily restricted. Please contact support for more information.");
    public static Error InvalidToken => new(nameof(InvalidToken), "Invalid token");
    public static Error CannotGetRoles => new(nameof(CannotGetRoles), "Cannot get roles, please try again");
    public static Error UserIsNotAuthenticated => new(nameof(UserIsNotAuthenticated), "User is not authenticated");
    public static Error UserIsNotAuthorized => new(nameof(UserIsNotAuthorized), "User is not authorized to perform this action");
    public static Error UserSupplierIsNotSet => new(nameof(UserSupplierIsNotSet), "User's supplier data is not set, please contact administrator");
    public static Error UserLogisticPartnerIsNotSet => new(nameof(UserLogisticPartnerIsNotSet), "User's logistic partner data is not set, please contact administrator");
    public static Error UserCanEitherBeSupplierOrLogisticPartner => new(nameof(UserCanEitherBeSupplierOrLogisticPartner), "User cannot be both supplier and logistic partner.");
    public static Error PleaseAddLogisticPartnerToUserRole => new(nameof(PleaseAddLogisticPartnerToUserRole), "Please add 'logistic-partner' to user's roles");

    public static Error PleaseAddSupplierToUserRole => Error.CreateError<IdentityDomainError>(
        nameof(PleaseAddSupplierToUserRole),
        "Please add 'supplier' to user's roles"
    );

    public static Error VendorCodeRequiredForSupplier => Error.CreateError<IdentityDomainError>(
        nameof(VendorCodeRequiredForSupplier),
        "Please select user's Supplier to user"
    );

    public static Error TransporterCodeRequiredForLogisticPartner => Error.CreateError<IdentityDomainError>(
        nameof(TransporterCodeRequiredForLogisticPartner),
        "Please select user's Logistic Partner to user"
    );
}
