using IDTrack.Domain.Models;
using IDTrack.Domain.Features.PickingPO.Entities;

namespace IDTrack.Domain.Features.PickingPO;

public class PurchaseOrder : AggregateRoot<long>{
    public string PoNo { get; set; } = "";
    public DateTime PoDate { get; set; }
    public string DocType { get; set; } = "";
    public string SapPlantCode { get; set; } = "";
    public string PlantCode { get; set; } = "";
    public long VendorId { get; set; }
    public string VendorCode { get; set; } = "";
    public string PurchaseOrg { get; set; } = "";
    public string PurchaseGroup { get; set; } = "";
    public DateTime ValidStart { get; set; }
    public DateTime ValidEnd { get; set; }
    public string Currency { get; set; } = "";
    public short PoStatus { get; set; }
    public string CfcCode { get; set; } = "";

    public virtual ICollection<PurchaseOrderDetail> Details { get; set; } = new List<PurchaseOrderDetail>();
}
