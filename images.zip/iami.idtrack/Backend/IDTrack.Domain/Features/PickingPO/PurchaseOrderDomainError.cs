using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingPO;

public static class PurchaseOrderDomainError
{
    public static Error PickingPONotFound(string id) => new(nameof(PickingPONotFound), $"Failed to find purchase order: {id}, please try again");
}
