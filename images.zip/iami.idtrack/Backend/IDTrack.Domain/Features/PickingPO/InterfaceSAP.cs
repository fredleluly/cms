using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingPO;

public class InterfaceSAP : AggregateRoot<long>
{
    public long TrackSapPickPoId { get; set; }
    public string IntfGuid { get; set; } = "";
    public string IntfFunc { get; set; } = "";
    public string IntfCompName { get; set; } = "";
    public DateTime IntfTimeStart { get; set; }
    public DateTime? IntfTimeEnd { get; set; }
    public int IntfStatus { get; set; }
    public string IntfConfirm { get; set; } = "";
    public string IntfMessage { get; set; } = "";
    public long RefId { get; set; }
    public long RefIntfId { get; set; }
}
