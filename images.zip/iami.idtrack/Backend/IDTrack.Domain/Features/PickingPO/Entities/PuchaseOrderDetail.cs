using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingPO.Entities;

public class PurchaseOrderDetail : Entity<long>{
    public string PoNo { get; set; } = "";
    public int ItemNo { get; set; }
    public string SapPlantCode { get; set; } = "";
    public string PlantCode { get; set; } = "";
    public long? MaterialId { get; set; }
    public string MaterialNo { get; set; } = "";
    public string SlocCode { get; set; } = "";
    public int QtyPo { get; set; }
    public string ScVendor { get; set; } = "";
    public string SuppVendor { get; set; } = "";
    public string VendorName { get; set; } = "";
    public string DeleteInd { get; set; } = "";
    public int PoDtlStatus { get; set; }
}
