using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingPO.Entities;

public class InterfaceSAPRequest : Entity<long>
{
    public long IntfId { get; set; }
    public DateTime ReqTime { get; set; }
    public string ReqMessage { get; set; } = "";
    public string ReqFilename { get; set; } = "";
    public string ReqPath { get; set; } = "";
}