using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingGR.Entities;

public class GoodReceiveDetail : Entity<long>
{
    public string GRNo { get; set; } = "";
    public int ItemNo { get; set; } = 1;
    public string MaterialNo { get; set; } = "";
    public string Description { get; set; } = "";
    public int Qty { get; set; }
    public string Unit { get; set; } = "";
}
