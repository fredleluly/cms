using IDTrack.Domain.Models;

namespace IDTrack.Domain.Features.PickingGR;

public static class GoodReceiveDomainError
{
    public static Error PickingGRNotFound(string id) => new(nameof(PickingGRNotFound), $"Failed to find good receive: {id}, please try again");
}
