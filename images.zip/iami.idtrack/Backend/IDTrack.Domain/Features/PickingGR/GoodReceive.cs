using IDTrack.Domain.Models;
using IDTrack.Domain.Features.PickingGR.Entities;

namespace IDTrack.Domain.Features.PickingGR;

public class GoodReceive : AggregateRoot<long>
{
    public string GRNo { get; set; } = "";
    public DateTime? GRDate { get; set; }
    public string PONo { get; set; } = "";
    public DateTime? PostDate { get; set; }
    public string DNNo { get; set; } = "";
    public string RefNo { get; set; } = "";
    public string PlantCode { get; set; } = "";
    public string WarehouseCode { get; set; } = "";
    public string VendorCode { get; set; } = "";
    public string VendorSite { get; set; } = "";

    public string SapMatDoc { get; set; } = "";
    public string SapMatDocYear { get; set; } = "";

    public virtual ICollection<GoodReceiveDetail> Details { get; set; } = new List<GoodReceiveDetail>();
}
